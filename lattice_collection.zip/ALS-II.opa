{c:\users\streun\opadat\test\als-ii.opa}
{com uls lattice study com}


energy = 2.000000;

    betax   = 4.1353254; alphax  = 0.0000000;
    etax    = 0.0001233; etaxp   = 0.0000000;
    betay   = 3.7885033; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d11  : drift, l = 0.500000, ax = 50.00, ay = 20.00;
d12  : drift, l = 0.100000, ax = 50.00, ay = 20.00;
d13  : drift, l = 0.150000, ax = 50.00, ay = 20.00;
d14  : drift, l = 0.325000, ax = 50.00, ay = 20.00;
d16  : drift, l = 0.025000, ax = 50.00, ay = 20.00;
d34  : drift, l = 0.220000, ax = 50.00, ay = 20.00;
d2   : drift, l = 0.100000, ax = 50.00, ay = 20.00;
d3   : drift, l = 0.120000, ax = 50.00, ay = 20.00;
d4   : drift, l = 0.120000, ax = 50.00, ay = 20.00;
d33  : drift, l = 0.100000, ax = 50.00, ay = 20.00;
dx1  : drift, l = 0.050000, ax = 50.00, ay = 20.00;
dx2  : drift, l = 0.100000, ax = 50.00, ay = 20.00;
dqf2 : drift, l = 0.075000, ax = 50.00, ay = 20.00;

qf1  : quadrupole, l = 0.200000, k = 9.008000, ax = 50.00, ay = 20.00;
qf2  : quadrupole, l = 0.150000, k = 8.786835, ax = 50.00, ay = 20.00;
q2   : quadrupole, l = 0.150000, k = 18.567360, ax = 50.00, ay = 20.00;
qf5  : quadrupole, l = 0.125000, k = 13.159460, ax = 50.00, ay = 20.00;
qf6  : quadrupole, l = 0.125000, k = 20.124970, ax = 50.00, ay = 20.00;
qf7  : quadrupole, l = 0.125000, k = 20.380000, ax = 50.00, ay = 20.00;
qd1  : quadrupole, l = 0.200000, k = -6.666000, ax = 50.00, ay = 20.00;

b31  : bending, l = 0.500000, t = 3.333333, k = -2.133000, t1 = 0.000000,
       t2 = 0.000000, ax = 50.00, ay = 20.00;
b32  : bending, l = 0.500000, t = 3.333333, k = -7.767328, t1 = 0.000000,
       t2 = 0.000000, ax = 50.00, ay = 20.00;
b3   : bending, l = 0.500000, t = 3.333333, k = -7.670851, t1 = 0.000000,
       t2 = 0.000000, ax = 50.00, ay = 20.00;

sf   : sextupole, l = 0.000000, k = 171.111116, n = 4, ax = 100.00,
       ay = 100.00;
sf2  : sextupole, l = 0.000000, k = 65.789053, n = 4, ax = 100.00,
       ay = 100.00;
sd1  : sextupole, l = 0.000000, k = -101.213585, n = 4, ax = 100.00,
       ay = 100.00;
sd2  : sextupole, l = 0.000000, k = -339.800495, n = 4, ax = 100.00,
       ay = 100.00;


{----- table of segments ----------------------------------------------------}

line1 : 5*d11, qf1, d12, qd1, d13, b31, dx1, sd1, dx1, d14, qf2, dqf2,
        sf, dqf2, qf2, d16, d34, dx2, sd2, dx2, b32, d2, q2, d3, sf2, d4;
line2 : qf5, d33, b3, d33, qf6;
line3 : qf6, d33, b3, d33, qf7;
line4 : qf7, d33, b3, d33, qf7;
line  : line1, line2, line3, line4, -line3, -line2, -line1;
ring  : line, nper=12;

{c:\users\streun\opadat\test\als-ii.opa}
