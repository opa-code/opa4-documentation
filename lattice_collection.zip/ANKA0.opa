{/home/as/opa/repo/anka0.opa}


energy = 2.500000;
rotinv = 0;
    betax   = 20.0777483; alphax  = 0.0000000;
    etax    = -0.0359019; etaxp   = 0.0000000;
    betay   = 8.1401748; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- variables ---------------------------------------------------}


{----- table of elements ---------------------------------------------}

d1   : drift, l = 2.801000, ax = 35.00, ay = 16.00;
d2   : drift, l = 0.450000, ax = 35.00, ay = 16.00;
d3   : drift, l = 0.208000, ax = 35.00, ay = 16.00;
d4   : drift, l = 0.240000, ax = 35.00, ay = 16.00;
d5a  : drift, l = 0.200000, ax = 35.00, ay = 16.00;
d5b  : drift, l = 0.655000, ax = 35.00, ay = 16.00;
d6   : drift, l = 0.170000, ax = 35.00, ay = 16.00;
d7a  : drift, l = 0.200000, ax = 35.00, ay = 16.00;
d7b  : drift, l = 0.615000, ax = 35.00, ay = 16.00;
d8   : drift, l = 0.280000, ax = 35.00, ay = 16.00;
d9   : drift, l = 1.118000, ax = 35.00, ay = 16.00;

q1   : quadrupole, l = 0.320000, k = 2.025000, ax = 35.00, ay = 16.00;
q2   : quadrupole, l = 0.320000, k = -2.010000, ax = 35.00, ay = 16.00;
q3   : quadrupole, l = 0.195000, k = 2.150000, ax = 35.00, ay = 16.00;
q4   : quadrupole, l = 0.320000, k = -2.000000, ax = 35.00, ay = 16.00;
q5   : quadrupole, l = 0.320000, k = 2.050000, ax = 35.00, ay = 16.00;

bend : bending, l = 2.183014, t = 22.500000, k = 0.000000, t1 = 11.250000,
       t2 = 11.250000, ax = 35.00, ay = 16.00;

sh   : sextupole, l = 0.000000, k = 4.581920, n = 1, ax = 35.00, ay = 16.00;
sv   : sextupole, l = 0.000000, k = -4.322804, n = 1, ax = 35.00,
       ay = 16.00;
sw   : sextupole, l = 0.000000, k = -3.406246, n = 1, ax = 35.00,
       ay = 16.00;

ocx  : multipole, n = 4,  k = 0.00000000, ax = 50.00, ay = 50.00;
ocy  : multipole, n = 4,  k = 0.00000000, ax = 50.00, ay = 50.00;


{----- table of segments ---------------------------------------------}

ring   : d1, q1, d2, q2, d3, bend, d4, sw, d5a, ocy, d5b, ocx, d6, q3, q3, d6,
         sh, d7b, ocy, d7a, sv, d8, bend, d3, q4, d2, q5, d9, d9, q5, d2, q4,
         d3, bend, d4, sv, d5a, ocy, d5b, ocx, d6, q3, q3, d6, sh, d7b, ocy,
         d7a, sw, d8, bend, d3, q2, d2, q1, d1, nper=4;
ringq3 : q3, d6, sh, d7b, ocy, d7a, sv, d8, bend, d3, q4, d2, q5, d9, d9, q5,
         d2, q4, d3, bend, d4, sv, d5a, ocy, d5b, ocx, d6, q3, q3, d6, sh, d7b,
         ocy, d7a, sw, d8, bend, d3, q2, d2, q1, d1, d1, q1, d2, q2, d3, bend,
         d4, sw, d5a, ocy, d5b, ocx, d6, q3, nper=4;

{/home/as/opa/repo/anka0.opa}
