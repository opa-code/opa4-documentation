{c:\users\streun\opadat\repository\sirius_v200_ac20_1.opa}


energy = 3.000000;

    betax   = 16.4911503; alphax  = 0.0000000;
    etax    = -0.0000003; etaxp   = 0.0000000;
    betay   = 3.8962684; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

lia2 : drift, l = 3.579200, ax = 15.00, ay = 5.80;
lia1 : drift, l = 0.170000, ax = 15.00, ay = 5.80;
lib  : drift, l = 3.009200, ax = 15.00, ay = 12.00;
l32  : drift, l = 0.430000, ax = 15.00, ay = 12.00;
l31  : drift, l = 0.170000, ax = 15.00, ay = 12.00;
l2   : drift, l = 0.230000, ax = 15.00, ay = 5.80;
l12  : drift, l = 0.170000, ax = 15.00, ay = 5.80;
l11  : drift, l = 0.170000, ax = 15.00, ay = 5.80;
lc11 : drift, l = 0.590000, ax = 15.00, ay = 5.80;
lc12 : drift, l = 0.170000, ax = 15.00, ay = 5.80;
lc21 : drift, l = 0.170000, ax = 15.00, ay = 5.80;
lc22 : drift, l = 0.320000, ax = 15.00, ay = 5.80;
lc31 : drift, l = 0.440000, ax = 15.00, ay = 5.80;
lc32 : drift, l = 0.170000, ax = 15.00, ay = 5.80;
lc4  : drift, l = 0.710000, ax = 15.00, ay = 5.80;
lq   : drift, l = 0.215000, ax = 15.00, ay = 5.80;
lb   : drift, l = 0.130000, ax = 15.00, ay = 5.80;

mc   : marker, ax = 15.00, ay = 5.80;
mia  : marker, ax = 15.00, ay = 5.80;
mib  : marker, ax = 15.00, ay = 5.80;

qaf  : quadrupole, l = 0.340000, k = 2.515526, ax = 15.00, ay = 5.80;
qad  : quadrupole, l = 0.140000, k = -2.602399, ax = 15.00, ay = 5.80;
qbd2 : quadrupole, l = 0.140000, k = 0.000000, ax = 15.00, ay = 5.80;
qbf  : quadrupole, l = 0.340000, k = 2.515526, ax = 15.00, ay = 5.80;
qbd1 : quadrupole, l = 0.140000, k = -2.602399, ax = 15.00, ay = 5.80;
qf1  : quadrupole, l = 0.250000, k = 2.372377, ax = 15.00, ay = 5.80;
qf2  : quadrupole, l = 0.250000, k = 3.351939, ax = 15.00, ay = 5.80;
qf3  : quadrupole, l = 0.250000, k = 3.062241, ax = 15.00, ay = 5.80;
qf4  : quadrupole, l = 0.250000, k = 2.726014, ax = 15.00, ay = 5.80;

b1   : bending, l = 0.828080, t = 2.766540, k = -0.780000, t1 = 1.383270,
       t2 = 1.383270, ax = 15.00, ay = 5.80;
b2   : bending, l = 1.228262, t = 4.103510, k = -0.780000, t1 = 2.051755,
       t2 = 2.051755, ax = 15.00, ay = 5.80;
b3   : bending, l = 0.428011, t = 1.429950, k = -0.780000, t1 = 0.714975,
       t2 = 0.714975, ax = 15.00, ay = 5.80;

sa1  : sextupole, l = 0.150000, k = -46.856865, n = 5, ax = 15.00, ay = 5.80;
sa2  : sextupole, l = 0.150000, k = 23.203597, n = 5, ax = 15.00, ay = 5.80;
sb1  : sextupole, l = 0.150000, k = -46.856865, n = 5, ax = 15.00, ay = 5.80;
sb2  : sextupole, l = 0.150000, k = 23.203597, n = 5, ax = 15.00, ay = 5.80;
sd1  : sextupole, l = 0.150000, k = -143.235386, n = 5, ax = 15.00,
       ay = 5.80;
sf1  : sextupole, l = 0.150000, k = 158.653188, n = 5, ax = 15.00, ay = 5.80;
sd2  : sextupole, l = 0.150000, k = -58.318451, n = 5, ax = 15.00, ay = 5.80;
sd3  : sextupole, l = 0.150000, k = -159.219707, n = 5, ax = 15.00,
       ay = 5.80;
sf2  : sextupole, l = 0.150000, k = 186.119501, n = 5, ax = 15.00, ay = 5.80;

bce  : combined, l = 0.062697, t = 0.700000, k = 0.000000, t1 = 0.700000,
       t2 = 0.000000, m = -18.93, n = 5, ax = 15.00, ay = 5.80;
bcs  : combined, l = 0.062697, t = 0.700000, k = 0.000000, t1 = 0.000000,
       t2 = 0.700000, m = -18.93, n = 5, ax = 15.00, ay = 5.80;

mon  : monitor, ax = 15.00, ay = 5.80;

ch   : h-corrector, ax = 15.00, ay = 5.80;

cv   : v-corrector, ax = 15.00, ay = 5.80;


{----- table of segments ----------------------------------------------------}

dispi  : b1, lc11, sd1, lc12, qf1, lq, sf1, lq, qf2, lc21, sd2, lc22,
         b2, lc31, sd3, lc32, qf3, lq, sf2, lq, qf4, lc4, b3, lb, bce, mc;
dispc  : mc, bcs, lb, b3, lc4, qf4, lq, sf2, lq, qf3, lc32, sd3, lc31,
         b2, lc22, sd2, lc21, qf2, lq, sf1, lq, qf1, lc12, sd1, lc11, b1;
insa   : mia, lia2, sa2, lia1, qaf, l2, qad, l12, sa1, l11;
insb   : mib, lib, qbd2, l32, sb2, l31, qbf, l2, qbd1, l12, sb1, l11;
hsupia : insa, dispi;
hsupca : dispc, -insa;
hsupib : insb, dispi;
hsupcb : dispc, -insb;
supa   : hsupia, hsupca;
supab  : hsupia, hsupcb;
supba  : hsupib, hsupca;
anelab : supab, supba, nper=10;
ring   : supa, nper=20;

{c:\users\streun\opadat\repository\sirius_v200_ac20_1.opa}
