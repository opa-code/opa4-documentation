{..\nsrrc\opa_4-0-51\tpsii-hoa-bvb-2s4sh\tpsii-hoa-bvb-2s4sh_error_v5.opa}


energy = 3.000000;
rotinv = 0;
    betax   = 15.9128495; alphax  = 0.0000000;
    etax    = -0.0000002; etaxp   = 0.0000000;
    betay   = 6.9809086; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- variables ---------------------------------------------------}

fixedpoint_v  = 3;
the1          = 0.0949;
the2          = -0.1681;
qsfac         = 0;
lqs           = 0.05;

{----- table of elements ---------------------------------------------}

da1     : drift, l = 0.070000, ax = 10.00, ay = 10.00;
db1u    : drift, l = 0.330000, ax = 10.00, ay = 10.00;
db1     : drift, l = 0.20-lqs, ax = 10.00, ay = 10.00;
da2     : drift, l = 0.050000, ax = 10.00, ay = 10.00;
db2     : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dma3    : drift, l = 0.0950-lqs, ax = 10.00, ay = 10.00;
dma3l   : drift, l = 0.225000, ax = 10.00, ay = 10.00;
dmb3    : drift, l = 0.070000, ax = 10.00, ay = 10.00;
dms     : drift, l = 0.050000, ax = 10.00, ay = 10.00;
dqa1    : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dqb1    : drift, l = 0.200000, ax = 10.00, ay = 10.00;
dqa2    : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dqb2    : drift, l = 0.200000, ax = 10.00, ay = 10.00;
dqa3    : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dqb3    : drift, l = 0.200000, ax = 10.00, ay = 10.00;
dqa4    : drift, l = 0.100000, ax = 10.00, ay = 10.00;
sss     : drift, l = 2.975000, ax = 10.00, ay = 10.00;
dqla1   : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dqlb1   : drift, l = 0.200000, ax = 10.00, ay = 10.00;
dqla2   : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dqlb2   : drift, l = 0.200000, ax = 10.00, ay = 10.00;
dqla3   : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dqlb3   : drift, l = 0.200000, ax = 10.00, ay = 10.00;
dqla4   : drift, l = 0.100000, ax = 10.00, ay = 10.00;
dx      : drift, l = 0.050000, ax = 10.00, ay = 10.00;
dxbc    : drift, l = 0.050000, ax = 10.00, ay = 10.00;
dxbpm   : drift, l = 0.050000, ax = 10.00, ay = 10.00;
dxqc    : drift, l = 0.22-lqs, ax = 10.00, ay = 10.00;
ssl     : drift, l = 3.035000, ax = 10.00, ay = 10.00;
dbpm    : drift, l = 0.015000, block, ax = 10.00, ay = 10.00;

center  : marker, ax = 10.00, ay = 10.00;

csu     : quadrupole, l = lqs, k = -0.5000*qsfac, rot = 45.0000, ax = 10.00,
          ay = 10.00;
cso     : quadrupole, l = lqs, k = -0.50000*qsfac, rot = 45.0000, ax = 10.00,
          ay = 10.00;
qs1     : quadrupole, l = 0.200000, k = 7.063707, ax = 10.00, ay = 10.00;
qs2     : quadrupole, l = 0.200000, k = -4.609448, ax = 10.00, ay = 10.00;
qs3     : quadrupole, l = 0.200000, k = -1.813021, ax = 10.00, ay = 10.00;
qs4     : quadrupole, l = 0.200000, k = 2.881971, ax = 10.00, ay = 10.00;
ql1     : quadrupole, l = 0.200000, k = 5.000000, ax = 10.00, ay = 10.00;
ql2     : quadrupole, l = 0.200000, k = -1.166400, ax = 10.00, ay = 10.00;
ql3     : quadrupole, l = 0.200000, k = -4.148889, ax = 10.00, ay = 10.00;
ql4     : quadrupole, l = 0.200000, k = 3.403843, ax = 10.00, ay = 10.00;

nb      : bending, l = 0.390000, t = 1.380000+the1, k = 0.000000,
          t1 = 0.000000, t2 = 1.380000+the1, ax = 10.00, ay = 10.00;
nbm     : bending, l = 0.520000, t = 1.798334-the2, k = 0.000000,
          t1 = 0.000000, t2 = 0.000000, ax = 10.00, ay = 10.00;

sfh     : sextupole, l = 0.050000, k = 334.582257, n = 2, ax = 10.00,
          ay = 10.00;
sd      : sextupole, l = 0.100000, k = -273.256706, n = 4, ax = 10.00,
          ay = 10.00;
sh1     : sextupole, l = 0.100000, k = 110.747857, n = 4, ax = 10.00,
          ay = 10.00;
sh2     : sextupole, l = 0.100000, k = -147.900038, n = 4, ax = 10.00,
          ay = 10.00;
sh3     : sextupole, l = 0.100000, k = -88.274247, n = 4, ax = 10.00,
          ay = 10.00;
sh4     : sextupole, l = 0.100000, k = 117.162459, n = 4, ax = 10.00,
          ay = 10.00;

4bacom  : opticsmarker, betax = 5.804890, alphax = 0.000000, betay = 2.587680,
          alphay = 0.000000, etax  = 0.053159, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 10.00, ay = 10.00;
4badsom : opticsmarker, betax = 0.867558, alphax = -1.686156, betay = 6.711253,
          alphay = 1.149916, etax  = 0.000000, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 10.00, ay = 10.00;
ssom    : opticsmarker, betax = 8.616400, alphax = -0.000003, betay = 2.782130,
          alphay = 0.000000, etax  = 0.000000, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 10.00, ay = 10.00;
5bacom  : opticsmarker, betax = 0.390245, alphax = 0.000000, betay = 7.140800,
          alphay = 0.000000, etax  = 0.012065, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 10.00, ay = 10.00;
5badsom : opticsmarker, betax = 0.867557, alphax = -1.686153, betay = 6.711260,
          alphay = 1.149916, etax  = 0.000000, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 10.00, ay = 10.00;
lsom    : opticsmarker, betax = 15.912800, alphax = -0.000003,
          betay = 6.980910, alphay = 0.000003, etax  = 0.000000,
          etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 10.00,
          ay = 10.00;

vb      : combined, l = 0.160000, t = 0.700000-the1, k = -3.947000,
          t1 = -1.380000-the1, t2 = 2.080000, ax = 10.00, ay = 10.00;
br_r    : combined, l = 0.080000, t = -0.13/2, k = 5.710000, t1 = 0.000000,
          t2 = -0.13/2, ax = 10.00, ay = 10.00;
brm_r   : combined, l = 0.110000, t = -0.13/1.5, k = 5.372582, t1 = 0.000000,
          t2 = -0.13/1.5, ax = 10.00, ay = 10.00;
vbm     : combined, l = 0.220000, t = 1.000000+the2, k = -4.203423,
          t1 = 0.000000, t2 = 0.000000, ax = 10.00, ay = 10.00;

mon     : monitor, ax = 10.00, ay = 10.00;

ch      : h-corrector, ax = 10.00, ay = 10.00;

cv      : v-corrector, ax = 10.00, ay = 10.00;


{----- table of segments ---------------------------------------------}

bpm           : dbpm, mon, dbpm;
b             : nb, dx, vb;
sf            : sfh, sfh;
sy            : sd;
br            : -br_r, br_r;
brm           : -brm_r, brm_r;
bm            : vbm, dx, nbm;
qcu           : cv, csu, ch;
qco           : cv, cso, ch;
bqc           : dxbpm, bpm, dxbc, qcu;
dout          : bpm, dxbc, qco;
dh1           : dxbpm, bpm, dxbc, qco, dxqc;
4bacellr      : 4bacom, sfh, db2, br, bqc, db1, sy, da1, -b, b, da1, sy, db1u,
                br, db2, sfh;
4badsupr      : 4bacellr, sfh, db2, brm, bqc, dma3, sy, dmb3, bm, 4badsom;
4basbetamat   : 4badsom, dh1, sh1, dqa1, qs1, dqb1, sh2, dqa2, qs2, dqb2, sh3,
                dqa3, qs3, dqb3, sh4, dqa4, qs4, dxbpm, dout, sss;
4baharcr      : 4badsupr, 4basbetamat, ssom;
4bacelll      : sfh, db2, br, bqc, db1, sy, da1, -b, b, da1, sy, db1u, br, db2,
                sfh;
4badcell      : 4bacelll, 4bacellr;
4badsupl      : 4badsom, -bm, dmb3, sy, dma3l, brm, db2, sfh, 4bacelll;
4basbetamatl  : ssom, sss, dout, dxbpm, qs4, dqa4, sh4, dqb3, qs3, dqa3, sh3,
                dqb2, qs2, dqa2, sh2, dqb1, qs1, dqa1, sh1, dh1;
4baharcl      : 4basbetamatl, 4badsupl;
4baarc        : 4baharcl, 4baharcr;
5bacellr      : 5bacom, b, da1, sy, db1u, br, db2, sf, db2, br, bqc, db1, sy,
                da1, -b, 5bacom;
5badsupr      : 5bacellr, b, da1, sy, db1u, br, db2, sf, db2, brm, bqc, dma3,
                sy, dmb3, bm, 5badsom;
5balbetamatr  : 5badsom, dh1, sh1, dqla1, ql1, dqlb1, sh2, dqla2, ql2, dqlb2,
                sh3, dqla3, ql3, dqlb3, sh4, dqla4, ql4, dxbpm, dout, ssl,
                lsom;
5balbetamatrs : lsom, ssl, dout, dxbpm, ql4, dqla4, sh4, dqlb3, ql3, dqla3,
                sh3, dqlb2, ql2, dqla2, sh2, dqlb1, ql1, dqla1, sh1, dh1,
                5badsom;
5balharc      : 5badsupr, 5balbetamatr;
5bacelll      : 5bacom, b, da1, sy, db1u, br, db2, sf, db2, br, bqc, db1, sy,
                da1, -b, 5bacom;
5badcell      : 5bacelll, 5bacellr;
5badsupl      : 5badsom, -bm, dmb3, sy, dma3l, brm, db2, sf, db2, br, bqc, db1,
                sy, da1, -b, 5bacom;
5basbetamat   : 4basbetamatl;
5basbetamats  : dh1, sh1, dqa1, qs1, dqb1, sh2, dqa2, qs2, dqb2, sh3, dqa3,
                qs3, dqb3, sh4, dqa4, qs4, dxbpm, dout, sss;
5basharc      : 5basbetamat, 5badsupl, 5bacelll;
5baarc        : ssom, 5basharc, 5bacom, 5balharc, lsom;
5baarcu       : lsom, 5balbetamatrs, 5badsupl, 5bacellr, 5badsupr,
                5basbetamats, ssom;
hsuper        : ssom, 4baarc, ssom, 5baarc, lsom;
super         : 5baarcu, 4baarc, 4baarc, 5baarc, center;
superunit     : super, nper=6;
ring          : 6*super;

{..\nsrrc\opa_4-0-51\tpsii-hoa-bvb-2s4sh\tpsii-hoa-bvb-2s4sh_error_v5.opa}
