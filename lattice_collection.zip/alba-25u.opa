{c:\users\streun\opadat\repository\alba-25u-mod.opa}


energy = 3.000000;

    betax   = 11.1937483; alphax  = 0.0000000;
    etax    = 0.1461745; etaxp   = 0.0000000;
    betay   = 5.9313884; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

smod : drift, l = 0.200000, ax = 50.00, ay = 50.00;
lmod : drift, l = 2.485000, ax = 50.00, ay = 50.00;
l_id : drift, l = 3.985000, ax = 50.00, ay = 50.00;
lm1  : drift, l = 2.985000, ax = 50.00, ay = 50.00;
d11  : drift, l = 0.170000, ax = 50.00, ay = 50.00;
d12  : drift, l = 0.150000, ax = 50.00, ay = 50.00;
d13  : drift, l = 0.150000, ax = 50.00, ay = 50.00;
d14  : drift, l = 0.375000, ax = 50.00, ay = 50.00;
d15  : drift, l = 0.260000, ax = 50.00, ay = 50.00;
d21  : drift, l = 0.260000, ax = 50.00, ay = 50.00;
d22  : drift, l = 0.150000, ax = 50.00, ay = 50.00;
d23  : drift, l = 0.375000, ax = 50.00, ay = 50.00;
d24  : drift, l = 0.150000, ax = 50.00, ay = 50.00;
d25  : drift, l = 0.165000, ax = 50.00, ay = 50.00;
d26  : drift, l = 0.470000, ax = 50.00, ay = 50.00;
d28  : drift, l = 0.260000, ax = 50.00, ay = 50.00;
d31  : drift, l = 0.260000, ax = 50.00, ay = 50.00;
d32  : drift, l = 0.370000, ax = 50.00, ay = 50.00;
d33  : drift, l = 0.175000, ax = 50.00, ay = 50.00;
d34  : drift, l = 0.150000, ax = 50.00, ay = 50.00;
m_id : drift, l = 2.096767, ax = 50.00, ay = 50.00;
d41  : drift, l = 0.260000, ax = 50.00, ay = 50.00;
d42  : drift, l = 0.540000, ax = 50.00, ay = 50.00;
d43  : drift, l = 0.165000, ax = 50.00, ay = 50.00;
s_id : drift, l = 1.300000, ax = 50.00, ay = 50.00;
ds1  : drift, l = 0.075000, ax = 50.00, ay = 50.00;
ds2  : drift, l = 0.110000, ax = 50.00, ay = 50.00;

qd1  : quadrupole, l = 0.230000, k = -1.773389, ax = 50.00, ay = 50.00;
qf1  : quadrupole, l = 0.290000, k = 1.511189, ax = 50.00, ay = 50.00;
qf2  : quadrupole, l = 0.290000, k = 1.901567, ax = 50.00, ay = 50.00;
qf3  : quadrupole, l = 0.290000, k = 1.549700, ax = 50.00, ay = 50.00;
qf4  : quadrupole, l = 0.230000, k = 1.492441, ax = 50.00, ay = 50.00;
qf5  : quadrupole, l = 0.310000, k = 1.794343, ax = 50.00, ay = 50.00;
qf6  : quadrupole, l = 0.530000, k = 2.078492, ax = 50.00, ay = 50.00;
qd2  : quadrupole, l = 0.290000, k = -1.877886, ax = 50.00, ay = 50.00;
qd3  : quadrupole, l = 0.290000, k = -1.849889, ax = 50.00, ay = 50.00;
qf7  : quadrupole, l = 0.530000, k = 2.028150, ax = 50.00, ay = 50.00;
qf8  : quadrupole, l = 0.310000, k = 2.008579, ax = 50.00, ay = 50.00;

be   : bending, l = 1.383700, t = 11.250000, k = -0.565620,
       t1 = 5.625000, t2 = 5.625000, ax = 50.00, ay = 50.00;
blm  : bending, l = 0.500000, t = -5.000000, k = 0.000000, t1 = 0.000000,
       t2 = -5.000000, ax = 50.00, ay = 50.00;
blp  : bending, l = 0.500000, t = 5.000000, k = 0.000000, t1 = 5.000000,
       t2 = 0.000000, ax = 50.00, ay = 50.00;

sf10 : sextupole, l = 0.000000, k = 1.465118, n = 1, ax = 50.00, ay = 50.00;
sd10 : sextupole, l = 0.000000, k = -2.371834, n = 1, ax = 50.00, ay = 50.00;
sd20 : sextupole, l = 0.000000, k = -3.497181, n = 1, ax = 50.00, ay = 50.00;
sf20 : sextupole, l = 0.000000, k = 5.961393, n = 1, ax = 50.00, ay = 50.00;
sd30 : sextupole, l = 0.000000, k = -5.902736, n = 1, ax = 50.00, ay = 50.00;
sd40 : sextupole, l = 0.000000, k = -5.958194, n = 1, ax = 50.00, ay = 50.00;
sf30 : sextupole, l = 0.000000, k = 5.776717, n = 1, ax = 50.00, ay = 50.00;
sd50 : sextupole, l = 0.000000, k = -4.442036, n = 1, ax = 50.00, ay = 50.00;
sf40 : sextupole, l = 0.000000, k = 6.893099, n = 1, ax = 50.00, ay = 50.00;

mod  : undulator, l = 3.000000, lamb = 0.166667, bmax = 1.650000,
       f1 = 0.636620, f2 = 0.500000, f3 = 0.424410, gap = 12.000, ax = 50.00,
       ay = 50.00;
mod2 : undulator, l = 2.200000, lamb = 0.122200, bmax = 2.630000,
       f1 = 0.636620, f2 = 0.500000, f3 = 0.424410, gap = 12.000, ax = 50.00,
       ay = 50.00;

ol1  : opticsmarker, betax = 11.196600, alphax = 0.000000,
       betay = 5.928690, alphay = 0.000000, etax  = 0.000000,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
       ay = 50.00;
om1  : opticsmarker, betax = 1.995500, alphax = -0.000005,
       betay = 1.306460, alphay = 0.000041, etax  = 0.000000,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
       ay = 50.00;
om2  : opticsmarker, betax = 1.995520, alphax = 0.000000,
       betay = 1.306410, alphay = 0.000000, etax  = 0.000000,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
       ay = 50.00;
om3  : opticsmarker, betax = 1.995500, alphax = 0.000005,
       betay = 1.306460, alphay = -0.000041, etax  = 0.000000,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
       ay = 50.00;
os1  : opticsmarker, betax = 8.686560, alphax = -0.000006,
       betay = 5.146100, alphay = -0.000027, etax  = 0.000000,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
       ay = 50.00;
os2  : opticsmarker, betax = 8.686560, alphax = 0.000006,
       betay = 5.146100, alphay = 0.000027, etax  = 0.000000,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
       ay = 50.00;


{----- table of segments ----------------------------------------------------}

lbl     : blm, lm1, blp;
sf1     : ds1, sf10, ds1;
sd1     : ds1, sd10, ds1;
sd2     : ds1, sd20, ds1;
sf2     : ds2, sf20, ds2;
sd3     : ds1, sd30, ds1;
sd4     : ds2, sd40, ds2;
sf3     : ds2, sf30, ds2;
sd5     : ds1, sd50, ds1;
sf4     : ds1, sf40, ds1;
block1  : qd1, d11, qf1, d12, sf1, d13, qf2, d14, sd1, d15;
block2  : d21, sd2, d22, qf3, d23, qf4, d24, sf2, d25, qf5, d26, sd3, d28;
block31 : d31, sd4, d32, qf6, d33, sf3, d34, qd2, m_id;
block32 : m_id, qd3, d34, sf3, d33, qf7, d32, sd4, d31;
block4  : d41, sd5, d42, qf8, d43, sf4, s_id;
block4s : d41, sd5, d42, qf8, d43, ds1, ds1, s_id;
oct     : block1, be, block2, be, block31, block32, be, block4,
          -block4s, be, -block32;
ring    : l_id, oct, -oct, l_id, nper=4;

{c:\users\streun\opadat\repository\alba-25u-mod.opa}
