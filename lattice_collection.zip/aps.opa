{c:\users\streun\opadat\repository\aps.opa}


energy = 7.000000;

    betax   = 19.4871209; alphax  = 0.0000000;
    etax    = 0.1718668; etaxp   = 0.0000000;
    betay   = 2.9251114; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d1   : drift, l = 2.956000, ax = 50.00, ay = 50.00;
d2   : drift, l = 0.247250, ax = 50.00, ay = 50.00;
d3   : drift, l = 0.667050, ax = 50.00, ay = 50.00;
d4   : drift, l = 0.177450, ax = 50.00, ay = 50.00;
d5   : drift, l = 0.176900, ax = 50.00, ay = 50.00;
d6   : drift, l = 0.836900, ax = 50.00, ay = 50.00;
d7   : drift, l = 0.225810, ax = 50.00, ay = 50.00;
d8   : drift, l = 0.225810, ax = 50.00, ay = 50.00;
d9   : drift, l = 0.788650, ax = 50.00, ay = 50.00;
d10  : drift, l = 0.359250, ax = 50.00, ay = 50.00;
d11  : drift, l = 0.177900, ax = 50.00, ay = 50.00;

q1   : quadrupole, l = 0.493500, k = -0.409254, ax = 50.00, ay = 50.00;
q2   : quadrupole, l = 0.792400, k = 0.710778, ax = 50.00, ay = 50.00;
q3   : quadrupole, l = 0.493500, k = -0.690066, ax = 50.00, ay = 50.00;
q4   : quadrupole, l = 0.490000, k = -0.740295, ax = 50.00, ay = 50.00;
q5   : quadrupole, l = 0.591500, k = 0.744954, ax = 50.00, ay = 50.00;

hv1a : bending, l = 0.160000, t = 0.057300, k = 0.000000, t1 = 0.057300,
       t2 = 0.000000, ax = 50.00, ay = 50.00;
hv1b : bending, l = 0.160000, t = 0.057300, k = 0.000000, t1 = 0.000000,
       t2 = 0.057300, ax = 50.00, ay = 50.00;
m    : bending, l = 3.055680, t = 4.442700, k = 0.000000, t1 = 2.221350,
       t2 = 2.221350, gap = 60.0000, k1 = 0.5000, ax = 50.00, ay = 50.00;

s1   : sextupole, l = 0.252700, k = 5.125000, n = 3, ax = 50.00, ay = 50.00;
s2   : sextupole, l = 0.252700, k = -12.625000, n = 3, ax = 50.00,
       ay = 50.00;
s3   : sextupole, l = 0.252700, k = -7.900000, n = 3, ax = 50.00, ay = 50.00;
s4   : sextupole, l = 0.252700, k = 8.582000, n = 3, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

ring : d1, hv1a, d2, q1, d3, q2, d4, s1, d5, q3, d6, s2, d7, m, d8, s3,
       d9, q4, d10, q5, d11, s4, d11, q5, d10, q4, d9, s3, d8, m, d7, s2, d6,
       q3, d5, s1, d4, q2, d3, q1, d2, hv1b, d1, nper=40;

{c:\users\streun\opadat\repository\aps.opa}
