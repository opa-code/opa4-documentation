{c:\users\streun\opadat\repository\aurora.opa}
{com one single 360 bend lattice - split in two to get correct tunes com}


energy = 0.650000;

    betax   = 0.5976144; alphax  = 0.0000000;
    etax    = 0.7142859; etaxp   = 0.0000000;
    betay   = 0.9128709; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

b : bending, l = 1.570796, t = 180.000000, k = -1.200000, t1 = 0.000000,
    t2 = 0.000000, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

ring : 2*b;

{c:\users\streun\opadat\repository\aurora.opa}
