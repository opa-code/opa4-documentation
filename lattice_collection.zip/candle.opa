{c:\users\streun\opadat\repository\candle.opa}


energy = 3.000000;

    betax   = 9.3663819; alphax  = 0.0000000;
    etax    = 0.0003551; etaxp   = 0.0000000;
    betay   = 2.4504930; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d1   : drift, l = 2.698300, ax = 50.00, ay = 50.00;
d2   : drift, l = 0.190000, ax = 50.00, ay = 50.00;
d3   : drift, l = 0.165000, ax = 50.00, ay = 50.00;
d4   : drift, l = 0.275000, ax = 50.00, ay = 50.00;
d5   : drift, l = 0.155000, ax = 50.00, ay = 50.00;
d6   : drift, l = 0.450000, ax = 50.00, ay = 50.00;

qfa  : quadrupole, l = 0.355000, k = 1.762730, ax = 50.00, ay = 50.00;
qda  : quadrupole, l = 0.180000, k = -1.062770, ax = 50.00, ay = 50.00;
qfb  : quadrupole, l = 0.355000, k = 1.539930, ax = 50.00, ay = 50.00;

sfa  : sextupole, l = 0.200000, k = 14.000000, n = 1, ax = 50.00, ay = 50.00;
sda  : sextupole, l = 0.200000, k = -15.000000, n = 1, ax = 50.00,
       ay = 50.00;
sdb  : sextupole, l = 0.200000, k = -8.355902, n = 1, ax = 50.00, ay = 50.00;
sfb  : sextupole, l = 0.100000, k = 8.054672, n = 1, ax = 50.00, ay = 50.00;

bend : combined, l = 1.725800, t = 12.857140, k = -0.329030,
       t1 = 8.493300, t2 = 8.493300, gap = 40.0000, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

halfcell : d1, sfa, d2, qfa, d3, sda, d4, bend, d4, sdb, d5, qda, d6,
           qfb, d2, sfb;
cell     : halfcell, -halfcell;
ring     : cell, nper=14;

{c:\users\streun\opadat\repository\candle.opa}
