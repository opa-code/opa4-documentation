{c:\users\streun\opadat\repository\clicdr1.opa}


energy = 2.860000;

    betax   = 9.5259125; alphax  = 0.0000196;
    etax    = -0.0002882; etaxp   = -0.0000224;
    betay   = 3.4473638; alphay  = 0.0153158;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d1         : drift, l = 0.080000, ax = 50.00, ay = 50.00;
d2         : drift, l = 0.080000, ax = 50.00, ay = 50.00;
d3         : drift, l = 0.080000, ax = 50.00, ay = 50.00;
d4         : drift, l = 0.100000, ax = 50.00, ay = 50.00;
wd0        : drift, l = 2.150000, ax = 50.00, ay = 50.00;
wd01       : drift, l = 1.075000, ax = 50.00, ay = 50.00;
wd02       : drift, l = 1.075000, ax = 50.00, ay = 50.00;
wd1        : drift, l = 0.600000, ax = 50.00, ay = 50.00;
wd2        : drift, l = 0.200000, ax = 50.00, ay = 50.00;
dm1        : drift, l = 0.310000, ax = 50.00, ay = 50.00;
dm2        : drift, l = 0.080000, ax = 50.00, ay = 50.00;
dm3        : drift, l = 0.350000, ax = 50.00, ay = 50.00;
dm4        : drift, l = 0.350000, ax = 50.00, ay = 50.00;
sm1        : drift, l = 0.150000, ax = 50.00, ay = 50.00;
d01        : drift, l = 0.200000, ax = 50.00, ay = 50.00;
d02        : drift, l = 0.200000, ax = 50.00, ay = 50.00;
d03        : drift, l = 0.200000, ax = 50.00, ay = 50.00;

mh2        : marker, ax = 50.00, ay = 50.00;
mrf        : marker, ax = 50.00, ay = 50.00;
minj       : marker, ax = 50.00, ay = 50.00;
mextr      : marker, ax = 50.00, ay = 50.00;
girdarc    : marker, ax = 50.00, ay = 50.00;
girdlss    : marker, ax = 50.00, ay = 50.00;
girdds     : marker, ax = 50.00, ay = 50.00;

gqf1       : quadrupole, l = 0.200000, k = -3.566840, ax = 50.00, ay = 50.00;
gqf2       : quadrupole, l = 0.200000, k = 6.967500, ax = 50.00, ay = 50.00;
qfw1       : quadrupole, l = 0.100000, k = 1.552612, ax = 50.00, ay = 50.00;
qdw1       : quadrupole, l = 0.100000, k = -1.301643, ax = 50.00, ay = 50.00;
gqf1ds     : quadrupole, l = 0.200000, k = -5.269692, ax = 50.00, ay = 50.00;
gqf2ds     : quadrupole, l = 0.200000, k = 6.350409, ax = 50.00, ay = 50.00;
qfw0       : quadrupole, l = 0.100000, k = 8.147307, ax = 50.00, ay = 50.00;
qdw0       : quadrupole, l = 0.100000, k = -4.865459, ax = 50.00, ay = 50.00;
qm1        : quadrupole, l = 0.200000, k = 8.269792, ax = 50.00, ay = 50.00;
qm31       : quadrupole, l = 0.305000, k = 6.105705, ax = 50.00, ay = 50.00;
qm41       : quadrupole, l = 0.305000, k = -8.677913, ax = 50.00, ay = 50.00;
gqf1ds2    : quadrupole, l = 0.200000, k = -4.468119, ax = 50.00, ay = 50.00;
gqf2ds2    : quadrupole, l = 0.200000, k = 5.707543, ax = 50.00, ay = 50.00;
qfw02      : quadrupole, l = 0.100000, k = 2.880540, ax = 50.00, ay = 50.00;
qdw02      : quadrupole, l = 0.100000, k = 1.764676, ax = 50.00, ay = 50.00;
qm12       : quadrupole, l = 0.200000, k = 8.507341, ax = 50.00, ay = 50.00;
qm312      : quadrupole, l = 0.300000, k = 10.520630, ax = 50.00, ay = 50.00;
qm412      : quadrupole, l = 0.300000, k = -7.289307, ax = 50.00, ay = 50.00;

gtmel      : bending, l = 0.290000, t = 1.800000, k = -1.100000,
             t1 = 1.800000, t2 = 0.000000, ax = 50.00, ay = 50.00;
gtmer      : bending, l = 0.290000, t = 1.800000, k = -1.100000,
             t1 = 0.000000, t2 = 1.800000, ax = 50.00, ay = 50.00;
gtmelds    : bending, l = 0.290000, t = 1.800000, k = 0.000000,
             t1 = 1.800000, t2 = 0.000000, ax = 50.00, ay = 50.00;
gtmerds    : bending, l = 0.290000, t = 1.800000, k = 0.000000,
             t1 = 0.000000, t2 = 1.800000, ax = 50.00, ay = 50.00;

s2x2       : sextupole, l = 0.150000, k = 100.000000, n = 1,
             ax = 50.00, ay = 50.00;
s2y1       : sextupole, l = 0.075000, k = -100.000000, n = 1,
             ax = 50.00, ay = 50.00;

wigglersin : undulator, l = 2.000000, lamb = 0.050000,
             bmax = 2.500000, f1 = 0.636620, f2 = 0.500000, f3 = 0.424413,
             gap = 1000.000, ax = 50.00, ay = 50.00;

mh1        : opticsmarker, betax = 0.167285, alphax = 0.000000,
             betay = 8.509100, alphay = 0.000000, etax  = 0.005567,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000,
             ax = 50.00, ay = 50.00;
mh3        : opticsmarker, betax = 9.525380, alphax = 0.000091,
             betay = 3.447320, alphay = 0.015317, etax  = -0.000166,
             etaxp  = -0.000019, etay  = 0.000000, etayp  = 0.000000,
             ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

tme      : gtmer, d1, s2x2, d2, gqf1, d3, gqf2, d4, s2y1, s2y1, d4,
           gqf2, d3, gqf1, d2, s2x2, d1, gtmel;
tme3     : gtmer, girdarc, d1, s2x2, d2, gqf1, d3, gqf2, d4, s2y1,
           s2y1, d4, gqf2, d3, gqf1, d2, s2x2, d1, gtmel, gtmer, d1, s2x2, d2,
           gqf1, d3, gqf2, d4, s2y1, s2y1, d4, gqf2, d3, gqf1, d2, s2x2, d1,
           gtmel, gtmer, d1, s2x2, d2, gqf1, d3, gqf2, d4, s2y1, s2y1, d4,
           gqf2, d3, gqf1, d2, s2x2, d1, gtmel;
tme315   : 15*tme3;
arc      : tme, tme315, girdarc, tme;
marc     : mh1, arc;
fodow    : qfw1, girdlss, wd1, wigglersin, wd2, girdlss, qdw1, qdw1,
           girdlss, wd1, wigglersin, wd2, girdlss, qfw1;
straight : 13*fodow;
disp22   : mh3, qfw1, girdds, wd01, mrf, wd02, qdw02, qdw02, wd0,
           qfw02, qfw02, d03, qm412, d02, qm312, d01, mh2, gtmelds, gtmerds,
           dm3, qm12, dm4, gqf2ds2, d3, gqf1ds2, d2, sm1, d1, girdds, gtmel,
           mh1;
disp11   : mh1, gtmer, girdds, d1, sm1, d2, gqf1ds, d3, gqf2ds, dm4,
           qm1, dm3, gtmelds, gtmerds, mh2, d01, qm31, d02, qm41, d03, qfw0,
           qfw0, wd0, qdw0, qdw0, wd0, girdds, qfw1, mh3;
half0    : straight, disp22, arc;
half1    : -mh1, disp11, -mh3;
half     : half0, half1;
ring     : straight, disp22, arc, disp11, straight, disp22, arc, disp11;

{c:\users\streun\opadat\repository\clicdr1.opa}
