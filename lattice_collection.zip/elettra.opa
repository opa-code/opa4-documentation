{c:\users\streun\opadat\elettra\elettra2.opa}
{com elettra (sync data booklet 4) com}


energy = 2.000000;

    betax   = 8.1690703; alphax  = 0.0000000;
    etax    = 0.0000828; etaxp   = 0.0000000;
    betay   = 2.6005116; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d1  : drift, l = 0.311600, ax = 100.00, ay = 100.00;
d2  : drift, l = 0.281000, ax = 100.00, ay = 100.00;
d3  : drift, l = 0.340000, ax = 100.00, ay = 100.00;
d4  : drift, l = 0.251000, ax = 100.00, ay = 100.00;
d5  : drift, l = 0.507000, ax = 100.00, ay = 100.00;
d6  : drift, l = 0.472500, ax = 100.00, ay = 100.00;
d7  : drift, l = 0.375500, ax = 100.00, ay = 100.00;
d8  : drift, l = 0.207400, ax = 100.00, ay = 100.00;
d9  : drift, l = 0.370000, ax = 100.00, ay = 100.00;

q1  : quadrupole, l = 0.260000, k = -1.952436, ax = 100.00, ay = 100.00;
q2  : quadrupole, l = 0.498000, k = 2.235991, ax = 100.00, ay = 100.00;
q3  : quadrupole, l = 0.260000, k = -1.277189, ax = 100.00, ay = 100.00;
q4  : quadrupole, l = 0.409000, k = 2.227470, ax = 100.00, ay = 100.00;
q5  : quadrupole, l = 0.130000, k = -1.400000, ax = 100.00, ay = 100.00;

b49 : bending, l = 0.647111, t = 6.666670, k = -0.430418, t1 = 7.500000,
      t2 = 0.000000, ax = 50.00, ay = 50.00;
b59 : bending, l = 0.808889, t = 8.333330, k = -0.430418, t1 = 0.000000,
      t2 = 7.500000, ax = 50.00, ay = 50.00;
bdh : bending, l = 0.728000, t = 7.500000, k = -0.430418, t1 = 7.500000,
      t2 = 0.000000, ax = 100.00, ay = 100.00;

sd  : sextupole, l = 0.000000, k = -3.611657, n = 1, ax = 100.00,
      ay = 100.00;
sf  : sextupole, l = 0.000000, k = 4.203128, n = 1, ax = 100.00, ay = 100.00;
s1  : sextupole, l = 0.000000, k = 1.100000, n = 1, ax = 100.00, ay = 100.00;


{----- table of segments ----------------------------------------------------}

hsup : 10*d1, q1, d2, s1, d3, q2, d4, q3, d5, b49, b59, d6, q4, d7, sf,
       10*d8, sd, d9, q5;
fsup : hsup, -hsup;
ring : fsup, nper=12;

{c:\users\streun\opadat\elettra\elettra2.opa}
