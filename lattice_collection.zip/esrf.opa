{c:\users\streun\opadat\repository\esrf.opa}


energy = 6.000000;

    betax   = 21.0401209; alphax  = 0.0000000;
    etax    = 0.0022774; etaxp   = 0.0000000;
    betay   = 12.4335567; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d1   : drift, l = 0.288145, ax = 50.00, ay = 50.00;
d2   : drift, l = 0.175000, ax = 50.00, ay = 50.00;
d3   : drift, l = 0.200000, ax = 50.00, ay = 50.00;
d4   : drift, l = 0.268062, ax = 50.00, ay = 50.00;
d5   : drift, l = 0.267937, ax = 50.00, ay = 50.00;
d6   : drift, l = 0.215000, ax = 50.00, ay = 50.00;
d7   : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dbb  : drift, l = 0.000000, ax = 50.00, ay = 50.00;

mark : marker, ax = 50.00, ay = 50.00;

qd1  : quadrupole, l = 0.200000, k = -0.319699, ax = 50.00, ay = 50.00;
qd2  : quadrupole, l = 0.250000, k = -0.529670, ax = 50.00, ay = 50.00;
qd3  : quadrupole, l = 0.200000, k = -0.693040, ax = 50.00, ay = 50.00;
qd4  : quadrupole, l = 0.250000, k = -0.770779, ax = 50.00, ay = 50.00;
qd5  : quadrupole, l = 0.200000, k = -0.547108, ax = 50.00, ay = 50.00;
qf1  : quadrupole, l = 0.300000, k = 0.522749, ax = 50.00, ay = 50.00;
qf2  : quadrupole, l = 0.250000, k = 0.759003, ax = 50.00, ay = 50.00;
qf3  : quadrupole, l = 0.300000, k = 0.810015, ax = 50.00, ay = 50.00;

b1i  : bending, l = 0.215728, t = 0.528980, k = 0.000000, t1 = 0.049090,
       t2 = 0.000000, ax = 50.00, ay = 50.00;
b1o  : bending, l = 0.215728, t = 0.528980, k = 0.000000, t1 = 0.000000,
       t2 = 0.043240, ax = 50.00, ay = 50.00;
b1m  : bending, l = 0.215728, t = 0.528980, k = 0.000000, t1 = 0.000000,
       t2 = 0.000000, ax = 50.00, ay = 50.00;
b2   : bending, l = 0.292710, t = 0.335180, k = 0.000000, t1 = -0.043240,
       t2 = 0.049090, ax = 50.00, ay = 50.00;

s1   : sextupole, l = 0.000000, k = 1.993402, n = 1, ax = 50.00, ay = 50.00;
s2   : sextupole, l = 0.000000, k = -2.168515, n = 1, ax = 50.00, ay = 50.00;
s3   : sextupole, l = 0.000000, k = -1.567120, n = 1, ax = 50.00, ay = 50.00;
s4   : sextupole, l = 0.000000, k = 2.595590, n = 1, ax = 50.00, ay = 50.00;
sd   : sextupole, l = 0.000000, k = -1.857434, n = 1, ax = 50.00, ay = 50.00;
sf   : sextupole, l = 0.000000, k = 3.298004, n = 1, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

b    : b1i, 8*b1m, b1o, b2;
half : mark, 11*d1, 2*qd1, 2*d2, s1, 2*d2, 3*qf1, 2*d3, s2, 2*d3, 2*qd2,
       4*d4, b, 4*d5, 2*qd3, 2*d2, sd, 2*d6, 2*qf2, 2*d7, sf, 2*d7, 2*qf2,
       2*d6, sd, 2*d2, 2*qd3, 4*d5, -b, 4*d4, 2*qd4, 2*d2, s3, 2*d3, 3*qf3,
       2*d2, s4, 2*d2, 2*qd5, 11*d1;
cell : half, -half, nper=16;
ring : 16*cell;

{c:\users\streun\opadat\repository\esrf.opa}
