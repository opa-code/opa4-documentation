{c:\users\streun\opadat\repository\max4_430bare.opa}


energy = 3.000000;

    betax   = 8.9999970; alphax  = 0.0000000;
    etax    = -0.0000002; etaxp   = 0.0000000;
    betay   = 2.0000013; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

str0500 : drift, l = 0.500000, ax = 11.00, ay = 11.00;
stra500 : drift, l = 0.500000, ax = 10.00, ay = 11.00;
str0420 : drift, l = 0.420000, ax = 11.00, ay = 11.00;
strx403 : drift, l = 0.403110, ax = 11.00, ay = 11.00;
str0377 : drift, l = 0.377000, ax = 11.00, ay = 11.00;
str0355 : drift, l = 0.355000, ax = 11.00, ay = 11.00;
str0321 : drift, l = 0.321000, ax = 11.00, ay = 11.00;
str0302 : drift, l = 0.302000, ax = 11.00, ay = 11.00;
str0280 : drift, l = 0.280000, ax = 11.00, ay = 11.00;
str0270 : drift, l = 0.270000, ax = 11.00, ay = 11.00;
str0269 : drift, l = 0.269000, ax = 11.00, ay = 11.00;
str0252 : drift, l = 0.252000, ax = 11.00, ay = 11.00;
strx203 : drift, l = 0.203110, ax = 11.00, ay = 11.00;
str0150 : drift, l = 0.150000, ax = 11.00, ay = 11.00;
str0100 : drift, l = 0.100000, ax = 11.00, ay = 11.00;
str0098 : drift, l = 0.098000, ax = 11.00, ay = 11.00;
strx093 : drift, l = 0.092680, ax = 11.00, ay = 11.00;
str0075 : drift, l = 0.075000, ax = 11.00, ay = 11.00;
str0058 : drift, l = 0.058000, ax = 11.00, ay = 11.00;
str0050 : drift, l = 0.050000, ax = 11.00, ay = 11.00;
str0025 : drift, l = 0.025000, ax = 11.00, ay = 11.00;
stra025 : drift, l = 0.025000, ax = 10.00, ay = 11.00;
str0021 : drift, l = 0.021000, ax = 11.00, ay = 11.00;
str0020 : drift, l = 0.020000, ax = 11.00, ay = 11.00;
strx013 : drift, l = 0.012500, ax = 11.00, ay = 11.00;
str0010 : drift, l = 0.010000, ax = 11.00, ay = 11.00;
strx006 : drift, l = 0.006080, ax = 11.00, ay = 11.00;

ip      : marker, ax = 11.00, ay = 11.00;
psmc    : marker, ax = 11.00, ay = 11.00;
kic     : marker, ax = 11.00, ay = 11.00;
pvc     : marker, ax = 11.00, ay = 11.00;

qf      : quadrupole, l = 0.150000, k = 4.030076, ax = 11.00, ay = 11.00;
qfm     : quadrupole, l = 0.150000, k = 3.773995, ax = 11.00, ay = 11.00;
qfend   : quadrupole, l = 0.250000, k = 3.653849, ax = 11.00, ay = 11.00;
qdend   : quadrupole, l = 0.250000, k = -2.503663, ax = 11.00, ay = 11.00;

d0      : bending, l = 0.361890, t = 1.094181, k = -0.864858,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
df1     : bending, l = 0.050000, t = 0.151199, k = -0.864908,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
df2     : bending, l = 0.050000, t = 0.151101, k = -0.866059,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
df3     : bending, l = 0.050000, t = 0.101861, k = -0.551829,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
df4     : bending, l = 0.050000, t = 0.001569, k = 0.011759,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
df5     : bending, l = 0.050000, t = 0.000089, k = -0.000128,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds6     : bending, l = 0.050000, t = 0.001070, k = 0.006608,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds5     : bending, l = 0.050000, t = 0.050729, k = -0.271428,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds4     : bending, l = 0.050000, t = 0.074672, k = -0.425119,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds3     : bending, l = 0.050000, t = 0.076248, k = -0.426048,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds2     : bending, l = 0.050000, t = 0.114983, k = -0.584884,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds1     : bending, l = 0.050000, t = 0.152049, k = -0.870351,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
ds0     : bending, l = 0.204240, t = 0.621695, k = -0.870701,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
dm1     : bending, l = 0.050000, t = 0.152220, k = -0.870751,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
dm2     : bending, l = 0.050000, t = 0.152122, k = -0.871910,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
dm3     : bending, l = 0.050000, t = 0.102549, k = -0.555557,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
dm4     : bending, l = 0.050000, t = 0.001579, k = 0.011839,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;
dm5     : bending, l = 0.050000, t = 0.000090, k = -0.000129,
          t1 = 0.000000, t2 = 0.000000, ax = 11.00, ay = 11.00;

sd      : sextupole, l = 0.100000, k = -116.625229, n = 3, ax = 11.00,
          ay = 11.00;
sdend   : sextupole, l = 0.100000, k = -170.000000, n = 3, ax = 11.00,
          ay = 11.00;
sfm     : sextupole, l = 0.100000, k = 170.000000, n = 3, ax = 11.00,
          ay = 11.00;
sfo     : sextupole, l = 0.100000, k = 174.000000, n = 3, ax = 11.00,
          ay = 11.00;
sfi     : sextupole, l = 0.100000, k = 207.412038, n = 3, ax = 11.00,
          ay = 11.00;

oxxo    : multipole, n = 4,  k = -164.85800000, ax = 11.00, ay = 11.00;
oxyo    : multipole, n = 4,  k = 327.01400000, ax = 11.00, ay = 11.00;
oyyo    : multipole, n = 4,  k = -142.02200000, ax = 11.00, ay = 11.00;

mon     : monitor, ax = 11.00, ay = 11.00;

ch      : h-corrector, ax = 11.00, ay = 11.00;

cv      : v-corrector, ax = 11.00, ay = 11.00;


{----- table of segments ----------------------------------------------------}

dip     : df5, df4, df3, df2, df1, d0;
dipm    : ds6, ds5, ds4, ds3, ds2, ds1, ds0, dm1, dm2, dm3, dm4, dm5;
oxx     : str0050, oxxo, str0050;
oxy     : str0050, oxyo, str0050;
oyy     : str0050, oyyo, str0050;
bpm     : str0025, mon, str0025;
corr    : str0025, cv, str0050, ch, str0025;
corrs   : str0025, ch, str0075;
psm     : str0150, psmc, str0150;
ki      : str0150, kic, str0150;
pv      : str0075, pvc, str0075;
sept    : 2*stra500, stra025;
sqfm    : qfm, str0075, sfm, strx013, bpm, strx013, qfm, str0100, corr;
sqfo    : qf, str0075, sfo, strx013, bpm, strx013, qf, str0100, corr;
sqfi    : qf, str0075, sfi, strx013, bpm, strx013, qf, str0100, corr;
dipuc   : sd, str0010, dip, -dip, str0010, sd;
ls      : 4*str0500, str0321;
ls1a    : str0500, str0377, sept, ip, str0098, str0321;
ls2a    : 3*str0500, str0252, psm, str0269;
ss      : 2*str0500, str0302;
ss1a    : str0270, ki, str0150, str0280, str0302;
ss10b   : str0420, str0075, pv, str0355, str0302;
uc1     : sqfm, strx203, dipuc, strx403;
uc2     : sqfo, strx203, dipuc, strx403;
uc3     : sqfi, strx203, dipuc, strx203, -sqfi;
uc4     : strx403, dipuc, strx203, -sqfo;
uc5     : strx403, dipuc, strx203, -sqfm;
mc1     : bpm, str0058, -corr, str0021, oxx, str0025, qfend, str0025,
          oxy, str0100, qdend, strx006, dipm, oyy, strx093, corrs, bpm,
          str0020, sdend;
mc2     : bpm, str0058, -corr, str0021, oxx, str0025, qfend, str0025,
          oxy, str0100, qdend, strx006, dipm, oyy, strx093, corr, bpm, str0020,
          sdend;
achr    : ls, mc1, ss, uc1, uc2, uc3, uc4, uc5, -ss, -mc2, -ls;
achr1   : ls1a, mc1, ss1a, uc1, uc2, uc3, uc4, uc5, -ss, -mc2, -ls;
achr2   : ls2a, mc1, ss, uc1, uc2, uc3, uc4, uc5, -ss, -mc2, -ls;
achr10  : ls, mc1, ss, uc1, uc2, uc3, uc4, uc5, -ss10b, -mc2, -ls;
ringinj : achr1, achr2, 7*achr, achr10, 10*achr;
ring    : achr, nper=20;

{c:\users\streun\opadat\repository\max4_430bare.opa}
