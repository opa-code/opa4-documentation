{c:\users\streun\opadat\repository\nsls2.opa}
{com r3lsbs6 r3l3sb3sper ex_2.024h (9.3) l(6.6m) pmtpw(0.40m) com}


energy = 3.000000;

    betax   = 20.2149828; alphax  = 0.0000000;
    etax    = -0.0000063; etaxp   = 0.0000000;
    betay   = 3.0722871; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

d0   : drift, l = 4.650000, ax = 100.00, ay = 100.00;
d0a  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d1b  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d1a  : drift, l = 0.490000, ax = 100.00, ay = 100.00;
d2a  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d3a  : drift, l = 0.190000, ax = 100.00, ay = 100.00;
d3b  : drift, l = 0.200000, ax = 100.00, ay = 100.00;
d4a  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d4b  : drift, l = 0.550000, ax = 100.00, ay = 100.00;
d5   : drift, l = 0.550000, ax = 100.00, ay = 100.00;
d5w  : drift, l = 0.200000, ax = 100.00, ay = 100.00;
dpw  : drift, l = 0.200000, ax = 100.00, ay = 100.00;
dpw2 : drift, l = 0.100000, ax = 100.00, ay = 100.00;
d5c  : drift, l = 0.250000, ax = 100.00, ay = 100.00;
dhvc : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d5hc : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d5a  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d6a  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d6b  : drift, l = 0.620000, ax = 100.00, ay = 100.00;
d7   : drift, l = 0.250000, ax = 100.00, ay = 100.00;
d44a : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d44  : drift, l = 0.550000, ax = 100.00, ay = 100.00;
d33a : drift, l = 0.388600, ax = 100.00, ay = 100.00;
d33b : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d22a : drift, l = 0.500000, ax = 100.00, ay = 100.00;
d22b : drift, l = 0.250000, ax = 100.00, ay = 100.00;
d21b : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d11a : drift, l = 0.150000, ax = 100.00, ay = 100.00;
d11b : drift, l = 0.250000, ax = 100.00, ay = 100.00;
d00  : drift, l = 3.300000, ax = 100.00, ay = 100.00;
dsx  : drift, l = 0.100000, ax = 100.00, ay = 100.00;
dsd  : drift, l = 0.125000, ax = 100.00, ay = 100.00;
dsl  : drift, l = 0.150000, ax = 100.00, ay = 100.00;
ddw  : drift, l = 0.617200, ax = 100.00, ay = 100.00;

q1   : quadrupole, l = 0.300000, k = -0.621453, ax = 100.00, ay = 100.00;
q2   : quadrupole, l = 0.400000, k = 1.668877, ax = 100.00, ay = 100.00;
q3   : quadrupole, l = 0.300000, k = -1.551548, ax = 100.00, ay = 100.00;
q4   : quadrupole, l = 0.300000, k = 0.000000, ax = 100.00, ay = 100.00;
qf1  : quadrupole, l = 0.300000, k = 1.159750, ax = 100.00, ay = 100.00;
qd1  : quadrupole, l = 0.300000, k = -0.685803, ax = 100.00, ay = 100.00;
q44  : quadrupole, l = 0.300000, k = 0.000000, ax = 100.00, ay = 100.00;
q33  : quadrupole, l = 0.300000, k = -1.538644, ax = 100.00, ay = 100.00;
q22  : quadrupole, l = 0.400000, k = 2.117711, ax = 100.00, ay = 100.00;
q11  : quadrupole, l = 0.300000, k = -1.316453, ax = 100.00, ay = 100.00;

b1   : bending, l = 2.620000, t = 6.000000, k = 0.000000, t1 = 3.000000,
       t2 = 3.000000, gap = 30.0000, ax = 100.00, ay = 100.00;

s1   : sextupole, l = 0.000000, k = 1.768549, n = 1, ax = 100.00,
       ay = 100.00;
s2   : sextupole, l = 0.000000, k = 1.710324, n = 1, ax = 100.00,
       ay = 100.00;
s3   : sextupole, l = 0.000000, k = -2.199905, n = 1, ax = 100.00,
       ay = 100.00;
s4   : sextupole, l = 0.000000, k = 0.000000, n = 1, ax = 100.00,
       ay = 100.00;
sd1  : sextupole, l = 0.000000, k = 0.000000, n = 1, ax = 100.00,
       ay = 100.00;
sf1  : sextupole, l = 0.000000, k = -2.339629, n = 1, ax = 100.00,
       ay = 100.00;
sf2  : sextupole, l = 0.000000, k = 3.228209, n = 1, ax = 100.00,
       ay = 100.00;
sl1  : sextupole, l = 0.000000, k = 1.949126, n = 1, ax = 100.00,
       ay = 100.00;
sl2  : sextupole, l = 0.000000, k = 1.084019, n = 1, ax = 100.00,
       ay = 100.00;
sl3  : sextupole, l = 0.000000, k = -1.753340, n = 1, ax = 100.00,
       ay = 100.00;
sl4  : sextupole, l = 0.000000, k = -1.278324, n = 1, ax = 100.00,
       ay = 100.00;

omb  : opticsmarker, betax = 29.208741, alphax = -0.005126,
       betay = 8.103007, alphay = -0.018515, etax  = 0.459944,
       etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 100.00,
       ay = 100.00;


{----- table of segments ----------------------------------------------------}

lid  : d0, dsx, sl1, dsx, d0a, q1, d1a, dsx, sl2, dsx, d1b, q2, d3a, dsx,
       sl3, dsx, d3b, q3, d4a, dsx, sl4, dsx, d4b;
sid  : d00, dsx, s1, dsx, d11a, q11, d22a, dsx, s2, dsx, d22b, q22, d33a,
       dsx, s3, dsx, d33b, q33, d44;
disp : d5, qd1, d6a, dsd, sf1, dsd, d6b, qf1;
dba  : b1, d5w, dpw, disp, d7, dsl, sf2, omb, dsl, d7, -disp, dpw2, dpw2,
       d5w, b1;
ring : lid, dba, -sid, sid, dba, -lid, nper=15;

{c:\users\streun\opadat\repository\nsls2.opa}
