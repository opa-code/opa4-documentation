{c:\users\streun\opadat\test\pepx1.opa}
{com "pep-x ultimate ring, 4 sf slices per quad" com}


energy = 4.500000;

    betax   = 201.9921169; alphax  = 0.0004837;
    etax    = 0.0000000; etaxp   = 0.0000000;
    betay   = 44.2426150; alphay  = 0.0104754;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

didh     : drift, l = 2.500000, ax = 50.00, ay = 50.00;
dc       : drift, l = 0.350000, ax = 50.00, ay = 50.00;
d1       : drift, l = 0.250000, ax = 50.00, ay = 50.00;
d2       : drift, l = 0.250000, ax = 50.00, ay = 50.00;
d3       : drift, l = 0.250000, ax = 50.00, ay = 50.00;
d4       : drift, l = 0.600000, ax = 50.00, ay = 50.00;
d5       : drift, l = 0.300000, ax = 50.00, ay = 50.00;
bk       : drift, l = 0.750000, ax = 50.00, ay = 50.00;
bm1l     : drift, l = 1.000000, ax = 50.00, ay = 50.00;
bm2l     : drift, l = 1.000000, ax = 50.00, ay = 50.00;
bm1r     : drift, l = 1.000000, ax = 50.00, ay = 50.00;
bm2r     : drift, l = 1.000000, ax = 50.00, ay = 50.00;
bkabrt1  : drift, l = 0.545211, ax = 50.00, ay = 50.00;
bkabrt2  : drift, l = 0.545211, ax = 50.00, ay = 50.00;
blam     : drift, l = 1.000000, ax = 50.00, ay = 50.00;
bkpingv  : drift, l = 0.545211, ax = 50.00, ay = 50.00;
bkpingh  : drift, l = 0.545211, ax = 50.00, ay = 50.00;
d56qm    : drift, l = 0.270434, ax = 50.00, ay = 50.00;
d56mc    : drift, l = 0.000000, ax = 50.00, ay = 50.00;
dm5656a  : drift, l = 6.531835, ax = 50.00, ay = 50.00;
d56sqm   : drift, l = 0.162401, ax = 50.00, ay = 50.00;
d56qc    : drift, l = 0.155473, ax = 50.00, ay = 50.00;
dsk      : drift, l = 0.431751, ax = 50.00, ay = 50.00;
dusq     : drift, l = 0.220000, ax = 50.00, ay = 50.00;
dmoi5b   : drift, l = 0.217620, ax = 50.00, ay = 50.00;
dmoi5a   : drift, l = 3.147893, ax = 50.00, ay = 50.00;
dmoi4    : drift, l = 0.637599, ax = 50.00, ay = 50.00;
dbkabrt1 : drift, l = 0.799781, ax = 50.00, ay = 50.00;
dbkabrt2 : drift, l = 1.004570, ax = 50.00, ay = 50.00;
doi3s    : drift, l = 16.122736, ax = 50.00, ay = 50.00;
d45qm    : drift, l = 0.216579, ax = 50.00, ay = 50.00;
d45qc    : drift, l = 0.209651, ax = 50.00, ay = 50.00;
dmoi2b   : drift, l = 2.263851, ax = 50.00, ay = 50.00;
doi2aa   : drift, l = 13.253687, ax = 50.00, ay = 50.00;
doi2ab   : drift, l = 0.775000, ax = 50.00, ay = 50.00;
doi1     : drift, l = 1.025000, ax = 50.00, ay = 50.00;
dsep     : drift, l = 0.625000, ax = 50.00, ay = 50.00;
d45qmb   : drift, l = 0.167609, ax = 50.00, ay = 50.00;
d45mcb   : drift, l = 0.042042, ax = 50.00, ay = 50.00;
dmoi2a   : drift, l = 15.517539, ax = 50.00, ay = 50.00;
doi2bm   : drift, l = 2.558421, ax = 50.00, ay = 50.00;
dmoi3    : drift, l = 15.828166, ax = 50.00, ay = 50.00;
dbkping2 : drift, l = 1.004570, ax = 50.00, ay = 50.00;
dbkping1 : drift, l = 0.799781, ax = 50.00, ay = 50.00;
doi5bb   : drift, l = 0.512190, ax = 50.00, ay = 50.00;
dm5656   : drift, l = 6.823414, ax = 50.00, ay = 50.00;
dm5656b1 : drift, l = 2.000000, ax = 50.00, ay = 50.00;
dm5656a1 : drift, l = 1.413851, ax = 50.00, ay = 50.00;
dm5656b2 : drift, l = 2.000000, ax = 50.00, ay = 50.00;
dm5656a2 : drift, l = 2.000000, ax = 50.00, ay = 50.00;
dm5656b3 : drift, l = 2.223413, ax = 50.00, ay = 50.00;
dm5656a3 : drift, l = 2.517984, ax = 50.00, ay = 50.00;
dlcorih  : drift, l = 0.150749, ax = 50.00, ay = 50.00;
dse      : drift, l = 7.567650, ax = 50.00, ay = 50.00;
ds1      : drift, l = 1.901000, ax = 50.00, ay = 50.00;
ds2      : drift, l = 1.901000, ax = 50.00, ay = 50.00;
ds3      : drift, l = 1.901000, ax = 50.00, ay = 50.00;
dids     : drift, l = 2.350000, ax = 50.00, ay = 50.00;

br       : marker, ax = 50.00, ay = 50.00;
cav      : marker, ax = 50.00, ay = 50.00;
cav0     : marker, ax = 50.00, ay = 50.00;
mi       : marker, ax = 50.00, ay = 50.00;
mcc      : marker, ax = 50.00, ay = 50.00;
mb       : marker, ax = 50.00, ay = 50.00;
mid      : marker, ax = 50.00, ay = 50.00;
mmm      : marker, ax = 50.00, ay = 50.00;
m_st     : marker, ax = 50.00, ay = 50.00;

qfc      : quadrupole, l = 0.200000, k = 2.695840, ax = 50.00, ay = 50.00;
qf3      : quadrupole, l = 0.200000, k = 2.695840, ax = 50.00, ay = 50.00;
qf2      : quadrupole, l = 0.200000, k = 2.864007, ax = 50.00, ay = 50.00;
qd3      : quadrupole, l = 0.150000, k = -0.783979, ax = 50.00, ay = 50.00;
qd2      : quadrupole, l = 0.175000, k = -2.423788, ax = 50.00, ay = 50.00;
qf1      : quadrupole, l = 0.275000, k = 2.566374, ax = 50.00, ay = 50.00;
qd1      : quadrupole, l = 0.150000, k = -2.483456, ax = 50.00, ay = 50.00;
qds1i    : quadrupole, l = 0.150000, k = 0.497718, ax = 50.00, ay = 50.00;
qfs1i    : quadrupole, l = 0.150000, k = -0.239715, ax = 50.00, ay = 50.00;
qds2i    : quadrupole, l = 0.150000, k = -1.140378, ax = 50.00, ay = 50.00;
qfoi     : quadrupole, l = 0.279178, k = 0.429329, ax = 50.00, ay = 50.00;
qdoi     : quadrupole, l = 0.279178, k = 0.000000, ax = 50.00, ay = 50.00;
qfi      : quadrupole, l = 0.225000, k = -0.116807, ax = 50.00, ay = 50.00;
qdi      : quadrupole, l = 0.225000, k = 0.071211, ax = 50.00, ay = 50.00;
qdse     : quadrupole, l = 0.150000, k = -0.573402, ax = 50.00, ay = 50.00;
qfse     : quadrupole, l = 0.150000, k = 0.590676, ax = 50.00, ay = 50.00;
qds1     : quadrupole, l = 0.150000, k = 0.441713, ax = 50.00, ay = 50.00;
qfs1     : quadrupole, l = 0.150000, k = -0.066154, ax = 50.00, ay = 50.00;
qds2     : quadrupole, l = 0.150000, k = -1.337303, ax = 50.00, ay = 50.00;
qfs2     : quadrupole, l = 0.150000, k = 1.120890, ax = 50.00, ay = 50.00;
qds3     : quadrupole, l = 0.150000, k = -0.492257, ax = 50.00, ay = 50.00;
qfs3     : quadrupole, l = 0.150000, k = 0.549138, ax = 50.00, ay = 50.00;

bm       : bending, l = 1.600000, t = 0.902262, k = 0.000000,
           t1 = 0.451131, t2 = 0.451131, gap = 20.0000, k1 = 0.5000,
           ax = 50.00, ay = 50.00;
bl       : bending, l = 2.000000, t = 1.139095, k = -0.435979,
           t1 = 0.569548, t2 = 0.569548, gap = 20.0000, k1 = 0.5000,
           ax = 50.00, ay = 50.00;

sf       : sextupole, l = 0.000000, k = 28.283874, n = 1, ax = 50.00,
           ay = 50.00;
sd       : sextupole, l = 0.000000, k = -65.997028, n = 1,
           ax = 50.00, ay = 50.00;
sf1      : sextupole, l = 0.000000, k = 19.086580, n = 1, ax = 50.00,
           ay = 50.00;
sd1      : sextupole, l = 0.000000, k = -80.809442, n = 1,
           ax = 50.00, ay = 50.00;
sh1      : sextupole, l = 0.000000, k = 35.000000, n = 1, ax = 50.00,
           ay = 50.00;
sh2      : sextupole, l = 0.000000, k = 3.325900, n = 1, ax = 50.00,
           ay = 50.00;
sh3      : sextupole, l = 0.000000, k = -51.404600, n = 1,
           ax = 50.00, ay = 50.00;
sh4      : sextupole, l = 0.000000, k = -26.732100, n = 1,
           ax = 50.00, ay = 50.00;
sh5      : sextupole, l = 0.000000, k = -25.759900, n = 1,
           ax = 50.00, ay = 50.00;
sh6      : sextupole, l = 0.000000, k = 64.283900, n = 1, ax = 50.00,
           ay = 50.00;

bpm      : monitor, ax = 50.00, ay = 50.00;

hcor     : h-corrector, ax = 50.00, ay = 50.00;

vcor     : v-corrector, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

fodo    : br, sd, vcor, bpm, dc, sf, qfc, sf, hcor, sf, qfc, sf, bpm,
          dc, sd, bl;
celml   : didh, qd1, sh1, qd1, d1, qf1, sh2, hcor, qf1, bpm, d2, qd2,
          sh3, qd2, d3, bm, sd1, vcor, bpm, d4, 2*qd3, d5, sf1, qf2, sf1, hcor,
          sf1, qf2, sf1, bpm, dc, sd, bl, br, sd, vcor, bpm, dc, sf, qf3, sf,
          hcor, sf, qf3, sf, bpm, dc, sd, bl;
celmr   : br, sd, vcor, bpm, dc, sf, qf3, sf, hcor, sf, qf3, sf, bpm,
          dc, sd, bl, br, sd, vcor, bpm, dc, sf1, qf2, sf1, hcor, sf1, qf2,
          sf1, bpm, d5, 2*qd3, d4, bpm, vcor, sd1, bm, d3, qd2, sh4, qd2, d2,
          qf1, sh5, hcor, qf1, bpm, d1, qd1, sh6, qd1, didh;
cel     : celml, fodo, mcc, fodo, celmr;
fodos   : qdse, bpm, vcor, dse, 2*qfse, bpm, hcor, dse, qdse;
hstsl   : qds1, bpm, vcor, ds1, 2*qfs1, bpm, hcor, ds2, 2*qds2, bpm,
          vcor, ds3, 2*qfs2, bpm, hcor, dse, 2*qds3, bpm, vcor, dse, 2*qfs3,
          bpm, hcor, dse, qdse, 2*fodos;
hstsr   : qdse, bpm, vcor, dse, 2*qfs3, bpm, hcor, dse, 2*qds3, bpm,
          vcor, dse, 2*qfs2, bpm, hcor, ds3, 2*qds2, bpm, vcor, ds2, 2*qfs1,
          bpm, hcor, ds1, qds1;
hstslc0 : qds1, bpm, vcor, cav0, ds1, 2*qfs1, bpm, hcor, ds2, 2*qds2,
          bpm, vcor, ds3, 2*qfs2, bpm, hcor, dse, 2*qds3, bpm, vcor, dse,
          2*qfs3, bpm, hcor, dse, qdse, 2*fodos;
hstslc  : qds1, bpm, vcor, cav, ds1, 2*qfs1, bpm, hcor, ds2, 2*qds2,
          bpm, vcor, ds3, 2*qfs2, bpm, hcor, dse, 2*qds3, bpm, vcor, dse,
          2*qfs3, bpm, hcor, dse, qdse, 2*fodos;
sts     : hstsl, mi, hstsr;
celmsl  : br, sd, vcor, bpm, dc, sf, qf3, sf, hcor, sf, qf3, sf, bpm,
          dc, sd, bl, br, sd, vcor, bpm, dc, sf1, qf2, sf1, hcor, sf1, qf2,
          sf1, bpm, d5, 2*qd3, d4, bpm, vcor, sd1, bm, d3, qd2, sh4, qd2, d2,
          qf1, sh5, hcor, qf1, bpm, d1, qd1, sh6, qd1, dids, qds1;
celmsr  : qds1, dids, qd1, sh1, qd1, d1, qf1, sh2, hcor, qf1, bpm, d2,
          qd2, sh3, qd2, d3, bm, sd1, vcor, bpm, d4, 2*qd3, d5, sf1, qf2, sf1,
          hcor, sf1, qf2, sf1, bpm, dc, sd, bl, br, sd, vcor, bpm, dc, sf, qf3,
          sf, hcor, sf, qf3, sf, bpm, dc, sd, bl;
celsl   : celml, fodo, mcc, fodo, celmsl;
celsr   : celmsr, fodo, mcc, fodo, celmr;
hsxtl   : 3*cel, celsl, hstsl;
hsxtr   : hstsr, celsr, 3*cel;
hsxtlc0 : 3*cel, celsl, hstslc0;
hsxtlc  : 3*cel, celsl, hstslc;
arc     : celsr, 6*cel, celsl;
vcori   : dlcorih, hcor, dlcorih;
hcori   : dlcorih, vcor, dlcorih;
hstsli  : qds1i, d56qm, bpm, d56mc, vcori, dm5656a1, 2*qfs1i,
          dm5656a2, 2*qds2i, dm5656a3, bpm, d56sqm, 2*qfoi, d56qc, hcori, dsk,
          2*dusq, dmoi5b, 2*bm2l, dmoi5a, vcori, d56qc, 2*qdoi, d56sqm, bpm,
          dmoi4, 2*bk, dbkabrt1, 2*bkabrt1, dbkabrt2, 2*bkabrt2, doi3s, bpm,
          d45qm, 2*qfi, d45qc, hcori, dmoi2b, 2*bm1l, doi2aa, 2*blam, doi2ab,
          2*qdi, doi1, dsep;
hstsri  : dsep, doi1, 2*qdi, d45qmb, bpm, d45mcb, vcori, dmoi2a,
          2*bm1r, doi2bm, bpm, d45qm, 2*qfi, d45qc, hcori, dmoi3, 2*bkpingv,
          dbkping2, 2*bkpingh, dbkping1, 2*bk, dmoi4, bpm, d56sqm, 2*qdoi,
          d56qc, vcori, dmoi5a, 2*bm2r, doi5bb, 2*dusq, dsk, bpm, d56sqm,
          2*qfoi, d56qc, hcori, dm5656b3, 2*qds2i, dm5656b2, 2*qfs1i, dm5656b1,
          qds1i;
stsi    : hstsli, hstsri;
celsli  : celml, fodo, mcc, fodo, br, sd, vcor, bpm, dc, sf, qf3, sf,
          hcor, sf, qf3, sf, bpm, dc, sd, bl, br, sd, vcor, bpm, dc, sf1, qf2,
          sf1, hcor, sf1, qf2, sf1, bpm, d5, 2*qd3, d4, bpm, vcor, sd1, bm, d3,
          qd2, sh4, qd2, d2, qf1, sh5, hcor, qf1, bpm, d1, qd1, sh6, qd1, dids,
          qds1i;
celsri  : qds1i, dids, qd1, sh1, qd1, d1, qf1, sh2, hcor, qf1, bpm,
          d2, qd2, sh3, qd2, d3, bm, sd1, vcor, bpm, d4, 2*qd3, d5, sf1, qf2,
          sf1, hcor, sf1, qf2, sf1, bpm, dc, sd, bl, br, sd, vcor, bpm, dc, sf,
          qf3, sf, hcor, sf, qf3, sf, bpm, dc, sd, bl, fodo, mcc, fodo, celmr;
hsxtli  : 3*cel, celsli, hstsli;
hsxtri  : hstsri, celsri, 3*cel;
ring0   : hsxtri, hsxtlc0, m_st, hsxtr, hsxtl, m_st, hsxtr, hsxtl,
          m_st, hsxtr, hsxtl, m_st, hsxtr, hsxtl, m_st, hsxtr, hsxtli, mmm;

{c:\users\streun\opadat\test\pepx1.opa}
