{c:\users\streun\opadat\test\petra.opa}
{com petra basis 4 and new octant phasad. 72 fod com}


energy = 6.000000;

    betax   = 11.4132588; alphax  = 0.0009819;
    etax    = -0.0001104; etaxp   = -0.0000219;
    betay   = 23.6505503; alphay  = 0.0016936;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

dricv   : drift, l = 0.173000, ax = 50.00, ay = 50.00;
d1      : drift, l = 0.233000, ax = 50.00, ay = 50.00;
d2      : drift, l = 0.234000, ax = 50.00, ay = 50.00;
d3      : drift, l = 0.546000, ax = 50.00, ay = 50.00;
d4      : drift, l = 0.731000, ax = 50.00, ay = 50.00;
d5      : drift, l = 0.885000, ax = 50.00, ay = 50.00;
d6      : drift, l = 0.886000, ax = 50.00, ay = 50.00;
d7      : drift, l = 1.236000, ax = 50.00, ay = 50.00;
d8      : drift, l = 4.358000, ax = 50.00, ay = 50.00;
d9      : drift, l = 4.658000, ax = 50.00, ay = 50.00;
d10     : drift, l = 7.289000, ax = 50.00, ay = 50.00;
d11     : drift, l = 5.427000, ax = 50.00, ay = 50.00;
d12     : drift, l = 6.403000, ax = 50.00, ay = 50.00;
d13     : drift, l = 6.848000, ax = 50.00, ay = 50.00;
d14     : drift, l = 7.158000, ax = 50.00, ay = 50.00;
d15     : drift, l = 7.187000, ax = 50.00, ay = 50.00;
d16     : drift, l = 9.023000, ax = 50.00, ay = 50.00;
d17     : drift, l = 9.059000, ax = 50.00, ay = 50.00;
dc1     : drift, l = 0.050000, ax = 50.00, ay = 50.00;
dc2     : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dc3     : drift, l = 0.389000, ax = 50.00, ay = 50.00;
ds1     : drift, l = 0.103000, ax = 50.00, ay = 50.00;
ds2     : drift, l = 0.496000, ax = 50.00, ay = 50.00;
drf1    : drift, l = 0.098000, ax = 50.00, ay = 50.00;
drf2    : drift, l = 0.300000, ax = 50.00, ay = 50.00;
drf3    : drift, l = 0.829000, ax = 50.00, ay = 50.00;
ddk1    : drift, l = 4.800000, ax = 50.00, ay = 50.00;
ddk2    : drift, l = 1.000000, ax = 50.00, ay = 50.00;
ddk3    : drift, l = 5.016000, ax = 50.00, ay = 50.00;
dd1     : drift, l = 4.700330, ax = 50.00, ay = 50.00;
dd2     : drift, l = 0.200000, ax = 50.00, ay = 50.00;
dd3     : drift, l = 0.700000, ax = 50.00, ay = 50.00;
dd4     : drift, l = 1.979000, ax = 50.00, ay = 50.00;
dd5     : drift, l = 2.000000, ax = 50.00, ay = 50.00;
dd11    : drift, l = 7.483500, ax = 50.00, ay = 50.00;
dl3     : drift, l = 5.427000, ax = 50.00, ay = 50.00;
dl4     : drift, l = 1.000000, ax = 50.00, ay = 50.00;
dl5     : drift, l = 5.887000, ax = 50.00, ay = 50.00;
d521    : drift, l = 0.491000, ax = 50.00, ay = 50.00;
dz1     : drift, l = 3.361500, ax = 50.00, ay = 50.00;
dz2     : drift, l = 0.750000, ax = 50.00, ay = 50.00;
dz41    : drift, l = 0.700000, ax = 50.00, ay = 50.00;
dz42    : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dz31    : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dz32    : drift, l = 0.400000, ax = 50.00, ay = 50.00;
dz51    : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dz52    : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dz6     : drift, l = 0.500000, ax = 50.00, ay = 50.00;
dz6h    : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dz7     : drift, l = 0.175000, ax = 50.00, ay = 50.00;
eol     : drift, l = 0.000000, ax = 50.00, ay = 50.00;
ip      : drift, l = 0.000000, ax = 50.00, ay = 50.00;
ipp     : drift, l = 0.000000, ax = 50.00, ay = 50.00;
dsex    : drift, l = 0.143000, ax = 50.00, ay = 50.00;
dsf1    : drift, l = 0.125000, ax = 50.00, ay = 50.00;
dsd1    : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dsfl1   : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dsdl1   : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dri_rf7 : drift, l = 1.050000, ax = 50.00, ay = 50.00;

cav_rf7 : marker, ax = 50.00, ay = 50.00;

qf      : quadrupole, l = 0.704000, k = 0.239837, ax = 50.00, ay = 50.00;
qd      : quadrupole, l = 0.704000, k = -0.239626, ax = 50.00, ay = 50.00;
qdh     : quadrupole, l = 0.352000, k = -0.239626, ax = 50.00, ay = 50.00;
q4b     : quadrupole, l = 0.704000, k = 0.239837, ax = 50.00, ay = 50.00;
q5b     : quadrupole, l = 0.704000, k = -0.239837, ax = 50.00, ay = 50.00;
q6b     : quadrupole, l = 0.704000, k = 0.239837, ax = 50.00, ay = 50.00;
q0n2    : quadrupole, l = 0.352000, k = -0.188494, ax = 50.00, ay = 50.00;
q1n     : quadrupole, l = 0.704000, k = 0.179288, ax = 50.00, ay = 50.00;
q2n     : quadrupole, l = 0.704000, k = -0.184592, ax = 50.00, ay = 50.00;
q3n     : quadrupole, l = 0.704000, k = 0.179633, ax = 50.00, ay = 50.00;
q4n     : quadrupole, l = 0.704000, k = -0.189290, ax = 50.00, ay = 50.00;
q5n     : quadrupole, l = 0.704000, k = 0.180648, ax = 50.00, ay = 50.00;
q6n2    : quadrupole, l = 0.352000, k = -0.189290, ax = 50.00, ay = 50.00;
q7n     : quadrupole, l = 1.042000, k = 0.131825, ax = 50.00, ay = 50.00;
q9n     : quadrupole, l = 1.042000, k = -0.139395, ax = 50.00, ay = 50.00;
q0b     : quadrupole, l = 1.042000, k = 0.172470, ax = 50.00, ay = 50.00;
q2b     : quadrupole, l = 1.042000, k = 0.179912, ax = 50.00, ay = 50.00;
q1      : quadrupole, l = 1.042000, k = -0.154295, ax = 50.00, ay = 50.00;
q3      : quadrupole, l = 0.704000, k = -0.236741, ax = 50.00, ay = 50.00;
q5a     : quadrupole, l = 0.704000, k = -0.239837, ax = 50.00, ay = 50.00;
q6a     : quadrupole, l = 0.704000, k = 0.239837, ax = 50.00, ay = 50.00;
q4a     : quadrupole, l = 0.704000, k = 0.224345, ax = 50.00, ay = 50.00;
q2a     : quadrupole, l = 0.704000, k = 0.264682, ax = 50.00, ay = 50.00;
q0a     : quadrupole, l = 1.042000, k = 0.174003, ax = 50.00, ay = 50.00;
qk1     : quadrupole, l = 1.042000, k = -0.187921, ax = 50.00, ay = 50.00;
qk3     : quadrupole, l = 0.704000, k = -0.214927, ax = 50.00, ay = 50.00;
q0k2    : quadrupole, l = 0.521000, k = -0.095879, ax = 50.00, ay = 50.00;
q1k     : quadrupole, l = 1.042000, k = 0.135740, ax = 50.00, ay = 50.00;
q2k     : quadrupole, l = 1.042000, k = -0.127232, ax = 50.00, ay = 50.00;
q2k2    : quadrupole, l = 1.042000, k = -0.127232, ax = 50.00, ay = 50.00;
q4k     : quadrupole, l = 1.042000, k = 0.131287, ax = 50.00, ay = 50.00;
q5k     : quadrupole, l = 0.704000, k = -0.275170, ax = 50.00, ay = 50.00;
gq      : quadrupole, l = 0.704000, k = 0.000000, ax = 50.00, ay = 50.00;
jqd1    : quadrupole, l = 0.400000, k = -0.500000, ax = 50.00, ay = 50.00;
jqf2    : quadrupole, l = 0.800000, k = 0.692000, ax = 50.00, ay = 50.00;
jqd3    : quadrupole, l = 0.400000, k = -0.670000, ax = 50.00, ay = 50.00;
jqd4    : quadrupole, l = 0.800000, k = -0.741000, ax = 50.00, ay = 50.00;
jqf5    : quadrupole, l = 0.800000, k = 0.651000, ax = 50.00, ay = 50.00;
q5nd    : quadrupole, l = 0.704000, k = 0.172712, ax = 50.00, ay = 50.00;
q6nd    : quadrupole, l = 0.704000, k = -0.194576, ax = 50.00, ay = 50.00;
q7nd    : quadrupole, l = 0.704000, k = 0.323451, ax = 50.00, ay = 50.00;
q8nd    : quadrupole, l = 1.042000, k = -0.169380, ax = 50.00, ay = 50.00;
qf11    : quadrupole, l = 0.704000, k = 0.142456, ax = 50.00, ay = 50.00;
qd11    : quadrupole, l = 0.704000, k = -0.210922, ax = 50.00, ay = 50.00;
qf12    : quadrupole, l = 0.704000, k = -0.239453, ax = 50.00, ay = 50.00;
qd12    : quadrupole, l = 0.704000, k = 0.112864, ax = 50.00, ay = 50.00;
qf21    : quadrupole, l = 1.042000, k = 0.140001, ax = 50.00, ay = 50.00;

b       : bending, l = 5.378000, t = 1.607140, k = 0.000000,
          t1 = 0.803570, t2 = 0.803570, ax = 50.00, ay = 50.00;
kbbo    : bending, l = 1.000000, t = 2.450000, k = 0.000000,
          t1 = 1.250000, t2 = 1.250000, ax = 50.00, ay = 50.00;
kbboh1  : bending, l = 0.500000, t = 1.250000, k = 0.000000,
          t1 = 1.250000, t2 = 0.000000, ax = 50.00, ay = 50.00;
kbboh2  : bending, l = 0.500000, t = 1.250000, k = 0.000000,
          t1 = 0.000000, t2 = 1.250000, ax = 50.00, ay = 50.00;

s10     : sextupole, l = 0.000000, k = -2.150425, n = 1, ax = 50.00,
          ay = 50.00;
s20     : sextupole, l = 0.000000, k = 1.227650, n = 1, ax = 50.00,
          ay = 50.00;
s30     : sextupole, l = 0.000000, k = -2.293318, n = 1, ax = 50.00,
          ay = 50.00;
s40     : sextupole, l = 0.000000, k = 1.363206, n = 1, ax = 50.00,
          ay = 50.00;

mon     : monitor, ax = 50.00, ay = 50.00;

chl0    : h-corrector, ax = 50.00, ay = 50.00;

cvl0    : v-corrector, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

rf7    : dri_rf7, cav_rf7, dri_rf7;
cv     : dricv, cvl0, dricv;
s1     : dsex, s10, dsex;
s2     : dsex, s20, dsex;
s3     : dsex, s30, dsex;
s4     : dsex, s40, dsex;
flst   : q6n2, d11, q5n, d11, q6n2;
lst    : q6n2, d11, q3n, d11, q2n, d11, q1n, d11, q0n2;
lgl    : q6n2, d11, q5n, d11, q4n, d11, q3n, d11, q2n, d11, q1n, d11, q0n2;
cb     : b;
dscv   : dc1, cv, dc2;
dbd1   : d1, b, d5;
dbdc1  : d1, mon, cb, dscv, dc3;
dbd2   : -dbd1;
dbdc2  : -dbdc1;
dbd3   : d2, b, d3;
dbdc3  : d2, mon, cb, dscv, dc1;
dbd4   : -dbd3;
dbdc4  : -dbdc3;
dbsm2  : d1, b, ds2, s2, ds1;
dbsm4  : d1, b, ds2, s4, ds1;
dbscm1 : d1, mon, cb, dscv, s1, ds1;
dbscm3 : d1, mon, cb, dscv, s1, ds1;
dbsp2  : ds1, s2, ds2, b, d1;
dbsp4  : ds1, s4, ds2, b, d1;
dbscp1 : ds1, s1, dscv, cb, mon, d1;
dbscp3 : ds1, s3, dscv, cb, mon, d1;
dhf1   : drf1, rf7, drf2, rf7, drf1;
dhf2   : drf1, rf7, drf2, rf7, drf3;
dhf3   : -dhf2;
lgl    : q6n2, d11, chl0, mon, q5n, d11, cvl0, q4n, d11, chl0, mon,
         q3n, d11, cvl0, q2n, d11, chl0, mon, q1n, d11, cvl0, q0n2;
lgr    : -lgl;
lghf   : q6n2, cvl0, d11, chl0, mon, q5n, d11, q4n, cvl0, dhf2, chl0,
         mon, q3n, dhf2, q2n, cvl0, dhf2, chl0, mon, q1n, dhf2, q0n2, q0n2,
         cvl0, dhf3, q1n, mon, chl0, dhf3, cvl0, q2n, dhf3, q3n, mon, chl0,
         dhf3, cvl0, q4n, d11, q5n, mon, chl0, d11, cvl0, q6n2;
balr   : q6n2, cvl0, d10, q7n, mon, chl0, d6, b, d6, q9n, cvl0, d13,
         q0b, dbdc3, q1, dbd3, q2b, d2, mon, cb, dscv, s1, ds1, q3, dbsm2, q4b,
         dbscm1, q5b, dbsm2, q6b, dbscm1, qdh;
ball   : qdh, dbscp1, q6b, dbsp2, q5b, dbscp1, q4b, dbsp2, q3, ds1, s1,
         dscv, cb, mon, d2, q2b, dbd4, q1, dbdc4, q0b, d13, chl0, q9n, d6, b,
         d6, chl0, mon, q7n, d10, cvl0, q6n2;
bmlk   : qdh, dbsm2, qf, dbscm1, qdh, qdh, dbsm2, qf, dbscm1, qdh, qdh,
         dbsm2, qf, d1, mon, cb, dscv, dc3, qdh, qdh, dbscp3, qf, dbsp4, qdh,
         qdh, dbscp3, qf, dbsp4, qdh, qdh, dbscp3, qf, dbsp4, qdh;
bmkl   : -bmlk;
bakr   : q0a, dbdc3, qk1, d2, b, d5, q2a, dbdc1, qk3, dbsm4, q4a,
         dbscm3, q5a, dbsm4, q6a, dbscm3, qdh;
bakl   : qdh, dbscp3, q6a, dbsp4, q5a, dbscp3, q4a, dbsp4, qk3, dbdc2,
         q2a, d5, b, d2, qk1, dbdc4, q0a;
kgr    : q0k2, cvl0, d14, q1k, mon, chl0, d9, q2k, cvl0, d17, q4k,
         dbdc1, q5k, d15;
kgl    : d15, q5k, dbdc2, q4k, d17, cvl0, q2k, d9, chl0, mon, q1k, d14, q0k2;
cbbo   : kbboh1, chl0, kbboh2;
ds3l   : dz31, dsfl1, dz32;
ds3r   : -ds3l;
ds4l   : dz41, dsdl1, dz42;
ds4r   : -ds4l;
ds5l   : dz51, dsd1, dz52;
ds5r   : -ds5l;
ds7m   : dz7, cvl0, dsf1, mon, chl0, dsf1, dz7;
ztrl   : dz1, cvl0, jqd1, dz2, jqf2, chl0, ds3l, jqd3, ds4l;
ztrr   : ds4r, jqd3, ds3r, chl0, jqf2, dz2, jqd1, cvl0, dz1;
zchr   : mon, kbbo, ds5l, jqd4, dz6h, cvl0, mon, dz6h, jqf5, ds7m,
         jqf5, dz6h, cvl0, mon, dz6h, jqd4, ds5r, kbbo, mon;
zell   : ztrl, zchr, ztrr;
lgrz   : ip, q0n2, dl3, q1n, mon, chl0, dl3, q2n, cvl0, dl3, q3n, mon,
         chl0, dl3, q4n, cvl0, dl3, q5nd, mon, chl0, dl3, q6nd, cvl0, dl3,
         q7nd, mon, chl0, dl4, q8nd, cvl0, dl5;
lglz   : -lgrz;
kgrz   : q0k2, cvl0, ddk1, qf11, mon, chl0, ddk1, qd11, cvl0, ddk1,
         qf21, mon, chl0, ddk1, qd12, cvl0, ddk2, qf12, mon, chl0, ddk3;
kglz   : -kgrz;
bog    : zell, zell, zell, zell, zell, zell, zell, zell, zell;
vier   : lgrz, bog, kglz, kgrz, bog, lglz;
oclk   : ip, lgr, balr, bmlk, bakl, kgl;
ockl   : kgr, bakr, bmkl, ball, lgl, ip;
quhf   : kgr, bakr, bmkl, ball, lghf, balr, bmlk, bakl, kgl;
ring   : lgrz, ipp, bog, ipp, kglz, ockl, oclk, quhf, ockl, oclk, ockl;

{c:\users\streun\opadat\test\petra.opa}
