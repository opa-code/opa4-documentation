{c:\users\streun\opadat\test\sesame.opa}


energy = 2.477000;

    betax   = 12.0065418; alphax  = 0.0000000;
    etax    = 0.5236296; etaxp   = 0.0000000;
    betay   = 3.1196627; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

dx    : drift, l = 2.220000, ax = 35.00, ay = 16.00;
d0100 : drift, l = 0.100000, ax = 35.00, ay = 16.00;
d0150 : drift, l = 0.150000, ax = 35.00, ay = 16.00;
d0280 : drift, l = 0.280000, ax = 35.00, ay = 16.00;
d1190 : drift, l = 1.190000, ax = 35.00, ay = 16.00;

qf    : quadrupole, l = 0.150000, k = 1.840000, ax = 35.00, ay = 16.00;
qd    : quadrupole, l = 0.100000, k = -0.370000, ax = 35.00, ay = 16.00;

bend1 : bending, l = 1.125000, t = 11.250000, k = -0.330000,
        t1 = 11.250000, t2 = 0.000000, ax = 35.00, ay = 16.00;
bend2 : bending, l = 1.125000, t = 11.250000, k = -0.330000,
        t1 = 0.000000, t2 = 11.250000, ax = 35.00, ay = 16.00;

sd    : sextupole, l = 0.000000, k = -0.769562, n = 1, ax = 35.00,
        ay = 16.00;
sf    : sextupole, l = 0.000000, k = 0.488665, n = 1, ax = 35.00, ay = 16.00;

m12   : multipole, n = 6,  k = 1.00000e+10, ax = 35.00, ay = 16.00;


{----- table of segments ----------------------------------------------------}

sesame : dx, sf, d0100, sf, d0150, qf, m12, qf, d0150, qd, d0150, sd,
         d0100, sd, d0280, bend1, bend2, d0280, sd, d0100, sd, d0150, qd,
         d0150, qf, m12, qf, d0150, sf, d0100, sf, d1190;
sup    : sesame, -sesame;
ring   : sup, nper=8;

{c:\users\streun\opadat\test\sesame.opa}
