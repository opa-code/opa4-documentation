{c:\as\opa\sls-2\b073_002_cs.opa}
{com 5 sd families com}


energy = 2.700000;
rotinv = 0;
    betax   = 6.6251513; alphax  = 0.3520931;
    etax    = 0.0000640; etaxp   = -0.0000158;
    betay   = 4.2053123; alphay  = 0.0542256;
    etay    = 0.0000686; etayp   = -0.0000282;

{----- variables ---------------------------------------------------}

gdbs5  = 0.002065;
gdbs2  = 1.5e-6;
ksf    = 1.00563;
ksd    = 1.0215;

{----- table of elements ---------------------------------------------}

dem4       : drift, l = 0.820000, ax = 32.00, ay = 16.00;
dem5       : drift, l = 0.170000, ax = 32.00, ay = 16.00;
fn         : drift, l = 0.010000, ax = 9.00, ay = 9.00;
doc        : drift, l = 0.015000, block, ax = 9.00, ay = 9.00;
dsx        : drift, l = 0.025000, block, ax = 9.00, ay = 9.00;
dos        : drift, l = 0.010000, ax = 9.00, ay = 9.00;
dbpm       : drift, l = 0.012500, block, ax = 9.00, ay = 9.00;
dmon       : drift, l = 0.022500, ax = 9.00, ay = 9.00;
dcc        : drift, l = 0.025000, block, ax = 9.00, ay = 9.00;
dchv       : drift, l = 0.055000, block, ax = 9.00, ay = 9.00;
dcsoq      : drift, l = 0.017500, ax = 9.00, ay = 9.00;
dqua       : drift, l = 0.035000, block, ax = 9.00, ay = 9.00;
dquail     : drift, l = 0.070000, block, ax = 38.00, ay = 20.00;
dquaim     : drift, l = 0.070000, block, ax = 27.00, ay = 27.00;
dquais     : drift, l = 0.070000, block, ax = 20.00, ay = 20.00;
dyco       : drift, l = 0.030000, block, ax = 38.00, ay = 20.00;
dycb       : drift, l = 0.060000, block, ax = 38.00, ay = 20.00;
dycq       : drift, l = 0.015000, ax = 38.00, ay = 20.00;
dabs       : drift, l = 0.170000, ax = 9.00, ay = 9.00;
dbe        : drift, l = 0.170000, ax = 9.00, ay = 9.00;
dbe1       : drift, l = 0.140500, ax = 9.00, ay = 9.00;
dbe2       : drift, l = 0.004500, ax = 9.00, ay = 9.00;
dbs5       : drift, l = gdbs5, block, ax = 9.00, ay = 9.00;
dbs2       : drift, l = gdbs2, block, ax = 9.00, ay = 9.00;
dmat       : drift, l = 0.129500, ax = 9.00, ay = 9.00;
dbspac     : drift, l = 0.030000, ax = 9.00, ay = 9.00;
dbspace    : drift, l = 0.035500, ax = 9.00, ay = 9.00;
dlcqt      : drift, l = 0.030000, ax = 9.00, ay = 9.00;
dlqqt      : drift, l = 0.200000, ax = 9.00, ay = 9.00;
dsept      : drift, l = 0.205000, block, ax = 5.00, ay = 10.90;
dkin       : drift, l = 0.125000, block, ax = 43.00, ay = 15.00;
no_sept    : drift, l = 0.300000, block, ax = 5.50, ay = 9.00;
no_k       : drift, l = 0.600000, block, ax = 9.00, ay = 9.00;
no_fk1     : drift, l = 0.800000, block, ax = 9.00, ay = 9.00;
no_fk2     : drift, l = 0.800000, block, ax = 9.00, ay = 9.00;
shalf      : drift, l = 2.055000, ax = 9.00, ay = 9.00;
mhalf      : drift, l = 2.490000, ax = 9.00, ay = 9.00;
scut4      : drift, l = 1.055000, ax = 9.00, ay = 9.00;
mcut8      : drift, l = 0.245000, ax = 9.00, ay = 9.00;
dvv        : drift, l = 0.100000, ax = 32.00, ay = 16.00;
lqua9a     : drift, l = 3.280000, ax = 9.00, ay = 9.00;
lqua9a1    : drift, l = 2.975000, ax = 9.00, ay = 9.00;
lqua9a2    : drift, l = 0.305000, ax = 9.00, ay = 9.00;
lqua9b     : drift, l = 2.500000, ax = 9.00, ay = 9.00;
lqua5a     : drift, l = 2.500000, ax = 9.00, ay = 9.00;
lqua5b     : drift, l = 3.280000, ax = 9.00, ay = 9.00;
lqua5b1    : drift, l = 0.305000, ax = 9.00, ay = 9.00;
lqua5b2    : drift, l = 2.975000, ax = 9.00, ay = 9.00;
lcut8a     : drift, l = 0.335000, ax = 32.00, ay = 16.00;
und8       : drift, l = 2.000000, block, ax = 4.00, ay = 4.00;
und81      : drift, l = 0.440000, block, ax = 4.00, ay = 4.00;
und82      : drift, l = 1.560000, block, ax = 4.00, ay = 4.00;
und4h      : drift, l = 1.000000, block, ax = 9.00, ay = 2.00;
void       : drift, l = 2.000000, ax = 9.00, ay = 9.00;
dnoq       : drift, l = 0.170000, block, ax = 43.00, ay = 15.00;
dfk1       : drift, l = 0.075000, ax = 32.00, ay = 16.00;
dfk2       : drift, l = 0.225000, ax = 32.00, ay = 16.00;
sfkcut     : drift, l = 0.955000, block, ax = 20.00, ay = 2.00;
dcsls      : drift, l = 0.042500, block, ax = 32.00, ay = 16.00;
d145       : drift, l = 0.145000, ax = 9.00, ay = 9.00;
dktap      : drift, l = 0.105000, ax = 9.00, ay = 9.00;
dflk       : drift, l = 0.025000, block, ax = 43.00, ay = 15.00;
pinger     : drift, l = 0.600000, block, ax = 43.00, ay = 15.00;
dylong     : drift, l = 1.575000, ax = 27.00, ay = 27.00;
sep1       : drift, l = 1.190000, block, ax = 9.50, ay = 16.74;
sep2       : drift, l = 0.280000, block, ax = 9.50, ay = 16.74;
dsep       : drift, l = 0.200000, block, ax = 9.50, ay = 20.00;
dqsep      : drift, l = 0.085000, ax = 38.00, ay = 20.00;
dysi2      : drift, l = 0.290000, ax = 50.00, ay = 50.00;
dysi1      : drift, l = 0.195000, ax = 50.00, ay = 50.00;
dyqmi      : drift, l = 0.110000, ax = 32.50, ay = 10.00;
dyqmo      : drift, l = 0.400000, ax = 27.00, ay = 20.00;
ddx        : drift, l = 0.010000, ax = 50.00, ay = 50.00;

center     : marker, ax = 9.00, ay = 9.00;
ossmon     : marker, ax = 32.00, ay = 16.00;
mmm        : marker, ax = 50.00, ay = 50.00;
special1l  : marker, ax = 50.00, ay = 50.00;
midlong    : marker, ax = 50.00, ay = 50.00;
midmedi    : marker, ax = 50.00, ay = 50.00;

qac        : quadrupole, l = 0.012500, k = 0.000000, ax = 50.00, ay = 50.00;
cs         : quadrupole, l = 0.012500, k = 0.000000, rot = 45.0000, ax = 50.00,
             ay = 50.00;
qax        : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qay        : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qaxmo      : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qaymo      : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qaxmi      : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qaymi      : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qaxx       : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qaxy       : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qayy       : quadrupole, l = 0.025000, k = 0.000000, ax = 9.00, ay = 9.00;
qays4a     : quadrupole, l = 0.025000, k = 0.180140*2, ax = 9.00, ay = 9.00;
qaxs4b     : quadrupole, l = 0.025000, k = -0.126882*2, ax = 9.00,
             ay = 9.00;
qays4c     : quadrupole, l = 0.025000, k = 0.091111*2, ax = 9.00, ay = 9.00;
qays4d     : quadrupole, l = 0.025000, k = -0.069814*2, ax = 9.00,
             ay = 9.00;
qaxs4e     : quadrupole, l = 0.025000, k = 0.033933*2, ax = 9.00, ay = 9.00;
qays5a     : quadrupole, l = 0.025000, k = 0.272679*2, ax = 9.00, ay = 9.00;
qaxs5b     : quadrupole, l = 0.025000, k = -0.188245*2, ax = 9.00,
             ay = 9.00;
qays5c     : quadrupole, l = 0.025000, k = 0.144105*2, ax = 9.00, ay = 9.00;
qays5d     : quadrupole, l = 0.025000, k = -0.109044*2, ax = 9.00,
             ay = 9.00;
qaxs5e     : quadrupole, l = 0.025000, k = 0.050947*2, ax = 9.00, ay = 9.00;
qays2a     : quadrupole, l = 0.025000, k = 0.013329*2, ax = 9.00, ay = 9.00;
qaxs2b     : quadrupole, l = 0.025000, k = -0.009141*2, ax = 9.00,
             ay = 9.00;
qays2c     : quadrupole, l = 0.025000, k = 0.006387*2, ax = 9.00, ay = 9.00;
qays2d     : quadrupole, l = 0.025000, k = -0.004862*2, ax = 9.00,
             ay = 9.00;
qaxs2e     : quadrupole, l = 0.025000, k = 0.002236*2, ax = 9.00, ay = 9.00;
qp1        : quadrupole, l = 0.100000, k = -4.647212, ax = 9.00, ay = 9.00;
qp2        : quadrupole, l = 0.100000, k = 9.489580, ax = 9.00, ay = 9.00;
qp3        : quadrupole, l = 0.140000, k = 7.254047, ax = 9.00, ay = 9.00;
qp4        : quadrupole, l = 0.140000, k = -8.300981, ax = 9.00, ay = 9.00;
qp3mo      : quadrupole, l = 0.140000, k = 6.323708, ax = 9.00, ay = 9.00;
qp4mo      : quadrupole, l = 0.140000, k = -6.857166, ax = 9.00, ay = 9.00;
qp6m       : quadrupole, l = 0.100000, k = -9.487761, ax = 9.00, ay = 9.00;
qp3mi      : quadrupole, l = 0.140000, k = 3.365066, ax = 9.00, ay = 9.00;
qp4mi      : quadrupole, l = 0.140000, k = -4.372454, ax = 9.00, ay = 9.00;
qp5m       : quadrupole, l = 0.140000, k = 6.929239, ax = 9.00, ay = 9.00;
qp3l9o     : quadrupole, l = 0.140000, k = 4.356105, ax = 9.00, ay = 9.00;
qp3l9i     : quadrupole, l = 0.140000, k = 3.157959, ax = 9.00, ay = 9.00;
qp4l9o     : quadrupole, l = 0.140000, k = -4.446914, ax = 9.00, ay = 9.00;
qp4l9i     : quadrupole, l = 0.140000, k = -3.009697, ax = 9.00, ay = 9.00;
qp5l9o     : quadrupole, l = 0.100000, k = 5.151850, ax = 9.00, ay = 9.00;
qp5l9i     : quadrupole, l = 0.100000, k = 5.327912, ax = 9.00, ay = 9.00;
qp6l9      : quadrupole, l = 0.070000, k = -7.581518, ax = 9.00, ay = 9.00;
qp3l5i     : quadrupole, l = 0.140000, k = 4.356065, ax = 9.00, ay = 9.00;
qp3l5o     : quadrupole, l = 0.140000, k = 3.158008, ax = 9.00, ay = 9.00;
qp4l5i     : quadrupole, l = 0.140000, k = -4.446890, ax = 9.00, ay = 9.00;
qp4l5o     : quadrupole, l = 0.140000, k = -3.009729, ax = 9.00, ay = 9.00;
qp5l5i     : quadrupole, l = 0.100000, k = 5.151850, ax = 9.00, ay = 9.00;
qp5l5o     : quadrupole, l = 0.100000, k = 5.327914, ax = 9.00, ay = 9.00;
qp6l5      : quadrupole, l = 0.070000, k = -7.581518, ax = 9.00, ay = 9.00;
qp3yi      : quadrupole, l = 0.140000, k = 1.614695, ax = 9.00, ay = 9.00;
qp3yo      : quadrupole, l = 0.140000, k = 4.450442, ax = 9.00, ay = 9.00;
qp4yi      : quadrupole, l = 0.140000, k = -1.296873, ax = 9.00, ay = 9.00;
qp4yo      : quadrupole, l = 0.140000, k = -4.319265, ax = 9.00, ay = 9.00;
qp5yi      : quadrupole, l = 0.100000, k = 0.000000, ax = 9.00, ay = 9.00;
qp6yi      : quadrupole, l = 0.100000, k = 0.000000, ax = 9.00, ay = 9.00;
qp7yi      : quadrupole, l = 0.200000, k = -1.805407, ax = 27.00,
             ay = 16.00;
qp7yo      : quadrupole, l = 0.200000, k = -2.279322, ax = 38.00,
             ay = 20.00;
qp8yi      : quadrupole, l = 0.200000, k = 1.525345, ax = 20.00, ay = 16.00;
qp8yo      : quadrupole, l = 0.200000, k = 1.851133, ax = 20.00, ay = 16.00;

bn         : bending, l = 0.202500, t = 1.740000, k = 0.000000, t1 = 0.000000,
             t2 = 1.740000, ax = 9.00, ay = 9.00;
beh        : bending, l = 0.242500, t = 1.760000, k = 0.000000, t1 = 0.000000,
             t2 = 1.760000, ax = 9.00, ay = 9.00;
bs200      : bending, l = 0.022456, t = 0.289000, k = 0.000000, t1 = 0.000000,
             t2 = 0.288900, ax = 50.00, ay = 50.00;
bs201      : bending, l = 0.025620, t = 0.289100, k = 0.000000, t1 = -0.288900,
             t2 = 0.578000, ax = 50.00, ay = 50.00;
bs202      : bending, l = 0.029680, t = 0.289800, k = 0.000000, t1 = -0.578000,
             t2 = 0.867800, ax = 50.00, ay = 50.00;
bs203      : bending, l = 0.034430, t = 0.289200, k = 0.000000, t1 = -0.867800,
             t2 = 1.157100, ax = 50.00, ay = 50.00;
bs204      : bending, l = 0.040160, t = 0.289400, k = 0.000000, t1 = -1.157100,
             t2 = 1.446400, ax = 50.00, ay = 50.00;
bs205      : bending, l = 0.050160, t = 0.293500, k = 0.000000, t1 = -1.446400,
             t2 = 1.740000, ax = 50.00, ay = 50.00;
bs500      : bending, l = 0.006240, t = 0.212400, k = 0.000000, t1 = 0.000000,
             t2 = 0.212400, ax = 50.00, ay = 50.00;
bs501      : bending, l = 0.006240, t = 0.206500, k = 0.000000, t1 = -0.212400,
             t2 = 0.418900, ax = 50.00, ay = 50.00;
bs502      : bending, l = 0.007800, t = 0.240100, k = 0.000000, t1 = -0.418900,
             t2 = 0.659000, ax = 50.00, ay = 50.00;
bs503      : bending, l = 0.009360, t = 0.248000, k = 0.000000, t1 = -0.659000,
             t2 = 0.907000, ax = 50.00, ay = 50.00;
bs504      : bending, l = 0.010920, t = 0.223500, k = 0.000000, t1 = -0.907000,
             t2 = 1.130500, ax = 50.00, ay = 50.00;
bs505      : bending, l = 0.018720, t = 0.241300, k = 0.000000, t1 = -1.130500,
             t2 = 1.371800, ax = 50.00, ay = 50.00;
bs506      : bending, l = 0.035880, t = 0.246800, k = 0.000000, t1 = -1.371800,
             t2 = 1.618600, ax = 50.00, ay = 50.00;
bs507      : bending, l = 0.105310, t = 0.121400, k = 0.000000, t1 = -1.618600,
             t2 = 1.740000, ax = 50.00, ay = 50.00;

sd1        : sextupole, l = 0.080000, k = -530.468142, n = 3, ax = 9.00,
             ay = 9.00;
sd2        : sextupole, l = 0.080000, k = -500.062556, n = 3, ax = 9.00,
             ay = 9.00;
sd3        : sextupole, l = 0.080000, k = -535.936359, n = 3, ax = 9.00,
             ay = 9.00;
sd4        : sextupole, l = 0.080000, k = -532.935703, n = 3, ax = 9.00,
             ay = 9.00;
sd5        : sextupole, l = 0.080000, k = -479.396334, n = 3, ax = 9.00,
             ay = 9.00;
sf1        : sextupole, l = 0.080000, k = 422.257752, n = 3, ax = 9.00,
             ay = 9.00;
sf2        : sextupole, l = 0.080000, k = 569.664254, n = 3, ax = 9.00,
             ay = 9.00;
sfm        : sextupole, l = 0.080000, k = 517.868024, n = 3, ax = 9.00,
             ay = 9.00;
sdm        : sextupole, l = 0.090000, k = -522.554000, n = 3, ax = 9.00,
             ay = 9.00;
sxx        : sextupole, l = 0.090000, k = 397.222222, n = 3, ax = 9.00,
             ay = 9.00;
sxy        : sextupole, l = 0.090000, k = -605.555556, n = 3, ax = 9.00,
             ay = 9.00;
syy        : sextupole, l = 0.090000, k = 383.333333, n = 3, ax = 9.00,
             ay = 9.00;

k1         : kicker, l = 0.600000, n = 1,  k = -1.607,  x = 0.000,  t = 6.000,
              delay = 7.238 nk = 1, ax = 43.00, ay = 15.00;
k2         : kicker, l = 0.600000, n = 1,  k = 1.297,  x = 0.000,  t = 6.000,
              delay = 10.807 nk = 1, ax = 43.00, ay = 15.00;
k3         : kicker, l = 0.600000, n = 1,  k = 2.880,  x = 0.000,
              t = 1000.000,  delay = 5.987 nk = 1, ax = 46.00, ay = 14.00;
k4         : kicker, l = 0.600000, n = 1,  k = -3.080,  x = 0.000,
              t = 1000.000,  delay = 9.557 nk = 1, ax = 46.00, ay = 14.00;
sept       : kicker, l = 0.300000, n = 1,  k = 0.000,  x = 0.000,
              t = 100000.000,  delay = 33.590 nk = 1, ax = 5.00, ay = 10.95;
fk1        : kicker, l = 0.800000, n = 1,  k = -0.585,  x = 0.000,  t = 0.010,
              delay = 70.949 nk = 1, ax = 5.00, ay = 4.00;
fk2        : kicker, l = 0.800000, n = 1,  k = -0.585,  x = 0.000,  t = 0.010,
              delay = 80.656 nk = 1, ax = 5.00, ay = 4.00;

otr5       : opticsmarker, betax = 1.000000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000000,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000,
             ax = 32.00, ay = 16.00;
otr9       : opticsmarker, betax = 1.000000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000000,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000,
             ax = 32.00, ay = 16.00;
oss        : opticsmarker, betax = 23.000000, alphax = 0.000002,
             betay = 6.644610, alphay = 0.481358, etax  = 0.000000,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000,
             ax = 30.00, ay = 9.00;
oqm3       : opticsmarker, betax = 1.000000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000000,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;
bsom       : opticsmarker, betax = 0.200000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000140,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;
bsc5om     : opticsmarker, betax = 0.200000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000140,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;
bsc4om     : opticsmarker, betax = 0.200000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000140,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;
bsc21m     : opticsmarker, betax = 0.200000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000140,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;
bnnom      : opticsmarker, betax = 0.178367, alphax = 0.000000,
             betay = 4.615774, alphay = 0.000000, etax  = 0.005825,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;
obe        : opticsmarker, betax = 1.000000, alphax = 0.000000,
             betay = 1.000000, alphay = 0.000000, etax  = 0.000000,
             etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 9.00,
             ay = 9.00;

vb         : combined, l = 0.185000, t = 1.000000, k = -4.515802,
             t1 = -1.740000, t2 = 0.500000, ax = 9.00, ay = 9.00;
vbx        : combined, l = 0.185000, t = 1.000000, k = -3.678870,
             t1 = -1.740000, t2 = 0.500000, ax = 9.00, ay = 9.00;
ve         : combined, l = 0.240000, t = 1.000000, k = -5.081460,
             t1 = 1.000000, t2 = 0.000000, ax = 9.00, ay = 9.00;
an         : combined, l = 0.140000, t = -0.240000, k = 8.622495,
             t1 = -0.240000, t2 = 0.000000, ax = 9.00, ay = 9.00;
anm        : combined, l = 0.150000, t = -0.260000, k = 9.201779,
             t1 = -0.260000, t2 = 0.000000, ax = 9.00, ay = 9.00;

src_superb : photonbeam, xl = 2.20, style = 1, snap = 1, ax = 9.00,
             ay = 9.00;
src_dip    : photonbeam, xl = 0.00, style = 2, snap = 1, ax = 9.00,
             ay = 9.00;
src_str_s  : photonbeam, xl = 2.50, style = 1, snap = 1, ax = 9.00,
             ay = 9.00;
src_str_m  : photonbeam, xl = 2.50, style = 1, snap = 1, ax = 9.00,
             ay = 9.00;
src_str_l  : photonbeam, xl = 2.80, style = 0, snap = 1, ax = 9.00,
             ay = 9.00;
src_endb   : photonbeam, xl = 0.00, style = 2, snap = 1, ax = 9.00,
             ay = 9.00;
gin_sec    : photonbeam, xl = 0.00, style = 0, snap = 1, ax = 9.00,
             ay = 9.00;

gsept      : girder, typ = 0, shift = 0.00000, ax = 50.00, ay = 50.00;
g1         : girder, typ = 1, shift = 0.00000, ax = 9.00, ay = 9.00;
g0         : girder, typ = 0, shift = 0.00000, ax = 30.00, ay = 9.00;
bevc       : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
lgbn       : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
lgbe       : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
lgbs5      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
lgbs2      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
soqxx      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
soqxy      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
soqyy      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
soqcxn     : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
soqcxe     : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
soqcyn     : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
sxqcye     : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
chv        : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup1       : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup2       : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup3s      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup4s      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup3y      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup4y      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup5y      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup6y      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup7y      : girder, typ = 3, shift = 0.00000, ax = 38.00, ay = 20.00;
qup8y      : girder, typ = 3, shift = 0.00000, ax = 38.00, ay = 20.00;
qup3l      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup4l      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup5l      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup6l      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup3m      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup4m      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup5m      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
qup6m      : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
bpm        : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;
cormony    : girder, typ = 3, shift = 0.00000, ax = 9.00, ay = 9.00;

ocx1       : multipole, n = 4,  k = -133.33333333,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
ocx2       : multipole, n = 4,  k = -140.09666667,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
ocxm       : multipole, n = 4,  k = -60.39166667,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
ocy1       : multipole, n = 4,  k = 208.12833333,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
ocy2       : multipole, n = 4,  k = -82.46333333,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
oxx        : multipole, n = 4,  k = 316.66666667,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
oxy        : multipole, n = 4,  k = -195.09000000,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;
oyy        : multipole, n = 4,  k = -14.37833333,  lmag = 0.0500, ax = 9.00,
             ay = 9.00;

mon        : monitor, ax = 30.00, ay = 30.00;
injmon     : monitor, ax = 32.00, ay = 32.00;

ch         : h-corrector, ax = 32.50, ay = 20.00;

cv         : v-corrector, ax = 32.50, ay = 20.00;


{----- table of segments ---------------------------------------------}

corr         : dcsoq, chv, dcc, ch, dchv, cv, dcc, chv, bpm, dbpm, mon, dbpm,
               bpm, dmon;
corrd        : dcsoq, chv, dcc, ch, dchv, cv, dcc, chv, ddx, bpm, dbpm, mon,
               dbpm, bpm, dmon;
corm1l       : cormony, dyco, ch, dycb, mon, special1l, dycb, cv, dyco,
               cormony;
dabsd        : ddx, dabs;
extrabpm     : bpm, dbpm, mon, dbpm, bpm;
qdp1         : qup1, dqua, qp1, dqua, qup1;
qdp2         : qup2, dqua, qp2, dqua, qup2;
qdp3s        : qup3s, dqua, qp3, dqua, qup3s;
qdp4s        : qup4s, dqua, qp4, dqua, qup4s;
qdp3mi       : qup3m, dqua, qp3mi, dqua, qup3m;
qdp4mi       : qup4m, dqua, qp4mi, dqua, qup4m;
qdp6m        : qup6m, dqua, qp6m, dqua, qup6m;
qdp3mo       : qup3m, dqua, qp3mo, dqua, qup3m;
qdp4mo       : qup4m, dqua, qp4mo, dqua, qup4m;
qdp5m        : qup5m, dqua, qp5m, dqua, qup6m;
qdp3l5i      : qup3l, dqua, qp3l5i, dqua, qup3l;
qdp4l5i      : qup4l, dqua, qp4l5i, dqua, qup4l;
qdp5l5i      : qup5l, dqua, qp5l5i, dqua, qup5l;
qdp3l5o      : qup3l, dqua, qp3l5o, dqua, qup3l;
qdp4l5o      : qup4l, dqua, qp4l5o, dqua, qup4l;
qdp5l5o      : qup5l, dqua, qp5l5o, dqua, qup5l;
qdp3l9i      : qup3l, dqua, qp3l9i, dqua, qup3l;
qdp4l9i      : qup4l, dqua, qp4l9i, dqua, qup4l;
qdp5l9i      : qup5l, dqua, qp5l9i, dqua, qup5l;
qdp3l9o      : qup3l, dqua, qp3l9o, dqua, qup3l;
qdp4l9o      : qup4l, dqua, qp4l9o, dqua, qup4l;
qdp5l9o      : qup5l, dqua, qp5l9o, dqua, qup5l;
qdp3yo       : qup3y, dqua, qp3yo, dqua, qup3y;
qdp4yo       : qup4y, dqua, qp4yo, dqua, qup4y;
qdp7yo       : qup7y, dquail, qp7yo, dquaim, qup7y;
qdp8yo       : qup8y, dquaim, qp8yo, dquais, qup8y;
qdp3yi       : qup3y, dqua, qp3yi, dqua, qup3y;
qdp4yi       : qup4y, dqua, qp4yi, dqua, qup4y;
qdp5yi       : qup5y, dqua, qp5yi, dqua, qup5y;
qdp6yi       : qup6y, dqua, qp6yi, dqua, qup6y;
qdp7yi       : qup7y, dquaim, qp7yi, dquaim, qup7y;
qdp8yi       : qup8y, dquaim, qp8yi, dquais, qup8y;
bnl          : bnnom, bn, vb, lgbn, dbspac;
bnlx         : bnnom, bn, vbx, lgbn, dbspac;
bs2          : bs200, bs201, bs202, bs203, bs204, bs205;
bs5          : bs500, bs501, bs502, bs503, bs504, bs505, bs506, bs507;
bsl2         : bsc21m, bs2, lgbs2, dbs2, vb, dbspac;
bsl5         : bsc5om, bs5, lgbs5, dbs5, vb, dbspac;
be           : lgbe, beh, src_endb, lgbe;
mcy1         : soqcyn, doc, qay, ocy1, qac, cs, doc, dos, dsx, sd1, dsx,
               soqcyn;
mcy2         : soqcyn, doc, qay, ocy1, qac, cs, doc, dos, dsx, sd2, dsx,
               soqcyn;
mcy3         : soqcyn, doc, qay, ocy2, qac, cs, doc, dos, dsx, sd3, dsx,
               soqcyn;
mcy4         : soqcyn, doc, qay, ocy2, qac, cs, doc, dos, dsx, sd4, dsx,
               soqcyn;
mcy5         : soqcyn, doc, qay, ocy2, qac, cs, doc, dos, dsx, sd5, dsx,
               soqcyn;
mcye         : sxqcye, dsx, sdm, dsx, sxqcye;
mcy1s5a      : soqcyn, doc, qays5a, ocy1, qac, cs, doc, dos, dsx, sd1, dsx,
               soqcyn;
mcy1s5c      : soqcyn, doc, qays5c, ocy1, qac, cs, doc, dos, dsx, sd2, dsx,
               soqcyn;
mcy1s2a      : soqcyn, doc, qays2a, ocy1, qac, cs, doc, dos, dsx, sd1, dsx,
               soqcyn;
mcy1s2c      : soqcyn, doc, qays2c, ocy1, qac, cs, doc, dos, dsx, sd2, dsx,
               soqcyn;
mcy2s5d      : soqcyn, doc, qays5d, ocy2, qac, cs, doc, dos, dsx, sd3, dsx,
               soqcyn;
mcy2s2d      : soqcyn, doc, qays2d, ocy2, qac, cs, doc, dos, dsx, sd3, dsx,
               soqcyn;
mcx1         : ddx, soqcxn, doc, qax, ocx1, qac, cs, doc, dos, dsx, sf1, dsx,
               soqcxn;
mcx1o        : ddx, soqcxn, doc, qax, ocx1, qac, cs, doc, dos, dsx;
mcx1i        : sf1, dsx, soqcxn;
mcx2         : ddx, soqcxn, doc, qax, ocx2, qac, cs, doc, dos, dsx, sf2, dsx,
               soqcxn;
mcxei        : ddx, soqcxe, doc, qaxmi, ocxm, qac, cs, doc, dos, dsx, sfm, dsx,
               soqcxe;
mcxeo        : ddx, soqcxe, doc, qaxmo, ocxm, qac, cs, doc, dos, dsx, sfm, dsx,
               soqcxe;
mcx1s5b      : ddx, soqcxn, doc, qaxs5b, ocx1, qac, cs, doc, dos, dsx, sf1,
               dsx, soqcxn;
mcx1s2b      : ddx, soqcxn, doc, qaxs2b, ocx1, qac, cs, doc, dos, dsx, sf1,
               dsx, soqcxn;
mcx2s5e      : ddx, soqcxn, doc, qaxs5e, ocx2, qac, cs, doc, dos, dsx, sf2,
               dsx, soqcxn;
mcx2s2e      : ddx, soqcxn, doc, qaxs2e, ocx2, qac, cs, doc, dos, dsx, sf2,
               dsx, soqcxn;
mxy          : soqxy, doc, qaxy, oxy, qac, cs, doc, dos, dsx, sxy, dsx,
               soqxy;
mxx          : soqxx, doc, qaxx, oxx, qac, cs, doc, dos, dsx, sxx, dsx,
               soqxx;
myy          : soqyy, doc, qayy, oyy, qac, cs, doc, dos, dsx, syy, dsx,
               soqyy;
hnca1        : bnl, g1, g1, -mcy1, dabsd, an, fn;
hncc1        : bnl, g1, g1, -mcy1, corrd, an, fn;
hncc1g       : bnl, -mcy2, corrd, an, fn;
hnca1g       : bnl, -mcy2, dabsd, an, fn;
hnca2        : bnlx, g1, g1, -mcy5, dabsd, an, fn;
hncc2        : bnlx, g1, g1, -mcy5, corrd, an, fn;
hncc2g3      : bnl, -mcy3, corrd, an, fn;
hnca2g3      : bnl, -mcy3, dabsd, an, fn;
hncc2g4      : bnl, -mcy4, corrd, an, fn;
hnca2g4      : bnl, -mcy4, dabsd, an, fn;
ncell        : hnca1, mcx1, -hncc1;
ncellr       : mcx1i, -hncc1, hnca1, mcx1o;
m0           : src_dip, bnl, -mcy4, -dabsd, an, fn, -mcx2, fn, -an, -corrd,
               mcy2, -bnl, src_dip, bnl, -mcy1, -dabsd, an, fn, -mcx1, fn, -an,
               -corrd, mcy1, g1, g1, -bnl;
m5           : src_dip, bnl, -mcy4, -dabsd, an, fn, -mcx2s5e, fn, -an, -corrd,
               mcy2s5d, -bnl, src_dip, bnl, -mcy1s5c, -dabsd, an, fn, -mcx1s5b,
               fn, -an, -corrd, mcy1s5a, g1, g1, -bsl5;
match5       : m5, src_superb, bsl5, g1, g1, -mcy1s5a, -dabsd, an, fn, mcx1s5b,
               fn, -an, -corrd, mcy1s5c, -bnl, src_dip, bnl, -mcy2s5d, -dabsd,
               an, fn, mcx2s5e, fn, -an, -corrd, mcy4, -bnl, src_dip;
m2           : src_dip, bnl, -mcy4, -dabsd, an, fn, -mcx2s2e, fn, -an, -corrd,
               mcy2s2d, -bnl, src_dip, bnl, -mcy1s2c, -dabsd, an, fn, -mcx1s2b,
               fn, -an, -corrd, mcy1s2a, g1, g1, -bsl2;
match2       : m2, src_superb, bsl2, g1, g1, -mcy1s2a, -dabsd, an, fn, mcx1s2b,
               fn, -an, -corrd, mcy1s2c, -bnl, src_dip, bnl, -mcy2s2d, -dabsd,
               an, fn, mcx2s2e, fn, -an, -corrd, mcy4, -bnl, src_dip;
hcori        : hncc1, mcx1, -hnca1g, src_dip, hncc2g3, mcx2, -hnca2g4,
               src_dip;
hcoro        : hnca1, mcx1, -hncc1g, src_dip, hnca2g3, mcx2, -hncc2g4,
               src_dip;
dsupi        : hncc2, mcxei, fn, -anm, -dabsd, dmat, ve, fn, mcye, fn, be,
               dbspace, corr;
dsupo        : hnca2, mcxeo, fn, -anm, -corrd, dmat, ve, fn, mcye, fn, be,
               dbspace, dbe1, extrabpm, dbe2;
arc          : -dsupi, -hcori, src_dip, hcoro, dsupo;
arc5         : -dsupi, match5, dsupo;
arc2         : -dsupi, match2, dsupo;
matc         : myy, fn, qdp1, fn, mxy, fn, qdp2, fn, mxx, fn;
matso        : matc, qdp3s, -corr, qdp4s, dvv, g0, gin_sec;
matsi        : matc, qdp3s, corr, qdp4s, dvv, g0;
matmo        : matc, qdp3mo, -corr, qdp4mo, dvv, g0, gin_sec;
matmi        : matc, qdp3mi, corr, qdp4mi, dvv, g0, dem4, qdp5m, corr,
               qdp6m;
matl5o       : matc, qdp3l5o, -corr, qdp4l5o, dvv, g0, gin_sec;
matl5i       : matc, qdp3l5i, corr, qdp4l5i, dvv, g0;
matl9o       : matc, qdp3l9o, -corr, qdp4l9o, dvv, g0, gin_sec;
matl9i       : matc, qdp3l9i, corr, qdp4l9i, dvv, g0;
matyo        : matc, qdp3yo, -corr, qdp4yo, dvv, g0, gin_sec;
matyi        : matc, qdp3yi, corr, qdp4yi, dvv, g0;
tripl5o      : g0, qdp5l5o, -corr, dlcqt, qup6l, dqua, qp6l5;
tripl5i      : g0, qdp5l5i, dlqqt, qup6l, dqua, qp6l5;
tripl9o      : g0, qdp5l9o, dlqqt, qup6l, dqua, qp6l9;
tripl9i      : g0, qdp5l9i, corr, dlcqt, qup6l, dqua, qp6l9;
injo         : d145, dktap, dflk, dkin, k1, dkin, dflk, dnoq, dflk, dkin, k2,
               dkin, dflk, dnoq, dflk, dkin, pinger, dkin, dflk, dylong, dsep,
               injmon, sep1, midlong, sep2, injmon, dsep, injmon, dqsep, g0,
               qdp7yo, dycq, corm1l, dyqmo, qdp8yo, dsept, injmon, sept,
               injmon, oss, dsept, mmm, gsept;
inji         : d145, dktap, dflk, dkin, k4, dkin, dflk, dnoq, dflk, dkin, k3,
               dkin, dflk, g0, dycq, corm1l, dycq, qdp7yi, dyqmi, dysi2,
               ossmon, dysi1, qdp8yi, gsept;
injo_nok     : d145, dktap, dflk, dkin, no_k, dkin, dflk, dnoq, dflk, dkin,
               no_k, dkin, dflk, dnoq, dflk, dkin, pinger, dkin, dflk, dylong,
               dsep, injmon, sep1, midlong, sep2, injmon, dsep, injmon, dqsep,
               g0, qdp7yo, dycq, corm1l, dyqmo, qdp8yo, dsept, injmon, sept,
               injmon, oss, dsept, mmm, gsept;
inji_nok     : d145, dktap, dflk, dkin, no_k, dkin, dflk, dnoq, dflk, dkin,
               no_k, dkin, dflk, g0, dycq, corm1l, dycq, qdp7yi, dyqmi, dysi2,
               ossmon, dysi1, qdp8yi, gsept;
lhalf5a      : lqua5a, src_str_l, lqua5a;
lhalf5b      : lqua5b, src_str_l, lqua5b2, midlong, lqua5b1;
lhalf9a      : lqua9a, src_str_l, lqua9a1, midlong, lqua9a2;
lhalf9b      : lqua9b, src_str_l, lqua9b;
hmso         : hcoro, dsupo, matso, shalf, nper=24;
hmsi         : hcori, dsupi, matsi, shalf, nper=24;
hmmo         : hcoro, dsupo, matmo, mhalf, nper=24;
hmmi         : hcori, dsupi, matmi, mhalf, nper=24;
hml5o        : hcoro, dsupo, matl5o, lhalf5a, tripl5o, nper=24;
hml5i        : hcori, dsupi, matl5i, lhalf5b, otr5, tripl5i, nper=24;
hml9o        : hcoro, dsupo, matl9o, lhalf9a, tripl9o, nper=24;
hml9i        : hcori, dsupi, matl9i, lhalf9b, otr9, tripl9i, nper=24;
hmyo         : hcoro, dsupo, matyo, injo, nper=24;
hmyi         : hcori, dsupi, matyi, inji, nper=24;
shrt         : hmso, src_str_s, -hmsi, nper=12;
midi         : hmmo, src_str_m, -hmmi, nper=12;
long5        : hml5o, src_str_l, -hml5i, nper=12;
long9        : hml9o, src_str_l, -hml9i, nper=12;
yinj         : hmyo, -hmyi, nper=12;
s_u4         : matso, scut4, und4h, src_str_s, und4h, scut4, -matsi;
m_u8         : matmo, mcut8, und8, mcut8, src_str_m, mcut8, und81, midmedi,
               und82, mcut8, -matmi;
lstr5        : matl5o, lhalf5a, tripl5o, -tripl5i, -lhalf5b, -matl5i;
lstr9        : matl9o, lhalf9a, tripl9o, -tripl9i, -lhalf9b, -matl9i;
sec01i       : -inji, -matyi, arc;
sec01i_nok   : -inji_nok, -matyi, arc;
sec01s1i     : -inji, -matyi, arc2;
sec01s1i_nok : -inji_nok, -matyi, arc2;
sec01s2i     : -inji, -matyi, arc5;
sec01s2i_nok : -inji_nok, -matyi, arc5;
sk02         : dfk1, fk1, dfk2, sfkcut, src_str_s, sfkcut, dfk2, fk2, dfk1;
sk02_nok     : dfk1, no_fk1, dfk2, sfkcut, src_str_s, sfkcut, dfk2, no_fk2,
               dfk1;
sec02        : matso, sk02, -matsi, arc;
sec02_nok    : matso, sk02_nok, -matsi, arc;
sec02s1      : matso, sk02, -matsi, arc2;
sec02s2      : matso, sk02, -matsi, arc5;
sec02s1_nok  : matso, sk02_nok, -matsi, arc2;
sec02s2_nok  : matso, sk02_nok, -matsi, arc5;
sec03        : m_u8, arc;
sec04        : s_u4, arc;
sec05        : lstr5, arc;
sec06s       : s_u4, arc2;
sec06        : s_u4, arc;
sec07        : m_u8, arc;
sec08        : s_u4, arc;
sec09        : lstr9, arc;
sec10s1      : s_u4, arc2;
sec10s2      : s_u4, arc2;
sec10        : s_u4, arc;
sec11        : m_u8, arc;
sec12        : s_u4, arc;
sec01o       : matyo, injo;
sec01o_nok   : matyo, injo_nok;
sec01        : sec01o, sec01i;
arcs         : -hmsi, hmso, nper=12;
arcs5        : shalf, -matsi, arc5, matso, shalf;
arcm         : -hmmi, hmmo, nper=12;
arcl         : -hml5i, hml5o, nper=12;
mplot        : dnoq, -bnl, bnl, dnoq, -bsl2, bsl2, dnoq, -bsl5, bsl5, dnoq;
plotsm       : -hmsi, hmmo;
inj12        : sec01i, sec02;
ring0        : sec01i, sec02, sec03, sec04, center, sec05, sec06, sec07, sec08,
               center, sec09, sec10, sec11, sec12, center, sec01o;
rings1       : sec01s1i, sec02s1, sec03, sec04, center, sec05, sec06s, sec07,
               sec08, center, sec09, sec10s1, sec11, sec12, center, sec01o;
rings2       : sec01s2i, sec02s2, sec03, sec04, center, sec05, sec06s, sec07,
               sec08, center, sec09, sec10s2, sec11, sec12, center, sec01o;
rings1_nok   : sec01s1i_nok, sec02s1_nok, sec03, sec04, center, sec05, sec06s,
               sec07, sec08, center, sec09, sec10s1, sec11, sec12, center,
               sec01o_nok;
rings2_nok   : sec01s2i_nok, sec02s2_nok, sec03, sec04, center, sec05, sec06s,
               sec07, sec08, center, sec09, sec10s2, sec11, sec12, center,
               sec01o_nok;
ringmpo      : injo, sec01s2i, sec02s2, sec03, sec04, center, sec05, sec06s,
               sec07, sec08, center, sec09, sec10s2, sec11, sec12, center,
               matyo;

{c:\as\opa\sls-2\b073_002_cs.opa}
