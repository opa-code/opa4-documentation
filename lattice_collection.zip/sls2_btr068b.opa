{c:\as\opa\sls-2\btr068b.opa}

allocation  = btr_lookup.dat;
calibration = bobrtype.dat;

energy = 2.700000;

    betax   = 2.3873600; alphax  = -1.1923100;
    etax    = 0.2029460; etaxp   = 0.0989340;
    betay   = 6.6630400; alphay  = 1.7823000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- variables ---------------------------------------------------}

gayin  = 6.79041826702047;
gab23  = 6.77824936648976;
glc4   = 0.935148325477994;

{----- table of elements ---------------------------------------------}

bd00    : drift, l = 1.440000, ax = 19.00, ay = 19.00;
bd22    : drift, l = 0.220000, ax = 19.00, ay = 19.00;
bdex    : drift, l = 0.200000, ax = 19.00, ay = 19.00;
dsep    : drift, l = 0.200000, block, ax = 19.00, ay = 19.00;
dsep2   : drift, l = 0.162000, block, ax = 19.00, ay = 19.00;
dqsl    : drift, l = 0.030000, block, ax = 50.00, ay = 50.00;
dbg     : drift, l = 0.100000, block, ax = 50.00, ay = 50.00;
dfa     : drift, l = 0.060000, block, ax = 19.00, ay = 19.00;
dcor    : drift, l = 0.100000, block, ax = 19.00, ay = 19.00;
dsics   : drift, l = 0.063000, block, ax = 19.00, ay = 19.00;
dsici   : drift, l = 0.079600, block, ax = 19.00, ay = 19.00;
dsicm   : drift, l = 0.145900, block, ax = 19.00, ay = 19.00;
dbsi    : drift, l = 0.211500, ax = 19.00, ay = 19.00;
dqsi    : drift, l = 0.081500, ax = 19.00, ay = 19.00;
dbq     : drift, l = 0.200000, ax = 19.00, ay = 19.00;
dcq     : drift, l = 0.160000, ax = 19.00, ay = 19.00;
dbb     : drift, l = 0.130000, ax = 19.00, ay = 19.00;
dqq     : drift, l = 0.160000, ax = 19.00, ay = 19.00;
la1     : drift, l = 1.450000, ax = 19.00, ay = 19.00;
la2     : drift, l = 0.500000, ax = 19.00, ay = 19.00;
la3     : drift, l = 0.170000, ax = 19.00, ay = 19.00;
lb1     : drift, l = 0.200000, ax = 19.00, ay = 19.00;
dmm     : drift, l = 0.840000, ax = 19.00, ay = 19.00;
lc1     : drift, l = 0.280000, ax = 19.00, ay = 19.00;
lc2     : drift, l = 0.210000, ax = 19.00, ay = 19.00;
lc3     : drift, l = 1.080000, ax = 19.00, ay = 19.00;
lc4     : drift, l = glc4, ax = 19.00, ay = 19.00;
meter   : drift, l = 1.000000, ax = 19.00, ay = 19.00;
dxxxx   : drift, l = 0.000010, ax = 19.00, ay = 19.00;

qx      : quadrupole, l = 0.220000, k = 0.726166, ax = 19.00, ay = 19.00;
qfa     : quadrupole, l = 0.150000, k = 2.028300, ax = 19.00, ay = 19.00;
qfb1    : quadrupole, l = 0.150000, k = -2.281108, ax = 19.00, ay = 19.00;
qfb2    : quadrupole, l = 0.150000, k = 0.000000, ax = 19.00, ay = 19.00;
qfb3    : quadrupole, l = 0.150000, k = 2.573098, ax = 19.00, ay = 19.00;
qfb4    : quadrupole, l = 0.150000, k = 0.226532, ax = 19.00, ay = 19.00;
qc1     : quadrupole, l = 0.400000, k = -1.333530, ax = 19.00, ay = 19.00;
qc2     : quadrupole, l = 0.400000, k = 0.816871, ax = 19.00, ay = 19.00;
qc3     : quadrupole, l = 0.400000, k = 1.172222, ax = 19.00, ay = 19.00;
qc4     : quadrupole, l = 0.400000, k = -1.127370, ax = 19.00, ay = 19.00;

b1h     : bending, l = 0.550000, t = 4.100000, k = 0.000000, t1 = 4.100000,
          t2 = 0.000000, ax = 19.00, ay = 19.00;
b23     : bending, l = 1.100000, t = gab23, k = 0.000000, t1 = gab23/2,
          t2 = gab23/2, ax = 19.00, ay = 19.00;
bkex    : bending, l = 1.000000, t = -0.280000, k = 0.000000, t1 = 0.000000,
          t2 = -0.280000, ax = 19.00, ay = 19.00;
byex1   : bending, l = 0.520000, t = -6.470000/2, k = 0.000000, t1 = 0.000000,
          t2 = -6.470000/2, ax = 19.00, ay = 19.00;
byex2   : bending, l = 0.520000, t = -6.470000/2, k = 0.000000, t1 = 6.47/2,
          t2 = -6.470000, ax = 19.00, ay = 19.00;
syin    : bending, l = 1.500000, t = gayin, k = 0.000000, t1 = 0.000000,
          t2 = 0.000000, gap = 9.0000, k1 = 0.5000, ax = 10.00, ay = 3.00;

obr     : opticsmarker, betax = 2.457794, alphax = -0.890083, betay = 8.363340,
          alphay = 2.110046, etax  = 0.217358, etaxp  = 0.106068,
          etay  = 0.000000, etayp  = 0.000000, ax = 19.00, ay = 19.00;
obw     : opticsmarker, betax = 2.677000, alphax = -0.605000, betay = 9.920000,
          alphay = 2.675000, etax  = 0.219000, etaxp  = 0.099000,
          etay  = 0.000000, etayp  = 0.000000, ax = 19.00, ay = 19.00;
od2r    : opticsmarker, betax = 38.796452, alphax = -7.533751,
          betay = 12.871447, alphay = -1.562828, etax  = 0.001293,
          etaxp  = 0.000208, etay  = 0.000000, etayp  = 0.000000, ax = 19.00,
          ay = 19.00;
os1     : opticsmarker, betax = 16.205807, alphax = -0.429981,
          betay = 11.817994, alphay = -0.905018, etax  = 0.080007,
          etaxp  = 0.000001, etay  = 0.000000, etayp  = 0.000000, ax = 19.00,
          ay = 19.00;
osm2    : opticsmarker, betax = 0.358845, alphax = 0.138557, betay = 38.393741,
          alphay = -5.756557, etax  = 0.589046, etaxp  = -0.086788,
          etay  = 0.000000, etayp  = 0.000000, screen, ax = 19.00,
          ay = 19.00;
oyex    : opticsmarker, betax = 6.789028, alphax = -2.444383, betay = 3.226912,
          alphay = 1.051812, etax  = 0.265466, etaxp  = -0.013837,
          etay  = 0.000000, etayp  = 0.000000, ax = 19.00, ay = 19.00;
osm3    : opticsmarker, betax = 16.859763, alphax = 4.928665, betay = 5.242809,
          alphay = 0.635442, etax  = 0.253156, etaxp  = -0.087280,
          etay  = 0.000000, etayp  = 0.000000, screen, ax = 19.00,
          ay = 19.00;
osm4    : opticsmarker, betax = 4.080273, alphax = 2.262944, betay = 3.829946,
          alphay = 0.159642, etax  = 0.098061, etaxp  = -0.087280,
          etay  = 0.000000, etayp  = 0.000000, screen, ax = 19.00,
          ay = 19.00;
obd6eex : opticsmarker, betax = 2.387360, alphax = -1.192310, betay = 6.663040,
          alphay = 1.782300, etax  = 0.202946, etaxp  = 0.098934,
          etay  = 0.000000, etayp  = 0.000000, ax = 19.00, ay = 19.00;
osm1    : opticsmarker, betax = 1.000000, alphax = 0.000000, betay = 1.000000,
          alphay = 0.000000, etax  = 0.000000, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, screen, ax = 19.00,
          ay = 19.00;

cdh     : combined, l = 0.630000, t = 3.220500, k = -0.386000, t1 = 3.220500,
          t2 = 0.000000, m = -1.22, n = 1, ax = 19.00, ay = 19.00;
cfh     : combined, l = 0.500000, t = 0.564800, k = 0.582000, t1 = 0.564800,
          t2 = 0.000000, m = 0.875, n = 1, ax = 19.00, ay = 19.00;

bend    : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;
qb      : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;
ql      : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;
qs      : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;
yin     : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;
yex     : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;
smon    : girder, typ = 3, shift = 0.00000, ax = 50.00, ay = 50.00;

monx    : monitor, ax = 19.00, ay = 19.00;
mon     : monitor, ax = 19.00, ay = 19.00;

ch      : h-corrector, ax = 19.00, ay = 19.00;
chx     : h-corrector, ax = 19.00, ay = 19.00;

cv      : v-corrector, ax = 19.00, ay = 19.00;
cvx     : v-corrector, ax = 19.00, ay = 19.00;


{----- table of segments ---------------------------------------------}

chuse   : ch;
cvuse   : cv;
monuse  : mon;
sicu1   : smon, dsics, dsici, monuse, dsicm, smon;
sicu2   : smon, dsics, osm2, dsici, monuse, dsicm, smon;
sicu3   : smon, dsics, osm3, dsici, monuse, dsicm, smon;
sicu4   : smon, dsics, osm4, dsici, monuse, dsicm, smon;
byex    : yex, byex1, chuse, byex2, yex;
b1      : bend, dbg, b1h, chuse, -b1h, dbg, bend;
b23g    : bend, dbg, b23, dbg, bend;
ccv     : dcor, cv, dcor;
cch     : dcor, ch, dcor;
ccvuse  : dcor, cvuse, dcor;
cchuse  : dcor, chuse, dcor;
qxm     : qs, dqsl, qx, dqsl, qs;
qc1m    : ql, dqsl, qc1, dqsl, ql;
qc2m    : ql, dqsl, qc2, dqsl, ql;
qc3m    : ql, dqsl, qc3, dqsl, ql;
qc4m    : ql, dqsl, qc4, dqsl, ql;
qb1     : qb, dfa, qfb1, dfa, qb, qb, dfa, qfb1, dfa, qb;
qb2     : qb, dfa, qfb2, dfa, qb, qb, dfa, qfb2, dfa, qb;
qb3     : qb, dfa, qfb3, dfa, qb, qb, dfa, qfb3, dfa, qb;
qb4     : qb, dfa, qfb4, dfa, qb, qb, dfa, qfb4, dfa, qb;
qa      : qb, dfa, qfa, dfa, qb, qb, dfa, qfa, dfa, qb;
bf      : cfh, -cfh;
bd      : cdh, -cdh;
boo     : obw, bd22, bkex, bd22, bf, bd00, bd;
ext     : la1, qxm, dqsi, -sicu1, la2, ccvuse, dcq, qa, la3;
mes     : lb1, ccvuse, dcq, qb1, dqq, qb2, dqq, qb3, dqq, qb4, dmm, -sicu2,
          dbsi;
inj     : dbq, qc1m, dcq, ccv, lc1, qc2m, dqsi, -sicu3, lc2, cch, dcq, qc3m,
          lc3, ccv, dcq, qc4m, dcq, cch, lc4, -sicu4, dbsi;
sepin   : dsep2, yin, dsep, syin, dsep, yin;
br0     : obd6eex, bdex, byex, oyex, ext, b1, mes, b23g, dbb, b23g, inj;
brmatch : br0, sepin;
full    : boo, brmatch;
steer   : brmatch, mon, meter, mon;

{c:\as\opa\sls-2\btr068b.opa}
