{c:\users\streun\opadat\sls-optics\sls_f6cwo.opa}

allocation  = lookup.dat;
calibration = opatype.dat;

energy = 2.411000;

    betax   = 4.4946639; alphax  = -0.0003146;
    etax    = -0.0001920; etaxp   = -0.0000004;
    betay   = 4.9924087; alphay  = 0.0014954;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

dmon  : drift, l = 0.062500, ax = 50.00, ay = 50.00;
dsxm  : drift, l = 0.072500, ax = 50.00, ay = 50.00;
d1    : drift, l = 0.385000, ax = 32.50, ay = 16.00;
d2    : drift, l = 0.415000, ax = 32.50, ay = 16.00;
d3    : drift, l = 0.235000, ax = 32.50, ay = 16.00;
d4    : drift, l = 0.385000, ax = 32.50, ay = 16.00;
dft   : drift, l = 0.320000, ax = 50.00, ay = 50.00;
dl    : drift, l = 5.865000, ax = 50.00, ay = 50.00;
dl1   : drift, l = 0.430000, ax = 32.50, ay = 16.00;
dl2   : drift, l = 0.330000, ax = 32.50, ay = 16.00;
dl3   : drift, l = 0.415000, ax = 32.50, ay = 16.00;
dl4   : drift, l = 0.330000, ax = 32.50, ay = 16.00;
dlm1  : drift, l = 0.363333, ax = 50.00, ay = 50.00;
dlm2  : drift, l = 0.479000, ax = 50.00, ay = 50.00;
dm    : drift, l = 3.485000, ax = 50.00, ay = 50.00;
dm1   : drift, l = 0.470000, ax = 32.50, ay = 16.00;
dm2   : drift, l = 0.450000, ax = 32.50, ay = 16.00;
dm3   : drift, l = 0.235000, ax = 32.50, ay = 16.00;
dnomo : drift, l = 6.380000, ax = 50.00, ay = 50.00;
drad  : drift, l = 0.041500, ax = 50.00, ay = 50.00;
ds    : drift, l = 1.985000, ax = 50.00, ay = 50.00;
ds1   : drift, l = 0.470000, ax = 32.50, ay = 16.00;
ds2   : drift, l = 0.450000, ax = 32.50, ay = 16.00;
ds3   : drift, l = 0.235000, ax = 32.50, ay = 16.00;
dsx   : drift, l = 0.135000, ax = 32.50, ay = 16.00;
lr1   : drift, l = 1.068000, ax = 50.00, ay = 50.00;
lr1m  : drift, l = 0.137000, ax = 50.00, ay = 50.00;
lr1c  : drift, l = 0.572000, ax = 50.00, ay = 50.00;
lr1r  : drift, l = 0.359000, ax = 50.00, ay = 50.00;
lr2   : drift, l = 0.665000, ax = 50.00, ay = 50.00;
mgp   : drift, l = 0.500000, ax = 32.50, ay = 16.00;
dl4r  : drift, l = 0.230000, ax = 50.00, ay = 50.00;
db    : drift, l = 0.925777, ax = 50.00, ay = 50.00;
dcic1 : drift, l = 0.665000, ax = 50.00, ay = 50.00;
dcic2 : drift, l = 0.462512, ax = 50.00, ay = 50.00;
lm1   : drift, l = 0.142000, ax = 50.00, ay = 50.00;
lm2   : drift, l = 0.212000, ax = 50.00, ay = 50.00;
dmod  : drift, l = 0.025000, ax = 50.00, ay = 50.00;
wopen : drift, l = 1.173000, ax = 50.00, ay = 50.00;
uopen : drift, l = 0.912000, ax = 50.00, ay = 50.00;

qla   : quadrupole, l = 0.230000, k = -1.417548, ax = 32.50, ay = 16.00;
qma   : quadrupole, l = 0.230000, k = -1.166716, ax = 32.50, ay = 16.00;
qsa   : quadrupole, l = 0.230000, k = -1.442881, ax = 32.50, ay = 16.00;
qlb   : quadrupole, l = 0.350000, k = 1.117631, ax = 32.50, ay = 16.00;
qmb   : quadrupole, l = 0.350000, k = 0.835841, ax = 32.50, ay = 16.00;
qsb   : quadrupole, l = 0.350000, k = 1.013120, ax = 32.50, ay = 16.00;
qlc   : quadrupole, l = 0.470000, k = 1.712615, ax = 32.50, ay = 16.00;
qmc   : quadrupole, l = 0.470000, k = 1.892955, ax = 32.50, ay = 16.00;
qsc   : quadrupole, l = 0.470000, k = 1.806508, ax = 32.50, ay = 16.00;
qld   : quadrupole, l = 0.350000, k = -1.630263, ax = 32.50, ay = 16.00;
qmd   : quadrupole, l = 0.350000, k = -1.896228, ax = 32.50, ay = 16.00;
qsd   : quadrupole, l = 0.350000, k = -1.852825, ax = 32.50, ay = 16.00;
qft1  : quadrupole, l = 0.350000, k = 1.627546, ax = 32.50, ay = 16.00;
qft2  : quadrupole, l = 0.470000, k = -1.749879, ax = 50.00, ay = 50.00;
qft3  : quadrupole, l = 0.230000, k = -0.669869, ax = 50.00, ay = 50.00;
qle   : quadrupole, l = 0.230000, k = -0.310455, ax = 32.50, ay = 16.00;
qlf   : quadrupole, l = 0.470000, k = 1.810624, ax = 32.50, ay = 16.00;
qlg   : quadrupole, l = 0.470000, k = -1.722213, ax = 32.50, ay = 16.00;
qlgm  : quadrupole, l = 0.470000, k = -1.872173, ax = 50.00, ay = 50.00;
qlgr  : quadrupole, l = 0.470000, k = -2.515022, ax = 32.50, ay = 16.00;
qlh   : quadrupole, l = 0.230000, k = 1.841263, ax = 32.50, ay = 16.00;
qlhm  : quadrupole, l = 0.230000, k = 1.932479, ax = 50.00, ay = 50.00;
qlhr  : quadrupole, l = 0.350000, k = 2.135718, ax = 32.50, ay = 16.00;
qme   : quadrupole, l = 0.230000, k = -0.684822, ax = 32.50, ay = 16.00;
qmf   : quadrupole, l = 0.470000, k = 2.120888, ax = 32.50, ay = 16.00;
qmg   : quadrupole, l = 0.350000, k = -1.541988, ax = 32.50, ay = 16.00;
qse   : quadrupole, l = 0.230000, k = -0.833901, ax = 32.50, ay = 16.00;
qsf   : quadrupole, l = 0.470000, k = 2.417668, ax = 32.50, ay = 16.00;
qsg   : quadrupole, l = 0.470000, k = -1.803287, ax = 32.50, ay = 16.00;

be    : bending, l = 0.800000, t = 8.000000, k = 0.000000,
        t1 = 3.400000, t2 = 3.400000, gap = 42.0000, k1 = 0.6000, ax = 32.50,
        ay = 16.00;
bxh   : bending, l = 0.700000, t = 7.000000, k = 0.000000,
        t1 = 6.400000, t2 = 0.000000, gap = 42.0000, k1in = 0.6200,
        k1ex = 0.0000, ax = 32.50, ay = 16.00;
bfc1  : bending, l = 0.320000, t = -2.362000, k = 0.000000,
        t1 = -1.181000, t2 = -1.181000, gap = 41.0000, k1 = 0.5000, ax = 50.00,
        ay = 50.00;
bfc2  : bending, l = 0.752000, t = 7.347000, k = 0.000000,
        t1 = 3.674000, t2 = 3.674000, gap = 41.0000, k1 = 0.5000, ax = 50.00,
        ay = 50.00;
bfc3  : bending, l = 0.512000, t = -4.985000, k = 0.000000,
        t1 = -2.493000, t2 = -2.493000, gap = 41.0000, k1 = 0.5000, ax = 50.00,
        ay = 50.00;

sdh   : sextupole, l = 0.110000, k = -22.593297, n = 2, ax = 32.50,
        ay = 16.00;
seh   : sextupole, l = 0.110000, k = -9.100000, n = 2, ax = 32.50,
        ay = 16.00;
sf    : sextupole, l = 0.220000, k = 21.134593, n = 4, ax = 32.50,
        ay = 16.00;
sla   : sextupole, l = 0.220000, k = -32.290000, n = 4, ax = 32.50,
        ay = 16.00;
slbh  : sextupole, l = 0.110000, k = 13.000000, n = 2, ax = 32.50,
        ay = 16.00;
sma   : sextupole, l = 0.220000, k = -17.090000, n = 4, ax = 32.50,
        ay = 16.00;
smbh  : sextupole, l = 0.110000, k = 15.576000, n = 2, ax = 32.50,
        ay = 16.00;
ssa   : sextupole, l = 0.220000, k = -32.257000, n = 4, ax = 32.50,
        ay = 16.00;
ssbh  : sextupole, l = 0.110000, k = 19.146000, n = 2, ax = 32.50,
        ay = 16.00;

u19   : undulator, l = 0.912000, lamb = 0.019000, bmax = 1.000000,
        f1 = 0.636620, f2 = 0.500000, f3 = 0.424413, gap = 1000.000,
        ax = 50.00, ay = 2.00;
w138  : undulator, l = 2.346000, lamb = 0.138000, bmax = 1.900000,
        f1 = 0.636620, f2 = 0.500000, f3 = 0.424413, gap = 1000.000,
        ax = 50.00, ay = 4.00;

omid  : opticsmarker, betax = 2.967725, alphax = 1.432158,
        betay = 8.931146, alphay = -2.419042, etax  = 0.000359,
        etaxp  = -0.000200, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
        ay = 50.00;
oml0  : opticsmarker, betax = 13.418100, alphax = -4.972130,
        betay = 12.982600, alphay = 6.294890, etax  = -0.000001,
        etaxp  = 0.000000, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
        ay = 50.00;
orad  : opticsmarker, betax = 8.318559, alphax = -2.144749,
        betay = 0.522360, alphay = -0.000002, etax  = 0.000330,
        etaxp  = 0.000023, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
        ay = 50.00;
omod  : opticsmarker, betax = 11.081467, alphax = 0.791011,
        betay = 6.274504, alphay = 1.532166, etax  = -0.011637,
        etaxp  = -0.041329, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
        ay = 50.00;

gm    : girder, typ = 0, shift = 0.00000, ax = 50.00, ay = 50.00;
gj    : girder, typ = 1, shift = 0.00000, ax = 50.00, ay = 50.00;
gb    : girder, typ = 2, shift = 0.00000, ax = 50.00, ay = 50.00;

mon   : monitor, ax = 50.00, ay = 50.00;

ch    : h-corrector, ax = 50.00, ay = 50.00;

cv    : v-corrector, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

sd    : sdh, ch, cv, sdh;
se    : seh, ch, cv, seh;
slb   : slbh, ch, cv, slbh;
ssb   : ssbh, ch, cv, ssbh;
smb   : smbh, ch, cv, smbh;
mond  : dmon, mon, dsxm;
bx    : gb, bxh, -bxh, -gb;
tl    : gj, d1, qla, mond, sd, d2, qlb, dsx, sf, dsx, qlc, d3, se,
        -mond, qld, d4, -gj, gb, be, -gb;
tm    : gj, d1, qma, mond, sd, d2, qmb, dsx, sf, dsx, qmc, d3, se,
        -mond, qmd, d4, -gj, gb, be, -gb;
ts    : gj, d1, qsa, mond, sd, d2, qsb, dsx, sf, dsx, qsc, d3, se,
        -mond, qsd, d4, -gj, gb, be, -gb;
ml0   : gj, dl1, sla, dsx, qle, dl2, qlf, mond, slb;
ml1   : dl3, qlg, dl4, qlh, -gm, dl;
ml    : ml0, ml1;
mm    : gj, dm1, sma, dsx, qme, dm2, qmf, mond, smb, dm3, qmg, -gm, dm;
ms    : gj, ds1, ssa, dsx, qse, ds2, qsf, mond, ssb, ds3, qsg, -gm, ds;
tml   : tl, ml;
tmm   : tm, mm;
tms   : ts, ms;
six   : -tml, bx, tms, -tms, bx, tmm;
per   : six, -six, nper=3;
ring0 : -ml1, oml0, -ml0, -tl, bx, tms, -tms, bx, tmm, -six, 2*per;
trip  : gm, qft1, dft, qft2, omid, dft, qft3, -gm;
rad   : lr1m, mon, lr1c, cv, ch, lr1r, drad, u19, orad, u19, drad, lr2;
norad : lr1m, mon, lr1c, cv, ch, lr1r, drad, uopen, orad, uopen, drad, lr2;
radin : dl3, qlgr, dl4r, qlhr, -gm;
modin : dl3, qlgm, dl4, qlhm, -gm;
mod   : lm1, dmod, wopen, omod, wopen, dmod, lm2;
chic  : dcic1, bfc1, mod, bfc2, db, bfc3, dcic2;
femto : -oml0, modin, chic, trip, norad, -radin;
empty : -oml0, ml1, -ml1;
ring  : six, -tmm, bx, tms, -tms, bx, tl, ml0, femto, -ml0, -tl, bx,
        tms, -tms, bx, tmm, -six, six, -six;

{c:\users\streun\opadat\sls-optics\sls_f6cwo.opa}
