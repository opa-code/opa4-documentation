{c:\users\streun\opadat\repository\sls_hex240_cdr.opa}
{com title : sls hexagon as described in the 1993 cdr (oval_a1) com}


energy = 2.100000;

    betax   = 3.4999938; alphax  = 0.0000000;
    etax    = 0.0000002; etaxp   = 0.0000000;
    betay   = 3.5000071; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

aaa  : drift, l = 0.000000, ax = 50.00, ay = 50.00;
d2   : drift, l = 0.230000, ax = 50.00, ay = 50.00;
d2s  : drift, l = 0.390000, ax = 50.00, ay = 50.00;
d3   : drift, l = 0.230000, ax = 50.00, ay = 50.00;
d4   : drift, l = 0.230000, ax = 50.00, ay = 50.00;
d5   : drift, l = 0.340000, ax = 50.00, ay = 50.00;
d5m  : drift, l = 0.480000, ax = 50.00, ay = 50.00;
d5s  : drift, l = 0.760000, ax = 50.00, ay = 50.00;
d6   : drift, l = 0.350000, ax = 50.00, ay = 50.00;
dls  : drift, l = 9.240000, ax = 50.00, ay = 50.00;
dql1 : drift, l = 0.500000, ax = 50.00, ay = 50.00;
dql2 : drift, l = 0.290000, ax = 50.00, ay = 50.00;
dql3 : drift, l = 0.300000, ax = 50.00, ay = 50.00;
dqsh : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dqss : drift, l = 0.300000, ax = 50.00, ay = 50.00;
dss  : drift, l = 3.500000, ax = 50.00, ay = 50.00;

ent  : marker, ax = 50.00, ay = 50.00;
enf  : marker, ax = 50.00, ay = 50.00;
est  : marker, ax = 50.00, ay = 50.00;

qd   : quadrupole, l = 0.180000, k = -3.047698, ax = 35.00, ay = 50.00;
qdl1 : quadrupole, l = 0.260000, k = -1.270524, ax = 35.00, ay = 50.00;
qdl2 : quadrupole, l = 0.180000, k = -3.022480, ax = 35.00, ay = 50.00;
qds  : quadrupole, l = 0.180000, k = -2.760931, ax = 35.00, ay = 50.00;
qds1 : quadrupole, l = 0.260000, k = -2.136661, ax = 35.00, ay = 50.00;
qds2 : quadrupole, l = 0.180000, k = -3.017897, ax = 35.00, ay = 50.00;
qf   : quadrupole, l = 0.260000, k = 3.049745, ax = 35.00, ay = 50.00;
qfl1 : quadrupole, l = 0.260000, k = 3.176640, ax = 35.00, ay = 50.00;
qfl2 : quadrupole, l = 0.260000, k = 3.039696, ax = 35.00, ay = 50.00;
qfs  : quadrupole, l = 0.260000, k = 2.950000, ax = 35.00, ay = 50.00;
qfs1 : quadrupole, l = 0.260000, k = 3.101917, ax = 35.00, ay = 50.00;
qfs2 : quadrupole, l = 0.260000, k = 3.101889, ax = 35.00, ay = 50.00;
qll1 : quadrupole, l = 0.180000, k = -2.813534, ax = 35.00, ay = 50.00;
qll2 : quadrupole, l = 0.320000, k = 3.468121, ax = 35.00, ay = 50.00;
qll3 : quadrupole, l = 0.320000, k = -2.743479, ax = 35.00, ay = 50.00;
qll4 : quadrupole, l = 0.260000, k = 1.783534, ax = 35.00, ay = 50.00;
qss1 : quadrupole, l = 0.260000, k = -2.388924, ax = 35.00, ay = 50.00;
qss2 : quadrupole, l = 0.260000, k = 2.518251, ax = 35.00, ay = 50.00;
qss3 : quadrupole, l = 0.320000, k = 2.483473, ax = 35.00, ay = 50.00;
qss4 : quadrupole, l = 0.260000, k = -2.388924, ax = 35.00, ay = 50.00;

bnf  : bending, l = 0.440000, t = 5.000000, k = 0.000000, t1 = 2.500000,
       t2 = 2.500000, ax = 50.00, ay = 50.00;
bnt  : bending, l = 0.880000, t = 10.000000, k = 0.000000, t1 = 5.000000,
       t2 = 5.000000, ax = 50.00, ay = 50.00;
bst  : bending, l = 0.260000, t = 10.000000, k = 0.000000, t1 = 5.000000,
       t2 = 5.000000, ax = 50.00, ay = 50.00;

sd   : sextupole, l = 0.000000, k = -6.925169, n = 1, ax = 50.00, ay = 50.00;
sf   : sextupole, l = 0.000000, k = 10.675445, n = 1, ax = 50.00, ay = 50.00;
sfl  : sextupole, l = 0.000000, k = 4.761732, n = 1, ax = 50.00, ay = 50.00;
sfs  : sextupole, l = 0.000000, k = 7.028844, n = 1, ax = 50.00, ay = 50.00;
shl  : sextupole, l = 0.000000, k = -0.101165, n = 1, ax = 50.00, ay = 50.00;
shs  : sextupole, l = 0.000000, k = 2.167008, n = 1, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

larc : dls, qll4, dql3, qll3, dql2, shl, dql2, qll2, dql1, qll1, d6, enf,
       bnf, enf, d5m, qdl1, d4, d3, qfl2, d2, sfl, d2, qfl2, d3, sd, d4, qdl2,
       d5, ent, bnt, ent, d5, qdl2, d4, sd, d3, qfl1, d2, sf, d2, qf, d3, sd,
       d4, qd, d5, ent, bnt, ent, d5, qd, d4, sd, d3, qf, d2, sf, d2s, qfs, d3,
       sd, d4, qds, d5s, est, bst, est, d5s, qds, d4, sd, d3, qfs, d2s, sf, d2,
       qf, d3, sd, d4, qd, d5, ent, bnt, ent, d5, qd, d4, sd, d3, qf, d2, sf,
       d2, qfs1, d3, sd, d4, qds2, d5, ent, bnt, ent, d5, qds2, d4, sd, d3,
       qfs2, d2, sfs, d2, qfs2, d3, d4, qds1, d5m, enf, bnf, enf, d6, qss1,
       dqss, qss2, dqsh, shs, dqsh, qss3, dqss, qss4, dss;
sarc : dss, qss4, dqss, qss3, dqsh, shs, dqsh, qss2, dqss, qss1, d6, enf,
       bnf, enf, d5m, qds1, d4, d3, qfs2, d2, sfs, d2, qfs2, d3, sd, d4, qds2,
       d5, ent, bnt, ent, d5, qds2, d4, sd, d3, qfs1, d2, sf, d2, qf, d3, sd,
       d4, qd, d5, ent, bnt, ent, d5, qd, d4, sd, d3, qf, d2, sf, d2s, qfs, d3,
       sd, d4, qds, d5s, est, bst, est, d5s, qds, d4, sd, d3, qfs, d2s, sf, d2,
       qf, d3, sd, d4, qd, d5, ent, bnt, ent, d5, qd, d4, sd, d3, qf, d2, sf,
       d2, qfs1, d3, sd, d4, qds2, d5, ent, bnt, ent, d5, qds2, d4, sd, d3,
       qfs2, d2, sfs, d2, qfs2, d3, d4, qds1, d5m, enf, bnf, enf, d6, qss1,
       dqss, qss2, dqsh, shs, dqsh, qss3, dqss, qss4, dss;
ring : larc, sarc, -larc, nper=2;

{c:\users\streun\opadat\repository\sls_hex240_cdr.opa}
