{c:\users\streun\opadat\repository\soleil_2009.opa}


energy = 2.750000;

    betax   = 10.8739675; alphax  = 0.0010033;
    etax    = 0.2204771; etaxp   = 0.0000002;
    betay   = 7.9973604; alphay  = 0.0003026;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- variables ----------------------------------------------------}


{----- table of elements ----------------------------------------------------}

sd1   : drift, l = 5.979900, ax = 50.00, ay = 50.00;
sd2   : drift, l = 0.289900, ax = 50.00, ay = 50.00;
sd3   : drift, l = 0.101900, ax = 50.00, ay = 50.00;
sd4   : drift, l = 0.291900, ax = 50.00, ay = 50.00;
sd5   : drift, l = 0.099900, ax = 50.00, ay = 50.00;
sd6   : drift, l = 0.710000, ax = 50.00, ay = 50.00;
sd7   : drift, l = 0.419900, ax = 50.00, ay = 50.00;
sd8   : drift, l = 0.099900, ax = 50.00, ay = 50.00;
sd9   : drift, l = 0.376240, ax = 50.00, ay = 50.00;
sd10  : drift, l = 0.369900, ax = 50.00, ay = 50.00;
sd12  : drift, l = 0.369900, ax = 50.00, ay = 50.00;
sd13  : drift, l = 3.462450, ax = 50.00, ay = 50.00;
sd14  : drift, l = 0.551800, ax = 50.00, ay = 50.00;
sdac3 : drift, l = 1.824680, ax = 50.00, ay = 50.00;

sym   : marker, ax = 50.00, ay = 50.00;

q1    : quadrupole, l = 0.360200, k = -1.073038, ax = 50.00, ay = 50.00;
q2    : quadrupole, l = 0.496200, k = 1.603455, ax = 50.00, ay = 50.00;
q3    : quadrupole, l = 0.360200, k = -0.649160, ax = 50.00, ay = 50.00;
q4    : quadrupole, l = 0.360200, k = -1.259864, ax = 50.00, ay = 50.00;
q5    : quadrupole, l = 0.360200, k = 1.696440, ax = 50.00, ay = 50.00;
q6    : quadrupole, l = 0.360200, k = -1.007805, ax = 50.00, ay = 50.00;
q7    : quadrupole, l = 0.496200, k = 2.084913, ax = 50.00, ay = 50.00;
q8    : quadrupole, l = 0.360200, k = -1.551946, ax = 50.00, ay = 50.00;
q9    : quadrupole, l = 0.360200, k = -1.510915, ax = 50.00, ay = 50.00;
q10   : quadrupole, l = 0.360200, k = 1.756880, ax = 50.00, ay = 50.00;

bend  : bending, l = 1.052430, t = 11.250000, k = 0.002040,
        t1 = 5.590600, t2 = 5.676580, gap = 53.5800, k1 = 0.5000, ax = 50.00,
        ay = 50.00;

sx1   : sextupole, l = 0.160000, k = 10.744937, n = 3, ax = 50.00,
        ay = 50.00;
sx2   : sextupole, l = 0.160000, k = -25.653500, n = 3, ax = 50.00,
        ay = 50.00;
sx3   : sextupole, l = 0.160000, k = -13.558625, n = 3, ax = 50.00,
        ay = 50.00;
sx4   : sextupole, l = 0.160000, k = 22.529062, n = 3, ax = 50.00,
        ay = 50.00;
sx5   : sextupole, l = 0.160000, k = -23.113812, n = 3, ax = 50.00,
        ay = 50.00;
sx6   : sextupole, l = 0.160000, k = 20.291687, n = 3, ax = 50.00,
        ay = 50.00;
sx7   : sextupole, l = 0.160000, k = -31.272000, n = 3, ax = 50.00,
        ay = 50.00;
sx8   : sextupole, l = 0.160000, k = 26.210750, n = 3, ax = 50.00,
        ay = 50.00;
sx9   : sextupole, l = 0.160000, k = -19.701844, n = 3, ax = 50.00,
        ay = 50.00;
sx10  : sextupole, l = 0.160000, k = 12.102700, n = 3, ax = 50.00,
        ay = 50.00;


{----- table of segments ----------------------------------------------------}

ring : sd1, q1, sd2, sx1, sd3, q2, sd14, q3, sd5, sx2, sd6, bend, sd7,
       q4, sd8, sx3, sd9, q5, sd12, sx4, sd10, q5, sd9, sx3, sd8, q4, sd7, bend,
       sd7, q6, sd5, sx5, sd4, q7, sd3, sx6, sd2, q8, sd13, sd13, q8, sd2, sx8,
       sd3, q7, sd4, sx7, sd5, q6, sd7, bend, sd7, q9, sd8, sx9, sd9, q10, sd8,
       sx10, sdac3, sdac3, sx10, sd8, q10, sd9, sx9, sd8, q9, sd7, bend, sd7,
       q6, sd5, sx7, sd4, q7, sd3, sx8, sd2, q8, sd13, sd13, q8, sd2, sx8, sd3,
       q7, sd4, sx7, sd5, q6, sd7, bend, sd7, q9, sd8, sx9, sd9, q10, sd8,
       sx10, sdac3, sdac3, sx10, sd8, q10, sd9, sx9, sd8, q9, sd7, bend, sd7,
       q6, sd5, sx7, sd4, q7, sd3, sx8, sd2, q8, sd13, sd13, q8, sd2, sx6, sd3,
       q7, sd4, sx5, sd5, q6, sd7, bend, sd7, q4, sd8, sx3, sd9, q5, sd10, sx4,
       sd12, q5, sd9, sx3, sd8, q4, sd7, bend, sd6, sx2, sd5, q3, sd14, q2,
       sd3, sx1, sd2, q1, sd1, nper=4;

{c:\users\streun\opadat\repository\soleil_2009.opa}
