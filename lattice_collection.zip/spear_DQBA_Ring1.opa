{c:\users\streun\opadat\repository\spear_dqba_ring1.opa}


energy = 3.000000;

    betax   = 8.3657772; alphax  = 0.0000000;
    etax    = 0.0799747; etaxp   = 0.0000000;
    betay   = 3.3881883; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

dc1     : drift, l = 1.529975, ax = 50.00, ay = 50.00;
dc2     : drift, l = 0.175585, ax = 50.00, ay = 50.00;
dc3     : drift, l = 0.112742, ax = 50.00, ay = 50.00;
dc4     : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dc5     : drift, l = 0.196874, ax = 50.00, ay = 50.00;
dc6     : drift, l = 0.176726, ax = 50.00, ay = 50.00;
dc7     : drift, l = 0.090139, ax = 50.00, ay = 50.00;
dc8     : drift, l = 0.090139, ax = 50.00, ay = 50.00;
dc9     : drift, l = 0.097216, ax = 50.00, ay = 50.00;
dc10    : drift, l = 0.090716, ax = 50.00, ay = 50.00;
dc11    : drift, l = 0.112291, ax = 50.00, ay = 50.00;
dc12    : drift, l = 0.126037, ax = 50.00, ay = 50.00;
dc13    : drift, l = 1.429975, ax = 50.00, ay = 50.00;
dcm1    : drift, l = 3.500785, ax = 50.00, ay = 50.00;
dcm2    : drift, l = 0.175585, ax = 50.00, ay = 50.00;
dcm3    : drift, l = 0.212742, ax = 50.00, ay = 50.00;
dcm4    : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dcm5    : drift, l = 0.547669, ax = 50.00, ay = 50.00;
dcm6    : drift, l = 0.377934, ax = 50.00, ay = 50.00;
dcm7    : drift, l = 0.321348, ax = 50.00, ay = 50.00;
dcm8    : drift, l = 0.321348, ax = 50.00, ay = 50.00;
dcm9    : drift, l = 0.298425, ax = 50.00, ay = 50.00;
dcm10   : drift, l = 0.512928, ax = 50.00, ay = 50.00;
dcm11   : drift, l = 0.324582, ax = 50.00, ay = 50.00;
dcm12   : drift, l = 0.326037, ax = 50.00, ay = 50.00;
dcm13   : drift, l = 4.181922, ax = 50.00, ay = 50.00;
dcs13   : drift, l = 1.429975, ax = 50.00, ay = 50.00;
dcs12   : drift, l = 0.126037, ax = 50.00, ay = 50.00;
dcs11   : drift, l = 0.082291, ax = 50.00, ay = 50.00;
dcs10   : drift, l = 0.160505, ax = 50.00, ay = 50.00;
dcs9    : drift, l = 0.182110, ax = 50.00, ay = 50.00;
dcs8    : drift, l = 0.105034, ax = 50.00, ay = 50.00;

mm      : marker, ax = 50.00, ay = 50.00;
mmm     : marker, ax = 50.00, ay = 50.00;
mms     : marker, ax = 50.00, ay = 50.00;
mq5     : marker, ax = 50.00, ay = 50.00;
mqm5    : marker, ax = 50.00, ay = 50.00;

q1      : quadrupole, l = 0.200000, k = -4.152646, ax = 20.00, ay = 20.00;
q2      : quadrupole, l = 0.250000, k = 9.588408, ax = 20.00, ay = 20.00;
q3      : quadrupole, l = 0.100000, k = -8.929858, ax = 20.00, ay = 20.00;
q4      : quadrupole, l = 0.300000, k = 8.027080, ax = 20.00, ay = 20.00;
q5h     : quadrupole, l = 0.130000, k = 10.440107, ax = 20.00, ay = 20.00;
q6      : quadrupole, l = 0.300000, k = 9.548062, ax = 20.00, ay = 20.00;
q7h     : quadrupole, l = 0.125000, k = 8.274681, ax = 20.00, ay = 20.00;
q8h     : quadrupole, l = 0.100000, k = -4.795081, ax = 20.00, ay = 20.00;
qm1     : quadrupole, l = 0.200000, k = -1.529976, ax = 20.00, ay = 20.00;
qm2h    : quadrupole, l = 0.125000, k = 6.769031, ax = 20.00, ay = 20.00;
qm3     : quadrupole, l = 0.200000, k = -4.711314, ax = 20.00, ay = 20.00;
qm4     : quadrupole, l = 0.300000, k = 6.839251, ax = 20.00, ay = 20.00;
qm5h    : quadrupole, l = 0.150000, k = 8.439446, ax = 20.00, ay = 20.00;
qm6     : quadrupole, l = 0.300000, k = 7.818449, ax = 20.00, ay = 20.00;
qm7h    : quadrupole, l = 0.125000, k = 4.746188, ax = 20.00, ay = 20.00;
qm8h    : quadrupole, l = 0.100000, k = -2.088342, ax = 20.00, ay = 20.00;
qs5h    : quadrupole, l = 0.150000, k = 8.866268, ax = 20.00, ay = 20.00;
qs6     : quadrupole, l = 0.300000, k = 8.985798, ax = 20.00, ay = 20.00;
qs7h    : quadrupole, l = 0.125000, k = 8.285364, ax = 20.00, ay = 20.00;
qs8h    : quadrupole, l = 0.100000, k = -4.389292, ax = 20.00, ay = 20.00;

bendl1  : bending, l = 1.209666, t = 5.618250, k = -1.541759,
          t1 = 2.809120, t2 = 2.809120, ax = 50.00, ay = 50.00;
bends   : bending, l = 0.924000, t = 4.321729, k = -1.234349,
          t1 = 2.160864, t2 = 2.160864, ax = 50.00, ay = 50.00;
bendl2  : bending, l = 1.209666, t = 5.618250, k = -1.388421,
          t1 = 2.809120, t2 = 2.809120, ax = 50.00, ay = 50.00;
bendlm1 : bending, l = 0.907249, t = 4.213684, k = -1.450000,
          t1 = 2.106842, t2 = 2.106842, ax = 50.00, ay = 50.00;
bendsm  : bending, l = 0.693000, t = 3.241295, k = -1.036030,
          t1 = 1.620648, t2 = 1.620648, ax = 50.00, ay = 50.00;
bendlm2 : bending, l = 0.907249, t = 4.213684, k = -1.424977,
          t1 = 2.106842, t2 = 2.106842, ax = 50.00, ay = 50.00;
bendls1 : bending, l = 1.139878, t = 5.294119, k = -1.465992,
          t1 = 2.647059, t2 = 2.647059, ax = 50.00, ay = 50.00;
bendls2 : bending, l = 1.139878, t = 5.294119, k = -1.508388,
          t1 = 2.647059, t2 = 2.647059, ax = 50.00, ay = 50.00;

sf      : sextupole, l = 0.100000, k = 229.656602, n = 1, ax = 20.00,
          ay = 20.00;
sd      : sextupole, l = 0.100000, k = -220.785070, n = 1, ax = 20.00,
          ay = 20.00;
sdb1    : sextupole, l = 0.050000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sdb2    : sextupole, l = 0.050000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sdb3    : sextupole, l = 0.050000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sdb4    : sextupole, l = 0.050000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sf1     : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sh1     : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sdm     : sextupole, l = 0.100000, k = -154.610000, n = 1, ax = 20.00,
          ay = 20.00;
sfm     : sextupole, l = 0.100000, k = 194.550000, n = 1, ax = 20.00,
          ay = 20.00;
sdm1    : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sfm1    : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
shm1    : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
shm2    : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sfs1    : sextupole, l = 0.100000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sds1    : sextupole, l = 0.080000, k = 0.000000, n = 1, ax = 20.00,
          ay = 20.00;
sfs     : sextupole, l = 0.100000, k = 248.984905, n = 1, ax = 20.00,
          ay = 20.00;
sds     : sextupole, l = 0.100000, k = -220.000000, n = 1, ax = 20.00,
          ay = 20.00;
sst1    : sextupole, l = 0.000000, k = 0.000000, n = 1, ax = 50.00,
          ay = 50.00;
sst2    : sextupole, l = 0.000000, k = 0.000000, n = 1, ax = 50.00,
          ay = 50.00;
sst3    : sextupole, l = 0.000000, k = 0.000000, n = 1, ax = 50.00,
          ay = 50.00;
sst4    : sextupole, l = 0.000000, k = 0.000000, n = 1, ax = 50.00,
          ay = 50.00;

oct1    : multipole, n = 4,  k = 100.00000000, ax = 50.00, ay = 50.00;
oct2    : multipole, n = 4,  k = -100.00000000, ax = 50.00, ay = 50.00;
oct3    : multipole, n = 4,  k = 0.00000000, ax = 50.00, ay = 50.00;
oct4    : multipole, n = 4,  k = 0.00000000, ax = 50.00, ay = 50.00;
oct5    : multipole, n = 4,  k = 0.00100000, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

hcel1  : dc1, q1, dc2, sh1, q2, dc3, q3, dc4, bends, 2*sdb1, dc5, q4,
         dc6, sdb2, bendl1, sdb2, dc7, q5h, sf1;
hcel2  : q5h, dc8, sdb3, bendl1, sdb3, dc9, q6, dc10, bendl2, sdb4,
         dc11, q7h, 2*sf, q7h, dc12, q8h, 2*sd, q8h, dc13;
cel    : hcel1, mq5, hcel2, mm, -hcel2, -hcel1;
cel1   : -hcel2, mq5, -hcel1, mm, hcel1, hcel2;
mhcel1 : dcm1, qm1, dcm2, shm1, 2*qm2h, dcm3, qm3, dcm4, shm2, bendsm,
         sdm1, dcm5, qm4, dcm6, bendlm1, dcm7, qm5h;
mhcel2 : qm5h, dcm8, bendlm1, dcm9, qm6, dcm10, bendlm2, 3*sdm, dcm11,
         qm7h, 2*sfm, qm7h, dcm12, qm8h, 2*sfm1, qm8h, dcm13;
mcel   : mhcel1, mqm5, mhcel2, mmm, -mhcel2, -mhcel1;
shcel2 : qs5h, sfs1, dcs8, bendls1, dcs9, qs6, dcs10, bendls2, sds1,
         dcs11, qs7h, 2*sfs, qs7h, dcs12, qs8h, 2*sds, qs8h, dcs13;
scel   : -shcel2, mms, shcel2;
qring  : -mhcel2, -mhcel1, cel, hcel1, hcel2, -shcel2;
hring  : qring, -qring;
ring   : hring, nper=2;

{c:\users\streun\opadat\repository\spear_dqba_ring1.opa}
