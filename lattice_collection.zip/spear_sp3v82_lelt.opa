{c:\users\streun\opadat\repository\spear_sp3v82_lelt.opa}
{com spear3 com}


energy = 3.000000;

    betax   = 9.0205511; alphax  = -0.1401911;
    etax    = 0.1000011; etaxp   = 0.0000000;
    betay   = 5.1764952; alphay  = -0.2551834;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

dcor   : drift, l = 0.075000, ax = 50.00, ay = 50.00;
cavity : drift, l = 1.500000, ax = 50.00, ay = 50.00;
dc1a   : drift, l = 1.405934, ax = 50.00, ay = 50.00;
dc1b   : drift, l = 0.124041, ax = 50.00, ay = 50.00;
dc2    : drift, l = 0.097500, ax = 50.00, ay = 50.00;
dc3    : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dc4    : drift, l = 0.230000, ax = 50.00, ay = 50.00;
dc5    : drift, l = 0.200986, ax = 50.00, ay = 50.00;
dc6    : drift, l = 0.180000, ax = 50.00, ay = 50.00;
dc3a   : drift, l = 0.053221, ax = 50.00, ay = 50.00;
dc3b   : drift, l = 0.163682, ax = 50.00, ay = 50.00;
dc4a   : drift, l = 0.159215, ax = 50.00, ay = 50.00;
dc4b   : drift, l = 0.044418, ax = 50.00, ay = 50.00;
dc6a   : drift, l = 0.110646, ax = 50.00, ay = 50.00;
dc6b   : drift, l = 0.063166, ax = 50.00, ay = 50.00;
dc2a   : drift, l = 0.115765, ax = 50.00, ay = 50.00;
dc2b   : drift, l = 0.115810, ax = 50.00, ay = 50.00;
dc2c   : drift, l = 0.102100, ax = 50.00, ay = 50.00;
dc2d   : drift, l = 0.129475, ax = 50.00, ay = 50.00;
dc5a   : drift, l = 0.090580, ax = 50.00, ay = 50.00;
dc5b   : drift, l = 0.361390, ax = 50.00, ay = 50.00;
dc5c   : drift, l = 0.095840, ax = 50.00, ay = 50.00;
dc5d   : drift, l = 0.356130, ax = 50.00, ay = 50.00;
dm1    : drift, l = 3.810000, ax = 50.00, ay = 50.00;
dm2    : drift, l = 0.097500, ax = 50.00, ay = 50.00;
dm3    : drift, l = 0.275000, ax = 50.00, ay = 50.00;
dm4    : drift, l = 0.215846, ax = 50.00, ay = 50.00;
dm5    : drift, l = 0.250000, ax = 50.00, ay = 50.00;
dm6    : drift, l = 0.490685, ax = 50.00, ay = 50.00;
dm7    : drift, l = 0.173810, ax = 50.00, ay = 50.00;
dm8    : drift, l = 0.500000, ax = 50.00, ay = 50.00;
dm9    : drift, l = 0.105000, ax = 50.00, ay = 50.00;
dm10   : drift, l = 3.276571, ax = 50.00, ay = 50.00;
da1a   : drift, l = 3.679239, ax = 50.00, ay = 50.00;
da1b   : drift, l = 0.124067, ax = 50.00, ay = 50.00;
da3a   : drift, l = 0.208899, ax = 50.00, ay = 50.00;
da3b   : drift, l = 0.054140, ax = 50.00, ay = 50.00;
da5a   : drift, l = 0.113977, ax = 50.00, ay = 50.00;
da5b   : drift, l = 0.108563, ax = 50.00, ay = 50.00;
da5c   : drift, l = 0.051845, ax = 50.00, ay = 50.00;
da5d   : drift, l = 0.170695, ax = 50.00, ay = 50.00;
da7a   : drift, l = 0.110697, ax = 50.00, ay = 50.00;
da7b   : drift, l = 0.063113, ax = 50.00, ay = 50.00;
da8a   : drift, l = 0.337359, ax = 50.00, ay = 50.00;
da8b   : drift, l = 0.128486, ax = 50.00, ay = 50.00;
da10a  : drift, l = 0.123940, ax = 50.00, ay = 50.00;
da10b  : drift, l = 2.275986, ax = 50.00, ay = 50.00;
da10c  : drift, l = 0.869951, ax = 50.00, ay = 50.00;
da1aw  : drift, l = 0.679239, ax = 50.00, ay = 50.00;
da1ae  : drift, l = 0.099759, ax = 50.00, ay = 50.00;
da2a   : drift, l = 0.115305, ax = 50.00, ay = 50.00;
da2b   : drift, l = 0.117734, ax = 50.00, ay = 50.00;
da6a   : drift, l = 0.126600, ax = 50.00, ay = 50.00;
da6b   : drift, l = 0.904768, ax = 50.00, ay = 50.00;
da6c   : drift, l = 0.096000, ax = 50.00, ay = 50.00;
da6d   : drift, l = 0.935370, ax = 50.00, ay = 50.00;
da9a   : drift, l = 0.109305, ax = 50.00, ay = 50.00;
da9b   : drift, l = 0.137305, ax = 50.00, ay = 50.00;
db1a   : drift, l = 3.747082, ax = 50.00, ay = 50.00;
db1b   : drift, l = 0.056223, ax = 50.00, ay = 50.00;
db3a   : drift, l = 0.132227, ax = 50.00, ay = 50.00;
db3b   : drift, l = 0.130813, ax = 50.00, ay = 50.00;
db5a   : drift, l = 0.170695, ax = 50.00, ay = 50.00;
db5b   : drift, l = 0.051845, ax = 50.00, ay = 50.00;
db5c   : drift, l = 0.108563, ax = 50.00, ay = 50.00;
db5d   : drift, l = 0.113977, ax = 50.00, ay = 50.00;
db7a   : drift, l = 0.063113, ax = 50.00, ay = 50.00;
db7b   : drift, l = 0.110697, ax = 50.00, ay = 50.00;
db8a   : drift, l = 0.327250, ax = 50.00, ay = 50.00;
db8b   : drift, l = 0.138595, ax = 50.00, ay = 50.00;
db10a  : drift, l = 0.124041, ax = 50.00, ay = 50.00;
db10b  : drift, l = 2.275885, ax = 50.00, ay = 50.00;
db10c  : drift, l = 0.869951, ax = 50.00, ay = 50.00;
db1aw  : drift, l = 0.747082, ax = 50.00, ay = 50.00;
db1ae  : drift, l = 0.138082, ax = 50.00, ay = 50.00;
db2a   : drift, l = 0.115805, ax = 50.00, ay = 50.00;
db2b   : drift, l = 0.117234, ax = 50.00, ay = 50.00;
db6a   : drift, l = 0.937370, ax = 50.00, ay = 50.00;
db6b   : drift, l = 0.093999, ax = 50.00, ay = 50.00;
db6c   : drift, l = 0.904370, ax = 50.00, ay = 50.00;
db6d   : drift, l = 0.127000, ax = 50.00, ay = 50.00;
db9a   : drift, l = 0.123305, ax = 50.00, ay = 50.00;
db9b   : drift, l = 0.123305, ax = 50.00, ay = 50.00;
dch1a  : drift, l = 0.238039, ax = 50.00, ay = 50.00;
dch1b  : drift, l = 0.238039, ax = 50.00, ay = 50.00;
dch2a  : drift, l = 0.125620, ax = 50.00, ay = 50.00;
dch2b  : drift, l = 0.105490, ax = 50.00, ay = 50.00;
dch3a  : drift, l = 1.168633, ax = 50.00, ay = 50.00;
dch3b  : drift, l = 1.193423, ax = 50.00, ay = 50.00;
di5    : drift, l = 1.240130, ax = 50.00, ay = 50.00;
di6    : drift, l = 0.165804, ax = 50.00, ay = 50.00;

bl4    : marker, ax = 50.00, ay = 50.00;
bl5    : marker, ax = 50.00, ay = 50.00;
bl6    : marker, ax = 50.00, ay = 50.00;
bl7    : marker, ax = 50.00, ay = 50.00;
bl9    : marker, ax = 50.00, ay = 50.00;
bl10   : marker, ax = 50.00, ay = 50.00;
bl11   : marker, ax = 50.00, ay = 50.00;
bl12   : marker, ax = 50.00, ay = 50.00;
bl13   : marker, ax = 50.00, ay = 50.00;
mmm    : marker, ax = 50.00, ay = 50.00;
mipae  : marker, ax = 50.00, ay = 50.00;
mipbe  : marker, ax = 50.00, ay = 50.00;
mmw    : marker, ax = 50.00, ay = 50.00;
mme    : marker, ax = 50.00, ay = 50.00;
mrf    : marker, ax = 50.00, ay = 50.00;
m3m    : marker, ax = 50.00, ay = 50.00;
bpm    : marker, ax = 50.00, ay = 50.00;
hcor   : marker, ax = 50.00, ay = 50.00;
vcor   : marker, ax = 50.00, ay = 50.00;
sept   : marker, ax = 50.00, ay = 50.00;

qf     : quadrupole, l = 0.353390, k = 1.784842, ax = 50.00, ay = 50.00;
qd     : quadrupole, l = 0.163459, k = -1.490056, ax = 50.00, ay = 50.00;
qfc    : quadrupole, l = 0.512380, k = 1.682812, ax = 50.00, ay = 50.00;
qfm2e  : quadrupole, l = 0.353390, k = 1.691263, ax = 50.00, ay = 50.00;
qdm2e  : quadrupole, l = 0.163459, k = -1.347312, ax = 50.00, ay = 50.00;
qdm1e  : quadrupole, l = 0.163459, k = -1.919505, ax = 50.00, ay = 50.00;
qfm1e  : quadrupole, l = 0.353390, k = 1.823416, ax = 50.00, ay = 50.00;
qfm2w  : quadrupole, l = 0.353390, k = 1.691263, ax = 50.00, ay = 50.00;
qdm2w  : quadrupole, l = 0.163459, k = -1.347312, ax = 50.00, ay = 50.00;
qdm1w  : quadrupole, l = 0.163459, k = -1.919505, ax = 50.00, ay = 50.00;
qfm1w  : quadrupole, l = 0.353390, k = 1.823416, ax = 50.00, ay = 50.00;
qf7a   : quadrupole, l = 0.353390, k = 1.958856, ax = 50.00, ay = 50.00;
qd7a   : quadrupole, l = 0.163459, k = -1.742612, ax = 50.00, ay = 50.00;
qf7b   : quadrupole, l = 0.353390, k = 1.934252, ax = 50.00, ay = 50.00;
qd7b   : quadrupole, l = 0.163459, k = -1.623875, ax = 50.00, ay = 50.00;
qf12a  : quadrupole, l = 0.353390, k = 1.966134, ax = 50.00, ay = 50.00;
qd12a  : quadrupole, l = 0.163459, k = -1.756092, ax = 50.00, ay = 50.00;
qf12b  : quadrupole, l = 0.353390, k = 1.941859, ax = 50.00, ay = 50.00;
qd12b  : quadrupole, l = 0.163459, k = -1.711690, ax = 50.00, ay = 50.00;
qdxw   : quadrupole, l = 0.353390, k = -1.172916, ax = 50.00, ay = 50.00;
qfxw   : quadrupole, l = 0.610531, k = 1.741964, ax = 50.00, ay = 50.00;
qdyw   : quadrupole, l = 0.353390, k = -1.248163, ax = 50.00, ay = 50.00;
qfyw   : quadrupole, l = 0.512380, k = 1.431524, ax = 50.00, ay = 50.00;
qdzw   : quadrupole, l = 0.353390, k = -1.386363, ax = 50.00, ay = 50.00;
qfzw   : quadrupole, l = 0.353390, k = 1.701688, ax = 50.00, ay = 50.00;
qdxbe  : quadrupole, l = 0.353390, k = -0.644728, ax = 50.00, ay = 50.00;
qfxbe  : quadrupole, l = 0.610531, k = 1.487811, ax = 50.00, ay = 50.00;
qdybe  : quadrupole, l = 0.353390, k = -1.337034, ax = 50.00, ay = 50.00;
qfybe  : quadrupole, l = 0.512380, k = 1.456174, ax = 50.00, ay = 50.00;
qdzbe  : quadrupole, l = 0.353390, k = -0.986346, ax = 50.00, ay = 50.00;
qfzbe  : quadrupole, l = 0.353390, k = 1.662691, ax = 50.00, ay = 50.00;
qdxae  : quadrupole, l = 0.353390, k = -0.580255, ax = 50.00, ay = 50.00;
qfxae  : quadrupole, l = 0.610531, k = 1.410586, ax = 50.00, ay = 50.00;
qdyae  : quadrupole, l = 0.353390, k = -1.290146, ax = 50.00, ay = 50.00;
qfyae  : quadrupole, l = 0.512380, k = 1.408487, ax = 50.00, ay = 50.00;
qdzae  : quadrupole, l = 0.353390, k = -0.925637, ax = 50.00, ay = 50.00;
qfzae  : quadrupole, l = 0.353390, k = 1.561344, ax = 50.00, ay = 50.00;
qde    : quadrupole, l = 0.305266, k = -1.986758, ax = 50.00, ay = 50.00;
qfbe   : quadrupole, l = 0.353390, k = 1.433615, ax = 50.00, ay = 50.00;
qfae   : quadrupole, l = 0.353390, k = 1.449057, ax = 50.00, ay = 50.00;

bend   : bending, l = 1.504800, t = 10.588240, k = -0.315379,
         t1 = 5.294120, t2 = 5.294120, ax = 50.00, ay = 50.00;
b34    : bending, l = 1.143290, t = 7.941180, k = -0.315379,
         t1 = 3.970590, t2 = 3.970590, ax = 50.00, ay = 50.00;
b1e    : bending, l = 0.110000, t = 0.114590, k = 0.000000,
         t1 = 0.057300, t2 = 0.057300, ax = 50.00, ay = 50.00;
b2e    : bending, l = 0.110000, t = 0.276880, k = 0.000000,
         t1 = 0.138440, t2 = 0.138440, ax = 50.00, ay = 50.00;
b3e    : bending, l = 0.110000, t = -0.849840, k = 0.000000,
         t1 = -0.424920, t2 = -0.424920, ax = 50.00, ay = 50.00;
b4e    : bending, l = 0.110000, t = 0.458370, k = 0.000000,
         t1 = 0.229180, t2 = 0.229180, ax = 50.00, ay = 50.00;

sf     : sextupole, l = 0.210000, k = 16.580234, n = 2, ax = 50.00,
         ay = 50.00;
sd     : sextupole, l = 0.250000, k = -21.808655, n = 2, ax = 50.00,
         ay = 50.00;
sfi    : sextupole, l = 0.210000, k = 7.691787, n = 2, ax = 50.00,
         ay = 50.00;
sdi    : sextupole, l = 0.210000, k = -9.501898, n = 2, ax = 50.00,
         ay = 50.00;


{----- table of segments ----------------------------------------------------}

l000001 : sept, di6, bpm, dc1b, qf, dc2a, dcor, hcor, vcor, dcor,
          dc2b, qd, dc3a, bpm, dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor,
          hcor, vcor, dcor, dc5b, sf;
l000002 : dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor,
          vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qd, dc2c,
          dcor, hcor, vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, m3m, dc1a, bpm,
          dc1b, qf, dc2a, dcor, hcor, vcor, dcor, dc2b, qd, dc3a, bpm, dc3b,
          bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor, dc5b, sf,
          dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor, vcor, dcor,
          dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qd, dc2c, dcor, hcor,
          vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, bl7, dc1a, bpm, dc1b, qf,
          dc2a, dcor, hcor, vcor, dcor, dc2b, qd, dc3a, bpm, dc3b, bend, dc4a,
          bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor, dc5b, sf, dc6a, bpm,
          dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor, vcor, dcor, dc5d, sd,
          dc4b, bpm, dc4a, bend, dc3b, dc3a, qd, dc2c, dcor, hcor, vcor, dcor,
          dc2d, qf, dc1b, bpm, dc1a, bl10, dc1a, bpm, dc1b, qf, dc2a, dcor,
          hcor, vcor, dcor, dc2b, qd, dc3a, bpm, dc3b, bend, dc4a, bpm, dc4b,
          sd, dc5a, dcor, hcor, vcor, dcor, dc5b, sf, dc6a, bpm, dc6b, qfc,
          dc6b, dc6a, sf, dc5c, dcor, hcor, vcor, dcor, dc5d, sd, dc4b, bpm,
          dc4a, bend, dc3b, dc3a, qd, dc2c, dcor, hcor, vcor, dcor;
l000003 : dc2d, qf, dc1b, bpm, dc1a, bl9, dc1a, bpm, dc1b, qfm2e,
          dc2a, dcor, hcor, vcor, dcor, dc2b, qdm2e, dc3a, bpm, dc3b, bend,
          dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor, dc5b, sf, dc6a,
          bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor, vcor, dcor, dc5d,
          sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qdm1e, dc2c, dcor, hcor, vcor,
          dcor, dc2d, qfm1e, dc1b, bpm, dc1a, db10c, mme, db10b, bpm, db10a,
          qfzbe, db9b, dcor, vcor, hcor, dcor, db9a, qdzbe, db8b, bpm, db8a,
          b34, db5d, bpm, db5c, sdi, db6d, dcor, vcor, hcor, dcor, db6c, sfi,
          db7b, bpm, db7a, qfybe, dm7, sfi, db6b, dcor, vcor, hcor, dcor, db6a,
          sdi, db5b, bpm, db5a, b34, dm4, qdybe, db3b, bpm, db3a, qfxbe, db2b,
          dcor, vcor, hcor, dcor, db2a, qdxbe, db1b, bpm, db1ae, b1e, dch3b,
          mipbe, dch3b, b2e, dch2b, qfbe, dch1b, qde, qde, dch1a, qfae, dch2a,
          b3e, dch3a, mipae, dch3a, b4e, da1ae, bpm, da1b, qdxae, da2a, dcor,
          hcor, vcor, dcor, da2b, qfxae, da3a, bpm, da3b, qdyae, dm4, b34,
          da5a, bpm, da5b, sdi, da6a, dcor, hcor, vcor, dcor, da6b, sfi, da7a,
          bpm, da7b, qfyae, dm7, sfi, da6c, dcor, hcor, vcor, dcor, da6d, sdi,
          da5c, bpm, da5d, b34, da8a, bpm, da8b, qdzae, da9a, dcor, hcor, vcor,
          dcor, da9b, qfzae, da10a, bpm, da10b, mme, da10c, dc1a, bpm, dc1b,
          qfm1e, dc2a, dcor, hcor, vcor, dcor, dc2b, qdm1e, dc3a, bpm;
l000004 : dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor,
          dcor, dc5b, sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor,
          hcor, vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qdm2e,
          dc2c, dcor, hcor, vcor, dcor, dc2d, qfm2e, dc1b, bpm, dc1a, bl6,
          dc1a, bpm, dc1b, qf, dc2a, dcor, hcor, vcor, dcor, dc2b, qd, dc3a,
          bpm, dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor,
          dc5b, sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor,
          vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qd, dc2c,
          dcor, hcor, vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, bl5, dc1a, bpm,
          dc1b, qf, dc2a, dcor, hcor, vcor, dcor, dc2b, qd, dc3a, bpm, dc3b,
          bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor, dc5b, sf,
          dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor, vcor, dcor,
          dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qd, dc2c, dcor, hcor,
          vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, m3m, dc1a, bpm, dc1b, qf,
          dc2a, dcor, hcor, vcor, dcor, dc2b, qd, dc3a, bpm, dc3b, bend, dc4a,
          bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor, dc5b, sf, dc6a, bpm,
          dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor, vcor, dcor, dc5d, sd,
          dc4b, bpm, dc4a, bend, dc3b;
l000005 : dc3a, qd, dc2c, dcor, hcor, vcor, dcor, dc2d, qf, dc1b, bpm,
          dc1a, m3m, dc1a, bpm, dc1b, qf, dc2a, dcor, hcor, vcor, dcor, dc2b,
          qd, dc3a, bpm, dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor,
          vcor, dcor, dc5b, sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c,
          dcor, hcor, vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a,
          qd, dc2c, dcor, hcor, vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, bl11,
          dc1a, bpm, dc1b, qf, dc2a, dcor, hcor, vcor, dcor, dc2b, qd, dc3a,
          bpm, dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor,
          dc5b, sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor,
          vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qd, dc2c,
          dcor, hcor, vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, bl4, dc1a, bpm,
          dc1b, qfm2w, dc2a, dcor, hcor, vcor, dcor, dc2b, qdm2w, dc3a, bpm,
          dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor, dcor, dc5b,
          sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor, hcor, vcor,
          dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qdm1w, dc2c, dcor,
          hcor, vcor, dcor, dc2d, qfm1w, dc1b, bpm, dc1a, db10c, bl13, mmw,
          db10b, bpm, db10a, qfzw, db9b, dcor, vcor, hcor, dcor, db9a, qdzw;
l000006 : db8b, bpm, db8a, b34, db5d, bpm, db5c, sdi, db6d, dcor,
          vcor, hcor, dcor, db6c, sfi, db7b, bpm, db7a, qfyw, dm7, sfi, db6b,
          dcor, vcor, hcor, dcor, db6a, sdi, db5b, bpm, db5a, b34, dm4, qdyw,
          db3b, bpm, db3a, qfxw, db2b, dcor, vcor, hcor, dcor, db2a, qdxw,
          db1b, bpm, db1aw, cavity, cavity, mrf, cavity, cavity, da1aw, bpm,
          da1b, qdxw, da2a, dcor, hcor, vcor, dcor, da2b, qfxw, da3a, bpm,
          da3b, qdyw, dm4, b34, da5a, bpm, da5b, sdi, da6a, dcor, hcor, vcor,
          dcor, da6b, sfi, da7a, bpm, da7b, qfyw, dm7, sfi, da6c, dcor, hcor,
          vcor, dcor, da6d, sdi, da5c, bpm, da5d, b34, da8a, bpm, da8b, qdzw,
          da9a, dcor, hcor, vcor, dcor, da9b, qfzw, da10a, bpm, da10b, mmw,
          da10c, dc1a, bpm, dc1b, qfm1w, dc2a, dcor, hcor, vcor, dcor, dc2b,
          qdm1w, dc3a, bpm, dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor,
          vcor, dcor, dc5b, sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c,
          dcor, hcor, vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a,
          qdm2w, dc2c, dcor, hcor, vcor, dcor, dc2d, qfm2w, dc1b, bpm, dc1a,
          m3m, dc1a, bpm, dc1b, qf, dc2a, dcor, hcor, vcor, dcor, dc2b, qd,
          dc3a, bpm, dc3b, bend, dc4a, bpm, dc4b, sd, dc5a, dcor, hcor, vcor,
          dcor, dc5b, sf, dc6a, bpm, dc6b, qfc, dc6b, dc6a, sf, dc5c, dcor,
          hcor, vcor, dcor, dc5d, sd, dc4b, bpm, dc4a, bend, dc3b, dc3a, qd,
          dc2c, dcor, hcor, vcor, dcor, dc2d, qf, dc1b, bpm, dc1a, mmm, di5;
ring    : l000001, l000002, l000003, l000004, l000005, l000006;

{c:\users\streun\opadat\repository\spear_sp3v82_lelt.opa}
