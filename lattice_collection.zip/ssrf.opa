{c:\users\streun\opadat\repository\ssrf.opa}
{com original file dec5_c55 from may 27, 2005 com}


energy = 3.500000;

    betax   = 10.0044048; alphax  = 0.0000000;
    etax    = 0.1500948; etaxp   = 0.0000000;
    betay   = 6.0003883; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- table of elements ----------------------------------------------------}

dl   : drift, l = 6.000000, ax = 50.00, ay = 50.00;
d1   : drift, l = 0.345000, ax = 50.00, ay = 50.00;
d2   : drift, l = 0.130000, ax = 50.00, ay = 50.00;
d3   : drift, l = 0.180000, ax = 50.00, ay = 50.00;
dhv1 : drift, l = 0.100000, ax = 50.00, ay = 50.00;
d4   : drift, l = 0.180000, ax = 50.00, ay = 50.00;
d5   : drift, l = 0.130000, ax = 50.00, ay = 50.00;
d6   : drift, l = 0.600000, ax = 50.00, ay = 50.00;
d7   : drift, l = 0.270000, ax = 50.00, ay = 50.00;
dhv2 : drift, l = 0.100000, ax = 50.00, ay = 50.00;
d8   : drift, l = 0.130000, ax = 50.00, ay = 50.00;
d9   : drift, l = 0.360000, ax = 50.00, ay = 50.00;
d10  : drift, l = 0.435000, ax = 50.00, ay = 50.00;
d11  : drift, l = 0.180000, ax = 50.00, ay = 50.00;
d12  : drift, l = 0.180000, ax = 50.00, ay = 50.00;
d13  : drift, l = 0.117500, ax = 50.00, ay = 50.00;
dhv3 : drift, l = 0.100000, ax = 50.00, ay = 50.00;
d14  : drift, l = 0.117500, ax = 50.00, ay = 50.00;
d15  : drift, l = 0.360000, ax = 50.00, ay = 50.00;
d17  : drift, l = 0.280000, ax = 50.00, ay = 50.00;
d18  : drift, l = 0.130000, ax = 50.00, ay = 50.00;
d19  : drift, l = 0.127500, ax = 50.00, ay = 50.00;
dhv4 : drift, l = 0.100000, ax = 50.00, ay = 50.00;
d20  : drift, l = 0.127500, ax = 50.00, ay = 50.00;
d21  : drift, l = 0.130000, ax = 50.00, ay = 50.00;
d22  : drift, l = 0.345000, ax = 50.00, ay = 50.00;
dm   : drift, l = 3.250000, ax = 50.00, ay = 50.00;
lq1  : drift, l = 0.320000, ax = 50.00, ay = 50.00;
lq2  : drift, l = 0.000000, ax = 50.00, ay = 50.00;
lq3  : drift, l = 0.000000, ax = 50.00, ay = 50.00;
ls1  : drift, l = 0.000000, ax = 50.00, ay = 50.00;
ls2  : drift, l = 0.000000, ax = 50.00, ay = 50.00;
dsx1 : drift, l = 0.100000, ax = 50.00, ay = 50.00;
dsx2 : drift, l = 0.120000, ax = 50.00, ay = 50.00;

bpm  : marker, ax = 50.00, ay = 50.00;
hvc  : marker, ax = 50.00, ay = 50.00;

q1l  : quadrupole, l = 0.320000, k = -1.026600, ax = 50.00, ay = 50.00;
q2lh : quadrupole, l = 0.290000, k = 1.363500, ax = 50.00, ay = 50.00;
q3l  : quadrupole, l = 0.320000, k = -1.261800, ax = 50.00, ay = 50.00;
q4l  : quadrupole, l = 0.260000, k = -1.037900, ax = 50.00, ay = 50.00;
q5l  : quadrupole, l = 0.320000, k = 1.391400, ax = 50.00, ay = 50.00;
q1   : quadrupole, l = 0.320000, k = -1.527800, ax = 50.00, ay = 50.00;
q2h  : quadrupole, l = 0.290000, k = 1.533300, ax = 50.00, ay = 50.00;
q3   : quadrupole, l = 0.320000, k = -1.082800, ax = 50.00, ay = 50.00;
q4   : quadrupole, l = 0.260000, k = -1.325600, ax = 50.00, ay = 50.00;
q5   : quadrupole, l = 0.320000, k = 1.456700, ax = 50.00, ay = 50.00;

bb   : bending, l = 1.440000, t = 9.000000, k = 0.000000, t1 = 4.500000,
       t2 = 4.500000, ax = 50.00, ay = 50.00;

s10  : sextupole, l = 0.000000, k = 1.505900, n = 1, ax = 50.00, ay = 50.00;
s20  : sextupole, l = 0.000000, k = -2.715200, n = 1, ax = 50.00, ay = 50.00;
s30  : sextupole, l = 0.000000, k = 2.736100, n = 1, ax = 50.00, ay = 50.00;
s40  : sextupole, l = 0.000000, k = -3.008600, n = 1, ax = 50.00, ay = 50.00;
s50  : sextupole, l = 0.000000, k = 3.273200, n = 1, ax = 50.00, ay = 50.00;
s60  : sextupole, l = 0.000000, k = -4.378500, n = 1, ax = 50.00, ay = 50.00;
sd0  : sextupole, l = 0.000000, k = -2.524200, n = 1, ax = 50.00, ay = 50.00;
sf0  : sextupole, l = 0.000000, k = 3.662800, n = 1, ax = 50.00, ay = 50.00;


{----- table of segments ----------------------------------------------------}

s1       : dsx1, s10, dsx1;
s3       : dsx1, s30, dsx1;
s5       : dsx1, s50, dsx1;
sd       : dsx1, sd0, dsx1;
s2       : dsx2, s20, dsx2;
s4       : dsx2, s40, dsx2;
s6       : dsx2, s60, dsx2;
sf       : dsx2, sf0, dsx2;
q2l      : 2*q2lh;
q2       : 2*q2h;
gird1    : dl, bpm, q1l, d1, s1, d2, q2l, d3, dhv1, hvc, dhv1, d4,
           bpm, q3l, d5, s2, d6;
girdl1   : d7, dhv2, hvc, dhv2, d8, bpm, q4l, d9, sd, d10, q5l, d11, bpm;
girdm1   : d7, dhv2, hvc, dhv2, d8, bpm, q4, d9, sd, d10, q5, d11, bpm;
girdl2   : -girdl1;
girdm2   : -girdm1;
gird3    : d17, q3, d18, s4, bpm, d19, dhv4, hvc, dhv4, d20, q2, d21,
           s3, d22, q1, bpm, dm;
gird4    : d17, q3, d18, s6, bpm, d19, dhv4, hvc, dhv4, d20, q2, d21,
           s5, d22, q1, bpm, dm;
m1       : gird1, bb, girdl1, sf, girdm2, bb, gird3;
m2       : -gird3, bb, girdm1, sf, girdm2, bb, gird4;
m3       : -gird4, bb, girdm1, sf, girdm2, bb, gird4;
m4       : -gird4, bb, girdm1, sf, girdm2, bb, gird3;
m5       : -gird3, bb, girdm1, sf, girdl2, bb, -gird1;
cell     : m1, m2, m3, m4, m5;
quadrant : cell, nper=4;
ring     : 4*cell;

{c:\users\streun\opadat\repository\ssrf.opa}
