{/home/as/opa/tps_tdmb2683_5.opa}
{com tps 518.4m plus triple double minimum, tdmb2683_5  com}


energy = 3.000000;
rotinv = 0;
    betax   = 10.0999967; alphax  = 0.0000000;
    etax    = 0.1172385; etaxp   = 0.0000000;
    betay   = 6.0660281; alphay  = 0.0000000;
    etay    = 0.0000000; etayp   = 0.0000000;

{----- variables ---------------------------------------------------}


{----- table of elements ---------------------------------------------}

dc1     : drift, l = 0.500000, ax = 50.00, ay = 50.00;
dc2     : drift, l = 2.250000, ax = 50.00, ay = 50.00;
dl1     : drift, l = 6.000000, ax = 50.00, ay = 50.00;
dl2     : drift, l = 0.730000, ax = 50.00, ay = 50.00;
dl2a    : drift, l = 0.355000, ax = 50.00, ay = 50.00;
dl2b    : drift, l = 0.125000, ax = 50.00, ay = 50.00;
dl3     : drift, l = 0.700000, ax = 50.00, ay = 50.00;
dl4     : drift, l = 0.750000, ax = 50.00, ay = 50.00;
dl4a    : drift, l = 0.125000, ax = 50.00, ay = 50.00;
dl4b    : drift, l = 0.375000, ax = 50.00, ay = 50.00;
dc5     : drift, l = 0.550000, ax = 50.00, ay = 50.00;
dc6     : drift, l = 0.950000, ax = 50.00, ay = 50.00;
dc6a    : drift, l = 0.275000, ax = 50.00, ay = 50.00;
dc6b    : drift, l = 0.425000, ax = 50.00, ay = 50.00;
dc7     : drift, l = 0.255000, ax = 50.00, ay = 50.00;
ds1     : drift, l = 3.500000, ax = 50.00, ay = 50.00;
ds2     : drift, l = 0.680000, ax = 50.00, ay = 50.00;
ds2a    : drift, l = 0.305000, ax = 50.00, ay = 50.00;
ds2b    : drift, l = 0.125000, ax = 50.00, ay = 50.00;
ds3     : drift, l = 0.800000, ax = 50.00, ay = 50.00;
ds3a    : drift, l = 0.425000, ax = 50.00, ay = 50.00;
ds3b    : drift, l = 0.125000, ax = 50.00, ay = 50.00;
ds4     : drift, l = 0.320000, ax = 50.00, ay = 50.00;
d3      : drift, l = 0.300000, ax = 50.00, ay = 50.00;
diu22   : drift, l = 3.058000, ax = 50.00, ay = 50.00;
dp05l   : drift, l = 1.971000, ax = 50.00, ay = 50.00;
dp05r   : drift, l = 1.971000, ax = 50.00, ay = 50.00;
dp09l   : drift, l = 0.871000, ax = 50.00, ay = 50.00;
dp09r   : drift, l = 0.871000, ax = 50.00, ay = 50.00;
dp21l   : drift, l = 1.971000, ax = 50.00, ay = 50.00;
dp21r   : drift, l = 1.971000, ax = 50.00, ay = 50.00;
dp23l   : drift, l = 1.971000, ax = 50.00, ay = 50.00;
dp23r   : drift, l = 1.971000, ax = 50.00, ay = 50.00;
dp25l   : drift, l = 0.871000, ax = 50.00, ay = 50.00;
dp25r   : drift, l = 0.871000, ax = 50.00, ay = 50.00;
depu48h : drift, l = 1.752000, ax = 50.00, ay = 50.00;
dp41l   : drift, l = 0.648000, ax = 50.00, ay = 50.00;
dp41r   : drift, l = 0.648000, ax = 50.00, ay = 50.00;
du50    : drift, l = 3.900000, ax = 50.00, ay = 50.00;
dp45l   : drift, l = 1.550000, ax = 50.00, ay = 50.00;
dp45r   : drift, l = 1.550000, ax = 50.00, ay = 50.00;

rf      : marker, ax = 50.00, ay = 50.00;
miu22l  : marker, ax = 50.00, ay = 50.00;
miu22r  : marker, ax = 50.00, ay = 50.00;
mepu48l : marker, ax = 50.00, ay = 50.00;
mepu48r : marker, ax = 50.00, ay = 50.00;
mu50l   : marker, ax = 50.00, ay = 50.00;
mu50r   : marker, ax = 50.00, ay = 50.00;
center  : marker, ax = 50.00, ay = 50.00;

qs5     : quadrupole, l = 0.300000, k = 1.599979, ax = 50.00, ay = 50.00;
qs4     : quadrupole, l = 0.300000, k = -0.962645, ax = 50.00, ay = 50.00;
qs3     : quadrupole, l = 0.300000, k = -1.370107, ax = 50.00, ay = 50.00;
qs2     : quadrupole, l = 0.600000, k = 1.549289, ax = 50.00, ay = 50.00;
qs1     : quadrupole, l = 0.300000, k = -1.700000, ax = 50.00, ay = 50.00;
ql3     : quadrupole, l = 0.300000, k = -1.256309, ax = 50.00, ay = 50.00;
ql2     : quadrupole, l = 0.600000, k = 1.301193, ax = 50.00, ay = 50.00;
ql1     : quadrupole, l = 0.300000, k = -1.080812, ax = 50.00, ay = 50.00;
q1      : quadrupole, l = 0.300000, k = -1.312360, ax = 50.00, ay = 50.00;
q2      : quadrupole, l = 0.600000, k = 1.414010, ax = 50.00, ay = 50.00;
q3      : quadrupole, l = 0.300000, k = -1.582253, ax = 50.00, ay = 50.00;
q4      : quadrupole, l = 0.600000, k = -1.233023, ax = 50.00, ay = 50.00;
q5      : quadrupole, l = 0.600000, k = 1.700000, ax = 50.00, ay = 50.00;

bce     : bending, l = 0.500000, t = 1.500000, k = 0.000000, t1 = 0.000000,
          t2 = 1.500000, ax = 50.00, ay = 50.00;
bcm     : bending, l = 0.500000, t = -1.500000, k = 0.000000, t1 = -1.500000,
          t2 = 0.000000, ax = 50.00, ay = 50.00;
bend    : bending, l = 1.100000, t = 7.500000, k = 0.000000, t1 = 3.750000,
          t2 = 3.750000, ax = 50.00, ay = 50.00;

s1      : sextupole, l = 0.250000, k = 5.946000, n = 4, ax = 50.00,
          ay = 50.00;
s2      : sextupole, l = 0.250000, k = -13.980000, n = 4, ax = 50.00,
          ay = 50.00;
s3      : sextupole, l = 0.250000, k = 19.520000, n = 4, ax = 50.00,
          ay = 50.00;
s4      : sextupole, l = 0.250000, k = -21.150000, n = 4, ax = 50.00,
          ay = 50.00;
s5      : sextupole, l = 0.250000, k = 16.430000, n = 4, ax = 50.00,
          ay = 50.00;
s6      : sextupole, l = 0.250000, k = -20.340000, n = 1, ax = 50.00,
          ay = 50.00;
sd      : sextupole, l = 0.250000, k = -13.945000, n = 4, ax = 50.00,
          ay = 50.00;
sf      : sextupole, l = 0.250000, k = 19.150000, n = 4, ax = 50.00,
          ay = 50.00;

omodc   : opticsmarker, betax = 10.842000, alphax = 0.272447, betay = 7.232000,
          alphay = 0.448577, etax  = 0.000000, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;
epu1c   : opticsmarker, betax = 10.842028, alphax = -0.272447,
          betay = 7.232003, alphay = -0.448577, etax  = 0.051735,
          etaxp  = 0.026186, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
          ay = 50.00;
omod    : opticsmarker, betax = 5.226295, alphax = -0.002822, betay = 1.639084,
          alphay = 0.007043, etax  = 0.086643, etaxp  = -0.000496,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;
iu22c   : opticsmarker, betax = 5.228470, alphax = 0.002967, betay = 1.661435,
          alphay = -0.000130, etax  = 0.086597, etaxp  = 0.000509,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;
orepu1  : opticsmarker, betax = 10.536151, alphax = 0.441346, betay = 1.781029,
          alphay = 0.072289, etax  = 0.113040, etaxp  = -0.000951,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;
orepu2  : opticsmarker, betax = 10.535964, alphax = -0.441316,
          betay = 1.766495, alphay = -0.085558, etax  = 0.113040,
          etaxp  = 0.000951, etay  = 0.000000, etayp  = 0.000000, ax = 50.00,
          ay = 50.00;
oriu22  : opticsmarker, betax = 5.226161, alphax = 0.002834, betay = 1.646404,
          alphay = -0.022631, etax  = 0.086643, etaxp  = 0.000496,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;
ocl16   : opticsmarker, betax = 7.592198, alphax = -0.672384, betay = 9.033669,
          alphay = -2.106483, etax  = 0.084817, etaxp  = -0.000509,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;
ocmid   : opticsmarker, betax = 10.099782, alphax = 0.000000, betay = 6.012700,
          alphay = 0.000000, etax  = -0.013732, etaxp  = 0.000000,
          etay  = 0.000000, etayp  = 0.000000, ax = 50.00, ay = 50.00;

xbeam   : photonbeam, xl = 20.00, style = 0, snap = 1, ax = 50.00,
          ay = 50.00;


{----- table of segments ---------------------------------------------}

l45p    : dc1, bce, dc2, omodc, dc2, bcm, ocmid, -bcm, dc2, epu1c, dc2, -bce,
          dc1;
l45m    : dc1, -bcm, dc2, omodc, xbeam, dc2, -bce, ocmid, bce, dc2, epu1c,
          xbeam, dc2, bcm, dc1;
l23     : dl1, dl1;
dball   : ql1, dl2a, s1, dl2b, ql2, dl3, ql3, dl4a, s2, dl4b;
dbalm   : dc5, qs4, dc6a, sd, dc6b, qs5, dc7, sf, dc7, qs5, dc6b, sd, dc6a,
          qs4, dc5;
dbalr   : ds4, qs3, ds3b, s4, ds3a, qs2, ds2b, s3, ds2a, qs1;
dbasl   : qs1, ds2a, s5, ds2b, qs2, ds3a, s6, ds3b, qs3, ds4;
dbasr   : ds4, qs3, ds3b, s6, ds3a, qs2, ds2b, s5, ds2a, qs1;
db04r   : dl4b, s2, dl4a, q3, dl3, q2, dl2b, s1, dl2a, q1;
cell01  : dball, bend, dbalm, bend, dbalr;
port03  : 2*ds1;
cell02  : dbasl, bend, dbalm, bend, dbasr;
port05  : dp05l, miu22l, diu22, miu22r, dp05r;
cell03  : -cell02;
port07  : 2*ds1;
cell04  : -dbalr, bend, -dbalm, bend, db04r;
port09  : dp09l, miu22l, diu22, miu22r, dp09r, q4, d3, q5, d3, q4, dp09r,
          miu22l, diu22, miu22r, dp09l;
cell05  : -db04r, bend, dbalm, bend, dbalr;
port11  : 2*ds1;
cell06  : cell02;
port13  : 2*ds1;
cell07  : -cell02;
port15  : 2*ds1;
cell08  : -cell01;
cell09  : cell01;
port19  : 2*ds1;
cell10  : cell02;
port21  : dp21l, miu22l, diu22, miu22r, dp21r;
cell11  : -cell02;
port23  : dp23l, miu22l, diu22, miu22r, dp23r;
cell12  : cell04;
port25  : dp25l, miu22l, diu22, miu22r, dp25r, q4, d3, q5, d3, q4, dp25r,
          miu22l, diu22, miu22r, dp25l;
cell13  : cell05;
port27  : 2*ds1;
cell14  : cell02;
port29  : 2*ds1;
cell15  : -cell02;
port31  : 2*ds1;
cell16  : -cell01;
cell17  : cell01;
port35  : ds1, iu22c, ds1;
cell18  : cell02;
port37  : ds1, rf, ds1;
cell19  : -cell02;
port39  : ds1, omod, ds1;
cell20  : cell04;
port41  : dp41l, mepu48l, depu48h, orepu1, depu48h, mepu48r, dp41r, q4, d3, q5,
          d3, q4, dp41r, mepu48l, depu48h, orepu2, depu48h, mepu48r, dp41l;
cell21  : cell05;
port43  : ds1, oriu22, ds1;
cell22  : cell02;
port45  : dp45l, mu50l, du50, mu50r, dp45r;
cell23  : -cell02;
port47  : 2*ds1;
cell24  : -cell01;
period1 : cell01, port03, cell02, port05, cell03, port07, cell04;
period2 : cell05, port11, cell06, port13, cell07, port15, cell08;
period3 : cell09, port19, cell10, port21, cell11, port23, cell12;
period4 : cell13, port27, cell14, port29, cell15, port31, ocl16, cell16;
period5 : cell17, port35, cell18, port37, cell19, port39, cell20;
period6 : cell21, port43, cell22, port45, cell23, port47, cell24;
per1    : period1, port09, period2;
per2    : period3, port25, period4;
per3    : period5, port41, period6;
ring0   : dl1, per1, l23, per2, dl1, dl1, per3, dl1;
ringp   : dl1, per1, l23, per2, l45p, per3, dl1;
ringm   : dl1, per1, l23, per2, l45m, per3, dl1;
ring    : dl1, per1, dl1, center, nper=3;
full    : 3*ring;

{/home/as/opa/tps_tdmb2683_5.opa}
